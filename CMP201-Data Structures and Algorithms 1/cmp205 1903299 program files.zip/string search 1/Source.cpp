#include <iostream>
#include <vector>
#include <string>
#include <algorithm> // used to get transform the inputed string into different cases and nothing else   
#include <fstream>

using namespace std;
using Position = long long int;

// taken from the week 7 lab used for clarity and ease of use since the algorithium its self is beening tested not the whole program
void show_context(const string& str, Position pos) {const int width = 76;
	Position left = pos - (width / 2);
	Position right = pos + (width / 2);
	Position len = str.size();
	for (Position i = left; i < right; ++i) {
		if (i < 0 || i >= len) {
			cout << ' ';
			continue;
		}
		char c = str[i];
		if (c >= 32 && c < 128) {
			cout << c;
		}
		else {
			// Show control characters as @s.
			cout << '@';
		}
	}
	cout << '\n';
	for (Position i = left; i < right; ++i) {
		if (i < pos) {
			cout << ' ';
		}
		else if (i == pos) {
			cout << "^ " << pos;
		}
	}
	cout << '\n';
}


string ReadFile(const string& path) {// loads the file enter.txt
	ifstream input_file(path);
	if (!input_file.is_open()) {
		cout<< "The file "<< path << "has not been found." << endl;
		exit;
	}
	return string((std::istreambuf_iterator<char>(input_file)), std::istreambuf_iterator<char>());
}

Position find_bm(const string& pat1, const string& pat2, const string& pat3, const string& text) {
	Position pat_len = pat1.size();
	Position text_len = text.size();
    vector<Position> Num_found;
	Position j;
	string pat;
	string str[3]{pat1, pat2, pat3};

becomes:int skip[256]{};
	for (int i = 0; i < 256; ++i) {
		skip[i] = pat_len; // Not in the pattern.
	}
	for (int i = 0; i < pat_len; ++i) {
		skip[int(pat1[i])] = (pat_len - 1) - i; //all caps
	}
	for (int i = 0; i < pat_len; ++i) {
		skip[int(pat2[i])] = (pat_len - 1) - i;// all lower case 
	}
	for (int i = 0; i < pat_len; ++i) {
		skip[int(pat3[i])] = (pat_len - 1) - i;// proper noun 
	}

	for (int i = 0; i < text_len - pat_len; ++i) {
		int s = skip[int(text[i + pat_len - 1])];
		if (s != 0) {
			i += s - 1; // Skip forwards.
			continue;
		}

		for (int x = 0; x < 3; x++)
		{
			pat = str[x];
		   for (j = 0; j < pat_len; j++) {// Check for characters one by one for all upper case then lower than as a proper noun
				if (text[i + j] != pat[j]) {
					break; // Doesn't match here.
				}
		   }
			if (j == pat_len) {
				Num_found.push_back(i);
			}
		}
	}


	if (Num_found.empty()) { return -1; }
	for (Position val : Num_found) {
		show_context(text, val); // taken from the week 7 lab used for clarity and ease of use since the algorithium its self is beening tested not the whole program			
	}
	cout << "The pattern was found " << Num_found.size() << " times.\n";
	Num_found.clear();
	return 0;


}


int main(int argc, char* argv[])
{
    string text;
	text = ReadFile("enter.txt");

	string pat ;
	cout << "Enter the word you want to search for (Suggested word Dundee)\n";	
	cin >> pat;
	string pat1 = pat, pat2 = pat1, pat3 = pat1;
	transform(pat1.begin(), pat1.end(), pat1.begin(), ::toupper); // transforms string into all caps
	transform(pat2.begin(), pat2.end(), pat2.begin(), ::tolower); // transform strinf in to all lower case
	pat3[0] = toupper(pat3[0]); // capitalises first charater of the string 

	find_bm(pat1, pat2, pat3, text);
	return 0;
}