#include <iostream>
#include <vector>
#include <string>
#include <algorithm>// used to get transform the inputed string into different cases and nothing else
#include <fstream>

using namespace std;
using Position = long long int;

// taken from the week 7 lab used for clarity and ease of use since the algorithium its self is beening tested not the whole program
void show_context(const string& str, Position pos) {
	const int width = 76;
	Position left = pos - (width / 2);
	Position right = pos + (width / 2);
	Position len = str.size();
	for (Position i = left; i < right; ++i) {
		if (i < 0 || i >= len) {
			cout << ' ';
			continue;
		}
		char c = str[i];
		if (c >= 32 && c < 128) {
			cout << c;
		}
		else {
			// Show control characters as @s.
			cout << '@';
		}
	}
	cout << '\n';
	for (Position i = left; i < right; ++i) {
		if (i < pos) {
			cout << ' ';
		}
		else if (i == pos) {
			cout << "^ " << pos;
		}
	}
	cout << '\n';
}

string ReadFile(const string& path) {// loads the file enter.txt
	ifstream input_file(path);
	if (!input_file.is_open()) {
		cout << "The file " << path << "has not been found." << endl;
		exit;
	}
	return string((std::istreambuf_iterator<char>(input_file)), std::istreambuf_iterator<char>());
}

Position find_RK(const string& pat1, const string& pat2, const string& pat3, const string& text) {
	// basic layout taken form geeks for geeks link : https://www.geeksforgeeks.org/rabin-karp-algorithm-for-pattern-searching/

	Position pat_len = pat1.size();
	Position text_len = text.size();
becomes:int skip = 256;
	static vector<Position> Num_found;
	string pat;
	int i, j;
	int q = 101;
	int p = 0; // hash value for pattern all caps
	int p2 = 0;// hash value for pattern all lower case
	int p3 = 0;// hash value for pattern proper noun 
	int t = 0; // hash value for txt 
	int h = 1;

	// The value of h would be "pow(d, M-1)%q" 
	for (i = 0; i < pat_len - 1; i++)
		h = (h * skip) % q;

	// Calculate the hash value of patterns and first 
	// window of text 
	for (i = 0; i < pat_len; i++)
	{
		p = (skip * p + pat1[i]) % q;
		p2 = (skip * p2 + pat2[i]) % q;
		p3 = (skip * p3 + pat3[i]) % q;
		t = (skip * t + text[i]) % q;
	}

	// Slide the pattern over text one by one 
	for (i = 0; i <= text_len - pat_len; i++)
	{

		// Check the hash values of current window of text and pattern. 
		if (p == t || p2 == t || p3 == t) // if a match is found then depending on the hash value the pat variable is made to equal the corisponding Pattern 
		{
			bool flag = true;

			if (p == t) { // all caps
				pat = pat1;
			}
			if (p2 == t) { // all lower case
				pat = pat2;
			}
			if (p3 == t) { // proper noun 
				pat = pat3;
			}

			// Check for characters one by one against the pattern 
			for (j = 0; j < pat_len; j++)
			{
				if (text[static_cast<std::basic_string<char, std::char_traits<char>, std::allocator<char>>::size_type>(i) + j] != pat[j])
				{
					flag = false;
					j = 100;
					continue;
				}

			}

			if (j == pat_len) {

				Num_found.push_back(i);
			}

		}

		// Calculate hash value for next window of text: Remove 
		// leading digit, add trailing digit 
		if (i < text_len - pat_len)
		{
			t = (skip * (t - text[i] * h) + text[i + pat_len]) % q;

			// We might get negative value of t, converting it 
			// to positive 
			if (t < 0)
				t = (t + q);
		}
	}


	if (Num_found.empty()) { return -1; }
	for (Position val : Num_found) {
		show_context(text, val);
	}
	cout << "The pattern was found " << Num_found.size() << " times.\n";
	Num_found.clear();
	return 0;
}


int main(int argc, char* argv[])
{
	string text;
	text = ReadFile("enter.txt");
	
	string pat;
	cout << "Enter the word you want to search for (Suggested word Dundee)\n";	
	cin >> pat;
	string pat1 = pat, pat2 = pat1, pat3 = pat1;

	transform(pat1.begin(), pat1.end(), pat1.begin(), ::toupper);
	transform(pat2.begin(), pat2.end(), pat2.begin(), ::tolower);
	pat3[0] = toupper(pat3[0]);

	find_RK(pat1, pat2, pat3, text);
	return 0;
}