﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Comic_book_store
{
    public partial class Customers_Page : Form
    {
        public Customers_Page(string email, string pass)
        {
            InitializeComponent();
            textBox2.Text = email;
            textBox3.Text = pass;
        }

        
        
        readonly mssql1903299Entities4 db = new mssql1903299Entities4();
        CUSTOMER CUS = new CUSTOMER();
        
        readonly C_ORDER order = new C_ORDER();
        readonly C_ORDER_CONTAINS order_con = new C_ORDER_CONTAINS();
        Functions GB = new Functions();
        int EmpId = 0;

        private void Customers_Page_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mssql1903299DataSet29.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            //this.c_ORDER_CONTAINSTableAdapter4.Fill(this.mssql1903299DataSet29.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet26.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            //this.c_ORDER_CONTAINSTableAdapter3.Fill(this.mssql1903299DataSet26.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet24.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            //this.c_ORDER_CONTAINSTableAdapter2.Fill(this.mssql1903299DataSet24.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet21.C_ORDER' table. You can move, or remove it, as needed.
            // this.c_ORDERTableAdapter1.Fill(this.mssql1903299DataSet21.C_ORDER);
            // TODO: This line of code loads data into the 'mssql1903299DataSet18.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            //this.c_ORDER_CONTAINSTableAdapter1.Fill(this.mssql1903299DataSet18.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet15.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            // this.c_ORDER_CONTAINSTableAdapter.Fill(this.mssql1903299DataSet15.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet14.C_ORDER' table. You can move, or remove it, as needed.
            // this.c_ORDERTableAdapter.Fill(this.mssql1903299DataSet14.C_ORDER);
            // TODO: This line of code loads data into the 'mssql1903299DataSet12.CUSTOMER' table. You can move, or remove it, as needed.
            //this.cUSTOMERTableAdapter.Fill(this.mssql1903299DataSet12.CUSTOMER);
            // TODO: This line of code loads data into the 'mssql1903299DataSet11.PRODUCT' table. You can move, or remove it, as needed.
            this.pRODUCTTableAdapter.Fill(this.mssql1903299DataSet11.PRODUCT);

        }

        private void Customer_CUS_Save_Click(object sender, EventArgs e)
        {
            if (EmpId > 0)
                db.Entry(CUS).State = EntityState.Modified;
            else
            {
                db.CUSTOMERs.Add(CUS);
            }
            db.SaveChanges();
            MessageBox.Show("Record Save Successfully");
        }

        private void Customer_CUS_Delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete Your Account ?", "Delete ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            { 
                if (string.IsNullOrEmpty(Account_Del.Text) == true)
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Account_Del.Text = "Enter the email of the account you want to delete";
                    return;
                }
                if (Account_Del.Text == "Enter the email of the account you want to delete")
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Account_Del.Text = "Enter the email of the account you want to delete";
                    return;
                }
                var cus = new CUSTOMER();
                cus.EMAIL = Account_Del.Text.Trim();

                db.CUSTOMERs.Attach(cus);
                db.CUSTOMERs.Remove(cus);
                db.SaveChanges();
                SetCustomerView();
                MessageBox.Show("Record Deleted Successfully");
                Account_Del.Text = "Enter the email of the account you want to delete";
                var m = new Startpage();
                m.Show();
                this.Hide();

            }
        }

        public void SetCustomerView()
        {
            Customer_Cus_Data_View.AutoGenerateColumns = false;
            var email = (from x in db.CUSTOMERs
                         where x.Username == textBox2.Text && x.Pass == textBox3.Text
                         select x).ToList();
            Customer_Cus_Data_View.DataSource = email;
        }

        public void SetProductView() 
        {
            Customer_Prod_Data_View.AutoGenerateColumns = false;
            Customer_Prod_Data_View.DataSource = db.PRODUCTs.ToList<PRODUCT>();
        }

        private void Customer_Make_Order_Click(object sender, EventArgs e)
        {
            var id = (from x in db.CUSTOMERs
                      where x.Username == textBox2.Text && x.Pass == textBox3.Text
                      select x.EMAIL).FirstOrDefault();
            int basket_ID;
            order.ToCollect = 0;
           order.Customer_ID = id;
            order.Paid = 0;
            order.Order_Date = DateTime.Now;
              

            db.C_ORDER.Add(order);
            db.SaveChanges();
            basket_ID = order.ORDER_ID;
            Cus_Order_ID.Text = basket_ID.ToString();
            MessageBox.Show("Basket made");
            Customer_Spesific_Load_Order.Enabled = true;
        }

        private void Customer_InBasket_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Customer_Prod_ID.Text) == true)
            {
                MessageBox.Show("Please enter the Product ID");
                Customer_Prod_ID.Text = "Enter the product id of the item you want";
                return;
            }
            if (Customer_Prod_ID.Text == "Enter the product id of the item you want")
            {
                MessageBox.Show("Please enter the Product ID");
                Customer_Prod_ID.Text = "Enter the product id of the item you want";
                return;
            }
            if (string.IsNullOrEmpty(Customer_Prod_Quan.Text) == true)
            {
                MessageBox.Show("Please enter the number of items you want to order");
                Customer_Prod_Quan.Text = "Enter the number of items you want";
                return;
            }
            if (Customer_Prod_Quan.Text == "Enter the number of items you want")
            {
                MessageBox.Show("Please enter the number of items you want to order");
                Customer_Prod_Quan.Text = "Enter the number of items you want";
                return;
            }
            order_con.Order_Id = Convert.ToInt32(Cus_Order_ID.Text.Trim());
            order_con.Product_ID = Convert.ToInt32(Customer_Prod_ID.Text.Trim());
            int id = Convert.ToInt32(Customer_Prod_ID.Text.Trim());

            order_con.Quantity = Convert.ToInt32(Customer_Prod_Quan.Text.Trim());

            var price = (from x in db.PRODUCTs
                         where x.Product_ID == id
                         select x.Price).FirstOrDefault();
            order_con.Price = (decimal)Convert.ToDouble(price);


            db.C_ORDER_CONTAINS.Add(order_con);
            db.SaveChanges();
            Customer_InBasket.Enabled = true;

            MessageBox.Show("Record Save Successfully");
            Customer_Prod_ID.Text = "Enter the product id of the item you want";
            Customer_Prod_Quan.Text = "Enter the number of items you want";
        }

        private void Cus_Recomend_Click(object sender, EventArgs e)
        {
            string recomended = (from x in db.CUSTOMERs
                              where x.Username == textBox2.Text && x.Pass == textBox3.Text
                              select x.pref).FirstOrDefault();

                

            Customer_Prod_Data_View.AutoGenerateColumns = false;
            Customer_Prod_Data_View.DataSource = (from x in db.PRODUCTs
                                                where x.Prod_des.Contains(recomended)
                                                select x).ToList();
        }
   
        private void Cus_Show_All_prod_Click(object sender, EventArgs e)
        {
            Customer_Prod_Data_View.AutoGenerateColumns = false;
            Customer_Prod_Data_View.DataSource = db.PRODUCTs.ToList<PRODUCT>();
        }


        public void SetOrderView()
        {
            var email = (from x in db.CUSTOMERs
                        where x.Username == textBox2.Text && x.Pass == textBox3.Text
                        select x.EMAIL).FirstOrDefault(); ;
            
            Customer_Orders_Grid_View.AutoGenerateColumns = false;

            var Log = (from x in db.C_ORDER
                                       where x.Customer_ID == email
                                       select x).ToList();
            Customer_Orders_Grid_View.DataSource = Log;
            Customer_Spesific_Load_Order.Enabled = true;

        }

        private void Customer_Order_delete_Click(object sender, EventArgs e)
        {
                if (MessageBox.Show("Are you sure you want to delete this Order ?", "Delete ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                if (string.IsNullOrEmpty(Cus_S_Order.Text) == true)
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Cus_S_Order.Text = "Num";
                    return;
                }
                if (Cus_S_Order.Text == "Num")
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Cus_S_Order.Text = "Num";
                    return;
                }
                    var order = new C_ORDER();
                    var order_con = new C_ORDER_CONTAINS();
                    order.ORDER_ID = Convert.ToInt32(Cus_S_Order.Text.Trim());
                    int temp = Convert.ToInt32(Cus_S_Order.Text.Trim());

                    int check = (from a in db.C_ORDER
                                 where a.ORDER_ID == temp
                                 select a.Paid).First();

                    if (check == 1)
                    {
                        MessageBox.Show("you can not delete a Paid order");
                        Cus_S_Order.Text = "Num";
                        return;
                    }
                db.C_ORDER.Attach(order);
                    db.C_ORDER.Remove(order);
                    db.SaveChanges();
                    SetOrderView();
                    MessageBox.Show("Record Deleted Successfully");
                    Cus_S_Order.Text = "Num";
                }
        }

        private void Customer_Order_Save_Click(object sender, EventArgs e)
        {

            if (order.Paid != 0)
            {
                if (EmpId > 0)
                {
                    db.Entry(order).State = EntityState.Modified;
                    db.Entry(order_con).State = EntityState.Modified;
                }
                db.SaveChanges();
                SetOrderView();
                MessageBox.Show("Record Save Successfully");

            }

            else { MessageBox.Show("This record can not be changed since the order has been paid. "); }
        }

        private void Customer_End_Order_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) == true)
            {
                MessageBox.Show("Please enter the id of the order you want to complete");
                textBox1.Text = "Order number";
                return;
            }
            if (textBox1.Text == "Order number")
            {
                MessageBox.Show("Please enter the id of the order you want to complete");
                textBox1.Text = "Order number";
                return;
            }
            int Which = Convert.ToInt32(textBox1.Text.Trim());

            if (Customer_Prod_ToCollect.SelectedItems.Contains(""))
            {
                MessageBox.Show("Please select if you want to collect your order in store");
                return;

            }


            else if (Customer_Prod_ToCollect.SelectedItems.Contains("Yes"))
            {
                order.ToCollect = 1;
            }

            else if (Customer_Prod_ToCollect.SelectedItems.Contains("No"))
            {
                order.ToCollect = 0;
            }

            using (var db = new mssql1903299Entities4())
            {
                
                var record6 = new C_ORDER{ ORDER_ID = Which, Paid = 1, ToCollect = order.ToCollect };
                db.C_ORDER.Attach(record6);
                db.Entry(record6).Property(r => r.Paid).IsModified = true;
                db.Entry(record6).Property(r => r.ToCollect).IsModified = true;
                db.SaveChanges();
            }
            GB.Customer_Calculat_Total(Which);
            //SetOrderView();
            SetProductView();
            MessageBox.Show("the order has been finalised");
            
            textBox1.Text = "Order number";
        }

        private void Customer_Order_settable_Click(object sender, EventArgs e)
        {
            SetOrderView();
            Customer_Spesific_Load_Order.Enabled = true;
        }

        private void Customer_Spesific_Load_Order_Click(object sender, EventArgs e)
        {            
            if (string.IsNullOrEmpty(Cus_S_Order.Text) == true)
            {
                MessageBox.Show("Please enter the id of the order you want to see more about");
                Cus_S_Order.Text = "Num";
                return;
            }
            if (Cus_S_Order.Text == "Num")
            {
                MessageBox.Show("Please enter the id of the order you want to see more about");
                Cus_S_Order.Text = "Num";
                return;
            }
            int Spes = Convert.ToInt32(Cus_S_Order.Text.Trim());
            var Log2 = (from x in db.C_ORDER_CONTAINS
                        where x.Order_Id == Spes
                        select x).ToList();

            Customer_Orders_Grid_View2.AutoGenerateColumns = false;
            Customer_Orders_Grid_View2.DataSource = Log2;
            Cus_S_Order.Text = "Num";
        }

        private void Customer_info_Load_Click(object sender, EventArgs e)
        {
            Customer_Cus_Data_View.AutoGenerateColumns = false;


            Customer_Cus_Data_View.DataSource = (from x in db.CUSTOMERs
                                                 where x.Username == textBox2.Text && x.Pass == textBox3.Text
                                                 select x).ToList(); ;
        }

        private void Search_Click(object sender, EventArgs e)
        {
            string search = Searching.Text.Trim();

            var Log = (from x in db.PRODUCTs
                       where x.Prod_des.Contains(search)
                       select x).ToList();
            Customer_Prod_Data_View.AutoGenerateColumns = false;
            Customer_Prod_Data_View.DataSource = Log;
            Searching.Text = "Search";
        }
    }
}
