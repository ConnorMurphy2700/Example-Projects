﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;  // when accessing the database
using System.Data.SqlTypes;
using System.Data.Entity;


namespace Comic_book_store
{
    public partial class Staff_Page : Form
    {
        public Staff_Page()
        {
            InitializeComponent();
        }

        readonly mssql1903299Entities4 db = new mssql1903299Entities4();
        PRODUCT Product = new PRODUCT();
        CUSTOMER cus = new CUSTOMER();
        C_ORDER order = new C_ORDER();
        C_ORDER_CONTAINS order_con = new C_ORDER_CONTAINS();
        Functions GB = new Functions();
        int EmpId = 0;

        private void Staff_Page_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mssql1903299DataSet28.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            this.c_ORDER_CONTAINSTableAdapter3.Fill(this.mssql1903299DataSet28.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet23.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            this.c_ORDER_CONTAINSTableAdapter2.Fill(this.mssql1903299DataSet23.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet20.C_ORDER' table. You can move, or remove it, as needed.
            this.c_ORDERTableAdapter1.Fill(this.mssql1903299DataSet20.C_ORDER);
            // TODO: This line of code loads data into the 'mssql1903299DataSet17.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            this.c_ORDER_CONTAINSTableAdapter1.Fill(this.mssql1903299DataSet17.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet3.PRODUCT' table. You can move, or remove it, as needed.
            this.pRODUCTTableAdapter.Fill(this.mssql1903299DataSet3.PRODUCT);
            // TODO: This line of code loads data into the 'mssql1903299DataSet2.CUSTOMER' table. You can move, or remove it, as needed.
            //this.cUSTOMERTableAdapter.Fill(this.mssql1903299DataSet2.CUSTOMER);
            // TODO: This line of code loads data into the 'mssql1903299DataSet1.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            this.c_ORDER_CONTAINSTableAdapter.Fill(this.mssql1903299DataSet1.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet.C_ORDER' table. You can move, or remove it, as needed.
            //this.c_ORDERTableAdapter.Fill(this.mssql1903299DataSet.C_ORDER);

        }

        public void ClearDataProduct()
        {
            Staff_Prod_Des.Text = Staff_Prod_Manu.Text = Staff_Prod_Manu.Text = Staff_Prod_name.Text = Staff_Prod_Type.Text = Staff_Prod_Price.Text = string.Empty;
            Staff_Prod_Save.Text = "Save";
            EmpId = 0;
        }


        public void SetProductView()
        {
            Staff_Products_Grid_View.AutoGenerateColumns = false;
            Staff_Products_Grid_View.DataSource = db.PRODUCTs.ToList<PRODUCT>();
        }

 


        private void Staff_Products_Delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this record ?", "Delete ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (string.IsNullOrEmpty(Staff_Product_ID.Text) == true)
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Staff_Product_ID.Text = "Enter Product ID";
                    return;
                }
                if (Staff_Product_ID.Text == "Enter Product ID")
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Staff_Product_ID.Text = "Enter Product ID";
                    return;
                }
                var Product = new PRODUCT();
                Product.Product_ID =Convert.ToInt32(Staff_Product_ID.Text.Trim());
                
                db.PRODUCTs.Attach(Product);
                db.PRODUCTs.Remove(Product);
                db.SaveChanges();
                SetProductView();
                MessageBox.Show("Record Deleted Successfully");
                Staff_Product_ID.Text = "Enter Product ID";
            }
        }

        private void Staff_Prod_Save_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Staff_Prod_name.Text) == true)
            {
                MessageBox.Show("Please enter the name of the new product");
                Staff_Admin_ID.Text = "Enter Product Name";
                return;
            }
            if (Staff_Admin_ID.Text == "Enter Product Name")
            {
                MessageBox.Show("Please enter the name of the new product");
                Staff_Admin_ID.Text = "Enter Product Name";
                return;
            }
            if (string.IsNullOrEmpty(Staff_Prod_Price.Text) == true)
            {
                MessageBox.Show("Please enter the price of the new product");
                Staff_Prod_Price.Text = "Enter Product Price";
                return;
            }
            if (Staff_Prod_Price.Text == "Enter Product Price")
            {
                MessageBox.Show("Please enter the price of the new product");
                Staff_Prod_Price.Text = "Enter Product Price";
                return;
            }
            if (string.IsNullOrEmpty(Staff_Prod_Type.Text) == true)
            {
                MessageBox.Show("Please enter the type of product that the new product is");
                Staff_Prod_Type.Text = "Enter Product Type";
                return;
            }
            if (Staff_Prod_Type.Text == "Enter Product Type")
            {
                MessageBox.Show("Please enter the type of product that the new product is");
                Staff_Prod_Type.Text = "Enter Product Type";
                return;
            }
            if (string.IsNullOrEmpty(Staff_Prod_Stock.Text) == true)
            {
                MessageBox.Show("Please enter the number of items in stock of the new product");
                Staff_Prod_Stock.Text = "Enter Product Stock";
                return;
            }
            if (Staff_Prod_Stock.Text == "Enter Product Stock")
            {
                MessageBox.Show("Please enter the number of items in stock of the new product");
                Staff_Prod_Stock.Text = "Enter Product Stock";
                return;
            }
            Product.Prod_name = Staff_Prod_name.Text.Trim();
            Product.Price = (decimal)Convert.ToDouble(Staff_Prod_Price.Text.Trim());
            Product.Product_Type = Staff_Prod_Type.Text.Trim();
            Product.Prod_des = Staff_Prod_Des.Text.Trim();
            Product.Manufacturer = Staff_Prod_Manu.Text.Trim();
            Product.Stock = Convert.ToInt32(Staff_Prod_Stock.Text.Trim());

            if (EmpId > 0)
                db.Entry(Product).State = EntityState.Modified;
            else
            {
                db.PRODUCTs.Add(Product);
            }
            db.SaveChanges();
            ClearDataProduct();
            SetProductView();
            MessageBox.Show("Record Save Successfully");

            Staff_Prod_Stock.Text = "Enter Product Stock";
            Staff_Prod_Type.Text = "Enter Product Type";
            Staff_Prod_Price.Text = "Enter Product Price";
            Staff_Admin_ID.Text = "Enter Product Name";
            Staff_Prod_Des.Text = "Enter Product Description";
            Staff_Prod_Manu.Text = "Enter Manucacture name";
        }
        private void Check_Inventory_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Staff_Prod_Stock.Text) == true)
            {
                MessageBox.Show("Please enter a number to check the database against");
                Staff_Prod_Stock.Text = "Enter Product Stock";
                return;
            }
            if (Staff_Prod_Stock.Text == "Enter Product Stock")
            {
                MessageBox.Show("Please enter a number to check the database against");
                Staff_Prod_Stock.Text = "Enter Product Stock";
                return;
            }
            int check = Convert.ToInt32(Staff_Prod_Stock.Text);
            GB.Check_Inventory(check);      
            Staff_Prod_Stock.Text = "Enter Product Stock";

        }

        private void Staff_Admin_Submit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Staff_Admin_ID.Text) == true)
            {
                MessageBox.Show("Please enter your password");
                Staff_Admin_ID.Text = "sgbdffda";
                return;
            }
            if (Staff_Admin_ID.Text == "sgbdffda")
            {
                MessageBox.Show("Please enter your password");
                Staff_Admin_ID.Text = "sgbdffda";
                return;
            }
            if (string.IsNullOrEmpty(Staff_Admin_Password.Text) == true)
            {
                MessageBox.Show("Please enter your password");
                Staff_Admin_Password.Text = "Enter your ID";
                return;
            }
            if (Staff_Admin_Password.Text == "Enter your ID")
            {
                MessageBox.Show("Please enter your password");
                Staff_Admin_Password.Text = "Enter your ID";
                return;
            }
            int Admin_UName;
            Admin_UName = Int32.Parse(Staff_Admin_ID.Text);
            if (Admin_UName !=1) 
            {               
                    MessageBox.Show("You enterd incorrect information repeted attempts will result in Deep repercussions");
                    return;                
            };
            string Admin_Pass;
            Admin_Pass = Staff_Admin_Password.Text;
            var test = GB.Staff_Login(Admin_UName, Admin_Pass);

            if (test == true)
            {
                var m = new Staff_Admin();
                m.Show();
                this.Hide();
            }
            Staff_Admin_Password.Text = "Enter your ID";
            Staff_Admin_ID.Text = "sgbdffda";
        }


        public void SetCustomerView()
        {
            Staff_Customer_Grid_View.AutoGenerateColumns = false;
            Staff_Customer_Grid_View.DataSource = db.CUSTOMERs.ToList<CUSTOMER>();
        }

        private void Staff_Cus_Reload_Click(object sender, EventArgs e)
        {
            SetCustomerView();
        }


        private void Staff_Customer_Delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this record ?", "Delete ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (string.IsNullOrEmpty(Staff_cus_text_delete.Text) == true)
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Staff_cus_text_delete.Text = "Enter the email of the account you want to delete";
                    return;
                }
                if (Staff_cus_text_delete.Text == "Enter the email of the account you want to delete")
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Staff_cus_text_delete.Text = "Enter the email of the account you want to delete";
                    return;
                }
                var cus = new CUSTOMER();
                cus.EMAIL = Staff_cus_text_delete.Text.Trim();

                db.CUSTOMERs.Attach(cus);
                db.CUSTOMERs.Remove(cus);
                db.SaveChanges();
                SetCustomerView();
                MessageBox.Show("Record Deleted Successfully");
                Staff_cus_text_delete.Text = "Enter the email of the account you want to delete";
            }
        }

        public void SetOrderView()
        {
            Staff_Orders_Grid_View.AutoGenerateColumns = false;
            Staff_Orders_Grid_View.DataSource = db.C_ORDER.ToList<C_ORDER>();
            Staff_Orders_Grid_View_2.AutoGenerateColumns = false;
            Staff_Orders_Grid_View_2.DataSource = db.C_ORDER.ToList<C_ORDER>();
        }

         private void Staff_Product_Reload_Click(object sender, EventArgs e)
        {
            SetProductView();
        }

        private void Staff_Orders_Reload_Click_1(object sender, EventArgs e)
        {
            SetOrderView();
        }

        private void Staff_Orders_Delete_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this record ?", "Delete ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (string.IsNullOrEmpty(Staff_Order_ID_delete.Text) == true)
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Staff_Order_ID_delete.Text = "Enter the email of the account you want to delete";
                    return;
                }
                if (Staff_Order_ID_delete.Text == "Enter the email of the account you want to delete")
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Staff_Order_ID_delete.Text = "Enter the email of the account you want to delete";
                    return;
                }


                var order = new C_ORDER();
                var order_con = new C_ORDER_CONTAINS();
                order.ORDER_ID = Convert.ToInt32(Staff_Order_ID_delete.Text.Trim());
                int temp = Convert.ToInt32(Staff_Order_ID_delete.Text.Trim());

                int check = (from a in db.C_ORDER
                             where a.ORDER_ID == temp
                             select a.Paid).First();

                if (check == 1)
                {
                    MessageBox.Show("you can not delete a Paid order");
                    Staff_Order_ID_delete.Text = "Enter the email of the account you want to delete";
                    return;
                }
                order_con.Order_Id = Convert.ToInt32(Staff_Order_ID_delete.Text.Trim());
                db.C_ORDER.Attach(order);
                db.C_ORDER.Remove(order);
                db.SaveChanges();
                SetOrderView();
                MessageBox.Show("Record Deleted Successfully");
                Staff_Order_ID_delete.Text = "Enter the email of the account you want to delete";

            }

        }

        private void Staff_Orders_Save_Click_1(object sender, EventArgs e)
        {
            if (order.Paid != 0)
            {
                if (EmpId > 0)
                {
                    db.Entry(order).State = EntityState.Modified;
                    db.Entry(order_con).State = EntityState.Modified;
                }
                db.SaveChanges();
                SetOrderView();
                MessageBox.Show("Record Save Successfully");
            }

            else { MessageBox.Show("This record can not be changed since the order has been paid. "); }

        }

        private void Staff_order_Calculate_Click_1(object sender, EventArgs e)
        {
            GB.Staff_Total_Profit();
        }

        private void Staff_ToCollect_Click_1(object sender, EventArgs e)
        {
            GB.Collection();
        }


    }
    
}
