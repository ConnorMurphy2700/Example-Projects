﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Comic_book_store
{
    public partial class Staff_Admin : Form
    {
        public Staff_Admin()
        {
            InitializeComponent();
        }

        readonly mssql1903299Entities4 db = new mssql1903299Entities4();
        STAFF Admin = new STAFF();
        int EmpId = 0;

        public void ClearDataStaff()
        {
            Staff_Admin_ID.Text = Staff_Admin_Pos.Text = Staff_Admin_Salary.Text = Staff_Admin_FName.Text = Staff_Admin_LName.Text = string.Empty;
            Staff_Admin_Delete.Enabled = false;
            Staff_Admin_Save.Text = "Save";
            EmpId = 0;
        }

        public void SetStaffView()
        {
            Staff_Admin_Grid_View.AutoGenerateColumns = false;
            Staff_Admin_Grid_View.DataSource = db.STAFFs.ToList<STAFF>();
        }

        private void Staff_Admin_Save_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Staff_Admin_ID.Text) == true)
            {
                MessageBox.Show("Please enter the an ID");
                Staff_Admin_ID.Text = "Enter Staff ID";
                return;
            }
            if (Staff_Admin_ID.Text == "Enter Staff ID")
            {
                MessageBox.Show("Please enter the an ID");
                Staff_Admin_ID.Text = "Enter Staff ID";
                return;
            }
            if (string.IsNullOrEmpty(Staff_Admin_Pos.Text) == true)
            {
                MessageBox.Show("Please enter the Position of the new staff menber");
                Staff_Admin_Pos.Text = "Enter Staff Position";
                return;
            }
            if (Staff_Admin_Pos.Text == "Enter Staff Position")
            {
                MessageBox.Show("Please enter the Position of the new staff menber");
                Staff_Admin_Pos.Text = "Enter Staff Position";
                return;
            }
            if (string.IsNullOrEmpty(Staff_Admin_Salary.Text) == true)
            {
                MessageBox.Show("Please enter the Salary of the new member");
                Staff_Admin_Salary.Text = "Enter Staff Salary";
                return;
            }
            if (Staff_Admin_Salary.Text == "Enter Staff Salary")
            {
                MessageBox.Show("Please enter the Salary of the new member");
                Staff_Admin_Salary.Text = "Enter Staff Salary";
                return;
            }
            if (string.IsNullOrEmpty(Staff_Admin_FName.Text) == true)
            {
                MessageBox.Show("Please enter the first name of the new member");
                Staff_Admin_FName.Text = "Enter Staff first Name";
                return;
            }
            if (Staff_Admin_FName.Text == "Enter Staff first Name")
            {
                MessageBox.Show("Please enter the first name of the new member");
                Staff_Admin_FName.Text = "Enter Staff first Name";
                return;
            }
            if (string.IsNullOrEmpty(Staff_Admin_LName.Text) == true)
            {
                MessageBox.Show("Please enter the last name of the new member");
                Staff_Admin_LName.Text = "Enter Staff Last Name";
                return;
            }
            if (Staff_Admin_LName.Text == "Enter Staff Last Name")
            {
                MessageBox.Show("Please enter the last name of the new member");
                Staff_Admin_LName.Text = "Enter Staff Last Name";
                return;
            }
            Admin.Staff_ID = Convert.ToInt32(Staff_Admin_ID.Text.Trim());  
            Admin.Pos = Staff_Admin_Pos.Text.Trim();
            Admin.Salary = (decimal)Convert.ToDouble(Staff_Admin_Salary.Text.Trim());
            Admin.Fname = Staff_Admin_FName.Text.Trim();
            Admin.Lname = Staff_Admin_LName.Text.Trim();
            Admin.Pass = "blue";
            if (EmpId > 0)
                db.Entry(Admin).State = EntityState.Modified;
            else
            {
                db.STAFFs.Add(Admin);
            }
            db.SaveChanges();
            ClearDataStaff();
            SetStaffView();
            MessageBox.Show("Record Save Successfully");

            Staff_Admin_LName.Text = "Enter Staff Last Name";
            Staff_Admin_FName.Text = "Enter Staff first Name";
            Staff_Admin_Salary.Text = "Enter Staff Salary";
            Staff_Admin_Pos.Text = "Enter Staff Position";
            Staff_Admin_ID.Text = "Enter Staff ID";
        }

        private void Staff_Admin_Grid_View_DoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Staff_Admin_Grid_View.CurrentCell.RowIndex != -1)
            {
                EmpId = Convert.ToInt32(Staff_Admin_Grid_View.CurrentRow.Cells[0].Value);
                Admin = db.STAFFs.Where(x => x.Staff_ID == EmpId).FirstOrDefault();
                Staff_Admin_ID.Text = Admin.Staff_ID.ToString();
                Staff_Admin_Pos.Text = Admin.Pos;
                Staff_Admin_Salary.Text = Admin.Salary.ToString();
                Staff_Admin_FName.Text = Admin.Fname;
                Staff_Admin_LName.Text = Admin.Lname;
                Admin.Pass = "blue";

            }
            Staff_Admin_Save.Text = "Update";
            Staff_Admin_Delete.Enabled = true;
        }

        private void Staff_Admin_Delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this record ?", "Delete ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (string.IsNullOrEmpty(Staff_Admin_ID.Text) == true)
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Staff_Admin_ID.Text = "Enter Staff ID";
                    return;
                }
                if (Staff_Admin_ID.Text == "Enter Staff ID")
                {
                    MessageBox.Show("Please enter the id you want to delete");
                    Staff_Admin_ID.Text = "Enter Staff ID";
                    return;
                }
                var Admin = new STAFF();
                Admin.Staff_ID =Convert.ToInt32(Staff_Admin_ID.Text.Trim());
                db.STAFFs.Attach(Admin);
                db.STAFFs.Remove(Admin);
                db.SaveChanges();
                ClearDataStaff();
                SetStaffView();
                MessageBox.Show("Record Deleted Successfully");
                Staff_Admin_ID.Text = "Enter Staff ID";
            }
        }

        private void Staff_Admin_Reload_Click(object sender, EventArgs e)
        {
            SetStaffView();
        }

        private void BackToStaff_Click(object sender, EventArgs e)
        {
            var m = new Staff_Page();
            m.Show();
            this.Hide();
        }

        private void Staff_Admin_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mssql1903299DataSet4.STAFF' table. You can move, or remove it, as needed.
            this.sTAFFTableAdapter.Fill(this.mssql1903299DataSet4.STAFF);

        }


    }
}
