﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace Comic_book_store
{
    public partial class Guest_Page : Form
    {
        public Guest_Page()
        {
            InitializeComponent();
        }

        readonly mssql1903299Entities4 db = new mssql1903299Entities4();
        CUSTOMER CUS = new CUSTOMER();
        Functions GB = new Functions();
        readonly C_ORDER order = new C_ORDER();
        readonly C_ORDER_CONTAINS order_con = new C_ORDER_CONTAINS();
        int EmpId = 0;

        private void Guest_Page_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mssql1903299DataSet27.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            //this.c_ORDER_CONTAINSTableAdapter3.Fill(this.mssql1903299DataSet27.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet25.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            // this.c_ORDER_CONTAINSTableAdapter2.Fill(this.mssql1903299DataSet25.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet22.C_ORDER' table. You can move, or remove it, as needed.
            //this.c_ORDERTableAdapter1.Fill(this.mssql1903299DataSet22.C_ORDER);
            // TODO: This line of code loads data into the 'mssql1903299DataSet16.C_ORDER_CONTAINS' table. You can move, or remove it, as needed.
            //this.c_ORDER_CONTAINSTableAdapter1.Fill(this.mssql1903299DataSet16.C_ORDER_CONTAINS);
            // TODO: This line of code loads data into the 'mssql1903299DataSet5.PRODUCT' table. You can move, or remove it, as needed.
            this.pRODUCTTableAdapter.Fill(this.mssql1903299DataSet5.PRODUCT);

        }

        public void SetProductView()
        {
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = db.PRODUCTs.ToList<PRODUCT>();
        }

        private void Guest_Make_Order_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Guest_Order_Email.Text) == true)
            {
                MessageBox.Show("Please enter the your email");
                Guest_Order_Email.Text = "Enter your email";
                return;
            }
            if (Guest_Order_Email.Text == "Enter your email")
            {
                MessageBox.Show("Please enter the your email");
                Guest_Order_Email.Text = "Enter your email";
                return;
            }
           int basket_id;
            order.ToCollect = 0;
            order.Customer_ID = Guest_Order_Email.Text.Trim();
            CUS.EMAIL = Guest_Order_Email.Text.Trim();

            order.Paid = 0;
            order.Order_Date = DateTime.Now; 
            db.CUSTOMERs.Add(CUS);
            db.C_ORDER.Add(order);
            
            db.SaveChanges();
            basket_id = order.ORDER_ID;
            Guest_Order_ID.Text = basket_id.ToString();
            MessageBox.Show("Basketmade");
            Guest_InBasket.Enabled = true;
            Guest_Order_Email.Text = "Enter your email";
        }

        private void Guest_InBasket_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Guess_Prod_ID.Text) == true)
            {
                MessageBox.Show("Please enter the Product ID");
                Guess_Prod_ID.Text = "Enter the product id of the item you want";
                return;
            }
            if (Guess_Prod_ID.Text == "Enter the product id of the item you want")
            {
                MessageBox.Show("Please enter the Product ID");
                Guess_Prod_ID.Text = "Enter the product id of the item you want";
                return;
            }
            if (string.IsNullOrEmpty(Guest_Prod_Quan.Text) == true)
            {
                MessageBox.Show("Please enter the number of items you want to order");
                Guest_Prod_Quan.Text = "Enter the number of items you want";
                return;
            }
            if (Guest_Prod_Quan.Text == "Enter the number of items you want")
            {
                MessageBox.Show("Please enter the number of items you want to order");
                Guest_Prod_Quan.Text = "Enter the number of items you want";
                return;
            }
            order_con.Order_Id = Convert.ToInt32(Guest_Order_ID.Text.Trim());
            order_con.Product_ID = Convert.ToInt32( Guess_Prod_ID.Text.Trim());
            int id = Convert.ToInt32(Guess_Prod_ID.Text.Trim());
            order_con.Quantity = Convert.ToInt32(Guest_Prod_Quan.Text.Trim());

            var price = (from x in db.PRODUCTs
                         where x.Product_ID == id
                         select x.Price).FirstOrDefault();
           
            order_con.Price= (decimal)Convert.ToDouble(price);
            db.C_ORDER_CONTAINS.Add(order_con);
            db.SaveChanges();

            MessageBox.Show("Record Save Successfully");
            Guest_Prod_Quan.Text = "Enter the number of items you want";
            Guess_Prod_ID.Text = "Enter the product id of the item you want";
        }

        private void Guest_Order_delete_Click(object sender, EventArgs e)
        {

                if (MessageBox.Show("Are you sure you want to delete this record ?", "Delete ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (string.IsNullOrEmpty(Guest_S_Order.Text) == true)
                    {
                        MessageBox.Show("Please enter the id you want to delete");
                        Guest_S_Order.Text = "Order number";
                        return;
                    }
                    if (Guest_S_Order.Text == "Order number")
                    {
                        MessageBox.Show("Please enter the id you want to delete");
                        Guest_S_Order.Text = "Order number";
                        return;
                    }
                    var order = new C_ORDER();
                    order.ORDER_ID = Convert.ToInt32(Guest_S_Order.Text.Trim());
                    int temp = Convert.ToInt32(Guest_S_Order.Text.Trim());

                     int check = (from a in db.C_ORDER
                                  where a.ORDER_ID == temp
                                  select a.Paid).First();

                     if (check == 1)
                     {
                         MessageBox.Show("you can not delete a Paid order");
                         Guest_S_Order.Text = "Order number";
                         return;
                     }

                db.C_ORDER.Attach(order);
                    db.C_ORDER.Remove(order);
                    db.SaveChanges();
                    SetOrderView();
                    MessageBox.Show("Record Deleted Successfully");
                    Guest_S_Order.Text = "Order number";
                }            
        }

        public void SetOrderView()
        {
            if (string.IsNullOrEmpty(Guest_S_Order.Text) == true)
            {
                MessageBox.Show("Please enter the email used to make the order");
                Guest_Email.Text = "Enter the email you used to make the order";
                return;
            }
            if (Guest_Email.Text == "Enter the email you used to make the order")
            {
                MessageBox.Show("Please enter the email used to make the order");
                Guest_Email.Text = "Enter the email you used to make the order";
                return;
            }
            string email;
            email = Guest_Email.Text.Trim();
           
            Guest_Orders_Grid_View.AutoGenerateColumns = false;

            var Log = (from x in db.C_ORDER
                            where x.Customer_ID == email
                            select x).ToList();
            Guest_Orders_Grid_View.DataSource = Log;
            Guest_Email.Text = "Enter the email you used to make the order";
        }

        private void Guest_Order_Save_Click(object sender, EventArgs e)
        {
            if ((order.Paid == 0) && (order.Paid == 0))
            {
                if (EmpId > 0)
                {
                    db.Entry(order).State = EntityState.Modified;
                    db.Entry(order_con).State = EntityState.Modified;
                }
                db.SaveChanges();
                SetOrderView();
                MessageBox.Show("Record Save Successfully");

            }

            else { MessageBox.Show("This record can not be changed since the order has been paid. "); }
        }

        private void Guest_End_Order_Click(object sender, EventArgs e)
        { 
            if (string.IsNullOrEmpty(Pay_order_num.Text) == true)
            {
                MessageBox.Show("Please enter the id of the order you want to complete");
                Pay_order_num.Text = "Order number";
                return;
            }
            if (Pay_order_num.Text == "Order number")
            {
                MessageBox.Show("Please enter the id of the order you want to complete");
                Pay_order_num.Text = "Order number";
                return;
            }
            int Which = Convert.ToInt32(Pay_order_num.Text.Trim());



            if (Guset_Prod_ToCollect.SelectedItems.Contains(""))
            {
                MessageBox.Show("Please select if you want to collect your order in store");
                return;

            }


            else if (Guset_Prod_ToCollect.SelectedItems.Contains("Yes"))
            {
                order.ToCollect = 1;
            }

            else if (Guset_Prod_ToCollect.SelectedItems.Contains("No"))
            {
                order.ToCollect = 0;
            }
            

            using (var db = new mssql1903299Entities4())
            {
                var result = db.C_ORDER.SingleOrDefault(b => b.ORDER_ID == Which);
                if (result != null)
                {
                    result.Paid = 1;
                    result.ToCollect = order.ToCollect;
                    db.SaveChanges();
                }
            }
            GB.Customer_Calculat_Total(Which);
            //SetOrderView();
            SetProductView();
            MessageBox.Show("the order has been finalised");
            Pay_order_num.Text = "Order number";
        }       
        
        private void Guest_Order_settable_Click(object sender, EventArgs e)
        {
            SetOrderView();
            Guest_Load_Spesific_Order.Enabled = true;
        }

        private void Guest_Load_Spesific_Order_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Guest_S_Order.Text) == true)
            {
                MessageBox.Show("Please enter the id of the order you want to see more about");
                Guest_S_Order.Text = "Order number";
                return;
            }
            if (Guest_S_Order.Text == "Order number")
            {
                MessageBox.Show("Please enter the id of the order you want to see more about");
                Guest_S_Order.Text = "Order number";
                return;
            }
            int Spes = Convert.ToInt32(Guest_S_Order.Text.Trim());
            var Log2 = (from x in db.C_ORDER_CONTAINS
                        where x.Order_Id == Spes
                        select x).ToList();

            Guest_Orders_Grid_View2.AutoGenerateColumns = false;
            Guest_Orders_Grid_View2.DataSource = Log2.ToList();
            Guest_S_Order.Text = "Order number";
        }

        private void Guest_Make_Account_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Guest_Cus_Email.Text) == true)
            {
                MessageBox.Show("Please enter Your email");
                Guest_Cus_Email.Text = "Enter your Email";
                return;
            }
            if (Guest_Cus_Email.Text == "Enter your Email")
            {
                MessageBox.Show("Please enter Your email");
                Guest_Cus_Email.Text = "Enter your Email";
                return;
            }
            if (string.IsNullOrEmpty(Guest_Cus_Address.Text) == true)
            {
                MessageBox.Show("Please enter Your full address");
                Guest_Cus_Address.Text = "Enter your Address";
                return;
            }
            if (Guest_Cus_Address.Text == "Enter your Address")
            {
                MessageBox.Show("Please enter Your full address");
                Guest_Cus_Address.Text = "Enter your Address";
                return;
            }
            if (string.IsNullOrEmpty(Guest_Cus_Fname.Text) == true)
            {
                MessageBox.Show("Please enter Your first name");
                Guest_Cus_Fname.Text = "Enter you first name";
                return;
            }
            if (Guest_Cus_Fname.Text == "Enter you first name")
            {
                MessageBox.Show("Please enter Your first name");
                Guest_Cus_Fname.Text = "Enter you first name";
                return;
            }
            if (string.IsNullOrEmpty(Guest_Cus_Lname.Text) == true)
            {
                MessageBox.Show("Please enter Your last name");
                Guest_Cus_Lname.Text = "Enter you last name";
                return;
            }
            if (Guest_Cus_Lname.Text == "Enter you last name")
            {
                MessageBox.Show("Please enter Your last name");
                Guest_Cus_Lname.Text = "Enter you last name";
                return;
            }
            if (string.IsNullOrEmpty(Guest_Cus_Username.Text) == true)
            {
                MessageBox.Show("Please enter Your new username");
                Guest_Cus_Username.Text = "Enter your Username";
                return;
            }
            if (Guest_Cus_Username.Text == "Enter your Username")
            {
                MessageBox.Show("Please enter Your new username");
                Guest_Cus_Username.Text = "Enter your Username";
                return;
            }
            if (string.IsNullOrEmpty(Guest_Cus_Pass.Text) == true)
            {
                MessageBox.Show("Please enter Your new password");
                Guest_Cus_Pass.Text = "Enter your Password";
                return;
            }
            if (Guest_Cus_Pass.Text == "Enter your Password")
            {
                MessageBox.Show("Please enter Your  new password");
                Guest_Cus_Pass.Text = "Enter your Password";
                return;
            }

            CUS.EMAIL = Guest_Cus_Email.Text.Trim();
            CUS.CAddress = Guest_Cus_Address.Text.Trim();
            CUS.Phone_Num = Guest_Cus_Pnum.Text.Trim();
            CUS.Fname = Guest_Cus_Fname.Text.Trim();
            CUS.Lname = Guest_Cus_Lname.Text.Trim();
            CUS.Username = Guest_Cus_Username.Text.Trim();
            CUS.Pass = Guest_Cus_Pass.Text.Trim();


            if (Guest_Cus_Preference.SelectedItems.Contains(""))
            {
                MessageBox.Show("Please select a Preference Option");
                return;

            }


            else if (Guest_Cus_Preference.SelectedItems.Contains("The Simpsons"))
            {
                CUS.pref = "simsons";
            }

            else if (Guest_Cus_Preference.SelectedItems.Contains("The Power Rangers"))
            {
                CUS.pref = "PowerRangers";
            }

            else if (Guest_Cus_Preference.SelectedItems.Contains("The Incradable Hulk"))
            {
                CUS.pref = "Hulk";
            }

            else if (Guest_Cus_Preference.SelectedItems.Contains("The Watchmen"))
            {
                CUS.pref = "OwlMan";
            }

            db.CUSTOMERs.Add(CUS);

            db.SaveChanges();

            MessageBox.Show("Record Save Successfully");
            var m = new Customers_Page(Guest_Cus_Username.Text.Trim(), Guest_Cus_Pass.Text.Trim());
            m.Show();
            this.Hide();
            
            Guest_Cus_Pass.Text = "Enter your Password";
            Guest_Cus_Username.Text = "Enter your Username";
            Guest_Cus_Lname.Text = "Enter you last name";
            Guest_Cus_Fname.Text = "Enter you first name";
            Guest_Cus_Address.Text = "Enter your Address";
            Guest_Cus_Email.Text = "Enter your Email";
        }

        private void Search_Click(object sender, EventArgs e)
        {
            string search = Guest_Search.Text.Trim();

            var Log = (from x in db.PRODUCTs
                       where x.Prod_des.Contains(search)
                       select x).ToList();
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = Log;
            Guest_Search.Text = "Search for a product";
        }

        private void Load_table_Click(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = db.PRODUCTs.ToList<PRODUCT>();
        }
    }
}
