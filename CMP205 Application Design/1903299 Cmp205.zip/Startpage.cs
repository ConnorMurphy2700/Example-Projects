﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;  // when accessing the database
using System.Data.SqlTypes;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Linq;
using System.Threading.Tasks;

namespace Comic_book_store
{
    public partial class Startpage : Form
    {
        public Startpage()
        {
            InitializeComponent();
            Staff_Login.Show();
            Staff_Login.Show();
        }

        Comic_book_store.mssql1903299Entities4 db = new Comic_book_store.mssql1903299Entities4();
        readonly Comic_book_store.STAFF admin = new Comic_book_store.STAFF();
        readonly Comic_book_store.CUSTOMER cus = new Comic_book_store.CUSTOMER();
        Functions GB = new Functions();

        private void Guest_Click(object sender, EventArgs e)
        {
            var m = new Guest_Page();
             m.Show();
             this.Hide();
        }

        private void Submit_customer_Click_1(object sender, EventArgs e)
        { 
            if (string.IsNullOrEmpty(Username_customer.Text) == true)
            {
                MessageBox.Show("Please enter your username");
                Username_customer.Text = "Enter your username";
                return;
            }
            if (Username_customer.Text == "Enter your username")
            {
                MessageBox.Show("Please enter your username");
                Username_customer.Text = "Enter your username";
                return;
            } 
            if (string.IsNullOrEmpty(Password_customer.Text) == true)
            {
                MessageBox.Show("Please enter your username password");
                Password_customer.Text = "dvasdvsdv";
                return;
            }
            if (Password_customer.Text == "dvasdvsdv")
            {
                MessageBox.Show("Please enter your username password");
                Password_customer.Text = "dvasdvsdv";
                return;
            }
            string Customer_Uname;
            Customer_Uname = Username_customer.Text;
            string Customer_Pass;
            Customer_Pass = Password_customer.Text;

            var test = GB.Customer_Login(Customer_Uname,Customer_Pass);

            if(test == true) 
            { 
            var m = new Customers_Page(Customer_Uname,Customer_Pass);
            m.Show();
            this.Hide();
            }
            Password_customer.Text = "dvasdvsdv";
            Username_customer.Text = "Enter your username";
        }

        private void Submit_Staff_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Username_Staff.Text) == true)
            {
                MessageBox.Show("Please enter your username");
                Username_Staff.Text = "Enter your username";
                return;
            }
            if (Username_Staff.Text == "Enter your username")
            {
                MessageBox.Show("Please enter your username");
                Username_Staff.Text = "Enter your username";
                return;
            }
            if (string.IsNullOrEmpty(PassWord_Staff.Text) == true)
            {
                MessageBox.Show("Please enter your username password");
                PassWord_Staff.Text = "sgwesdgsd";
                return;
            }
            if (PassWord_Staff.Text == "sgwesdgsd")
            {
                MessageBox.Show("Please enter your username password");
                PassWord_Staff.Text = "sgwesdgsd";
                return;
            }
            int Staff_UName;
            Staff_UName = Int32.Parse(Username_Staff.Text);
            string Staff_Pass;
            Staff_Pass = PassWord_Staff.Text;

            var test = GB.Staff_Login(Staff_UName, Staff_Pass);
            
            if (test == true)
            {
                var m = new Staff_Page();
                m.Show();
                this.Hide();
            }

            PassWord_Staff.Text = "sgwesdgsd";
            Username_Staff.Text = "Enter your username";
        }
    }
}
