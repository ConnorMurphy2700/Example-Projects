﻿
namespace Comic_book_store
{
    partial class Guest_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Guest_Page));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Guest_Prod_Tab = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Guest_Order_ID = new System.Windows.Forms.TextBox();
            this.Guest_Order_Email = new System.Windows.Forms.TextBox();
            this.Guest_Prod_Quan = new System.Windows.Forms.TextBox();
            this.Guess_Prod_ID = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.stockDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manufacturerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.proddesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pRODUCTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet5 = new Comic_book_store.mssql1903299DataSet5();
            this.Guest_Make_Order = new System.Windows.Forms.Button();
            this.Guest_InBasket = new System.Windows.Forms.Button();
            this.Guest_Customer_Tab = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.Guest_Cus_Preference = new System.Windows.Forms.ListBox();
            this.Guest_Cus_Address = new System.Windows.Forms.TextBox();
            this.Guest_Cus_Lname = new System.Windows.Forms.TextBox();
            this.Guest_Cus_Pass = new System.Windows.Forms.TextBox();
            this.Guest_Cus_Pnum = new System.Windows.Forms.TextBox();
            this.Guest_Cus_Fname = new System.Windows.Forms.TextBox();
            this.Guest_Cus_Username = new System.Windows.Forms.TextBox();
            this.Guest_Cus_Email = new System.Windows.Forms.TextBox();
            this.Guest_Make_Account = new System.Windows.Forms.Button();
            this.Guest_Order_tab = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Guest_S_Order = new System.Windows.Forms.TextBox();
            this.Pay_order_num = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Guest_Load_Spesific_Order = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Guest_End_Order = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Guset_Prod_ToCollect = new System.Windows.Forms.ListBox();
            this.Guest_Order_settable = new System.Windows.Forms.Button();
            this.Guest_Email = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Guest_Order_Save = new System.Windows.Forms.Button();
            this.Guest_Order_delete = new System.Windows.Forms.Button();
            this.Guest_Orders_Grid_View2 = new System.Windows.Forms.DataGridView();
            this.orderIdDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cORDERCONTAINSBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet25 = new Comic_book_store.mssql1903299DataSet25();
            this.Guest_Orders_Grid_View = new System.Windows.Forms.DataGridView();
            this.toCollectDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oRDERIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cORDERBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet22 = new Comic_book_store.mssql1903299DataSet22();
            this.cORDERCONTAINSBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet16 = new Comic_book_store.mssql1903299DataSet16();
            this.cORDERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet6 = new Comic_book_store.mssql1903299DataSet6();
            this.cORDERCONTAINSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet7 = new Comic_book_store.mssql1903299DataSet7();
            this.pRODUCTTableAdapter = new Comic_book_store.mssql1903299DataSet5TableAdapters.PRODUCTTableAdapter();
            this.c_ORDERTableAdapter = new Comic_book_store.mssql1903299DataSet6TableAdapters.C_ORDERTableAdapter();
            this.c_ORDER_CONTAINSTableAdapter = new Comic_book_store.mssql1903299DataSet7TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.c_ORDER_CONTAINSTableAdapter1 = new Comic_book_store.mssql1903299DataSet16TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.c_ORDERTableAdapter1 = new Comic_book_store.mssql1903299DataSet22TableAdapters.C_ORDERTableAdapter();
            this.c_ORDER_CONTAINSTableAdapter2 = new Comic_book_store.mssql1903299DataSet25TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.mssql1903299DataSet27 = new Comic_book_store.mssql1903299DataSet27();
            this.cORDERCONTAINSBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.c_ORDER_CONTAINSTableAdapter3 = new Comic_book_store.mssql1903299DataSet27TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.tabControl1.SuspendLayout();
            this.Guest_Prod_Tab.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet5)).BeginInit();
            this.Guest_Customer_Tab.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Guest_Order_tab.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Guest_Orders_Grid_View2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Guest_Orders_Grid_View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Guest_Prod_Tab);
            this.tabControl1.Controls.Add(this.Guest_Customer_Tab);
            this.tabControl1.Controls.Add(this.Guest_Order_tab);
            this.tabControl1.Location = new System.Drawing.Point(-2, -1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(926, 452);
            this.tabControl1.TabIndex = 0;
            // 
            // Guest_Prod_Tab
            // 
            this.Guest_Prod_Tab.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Guest_Prod_Tab.BackgroundImage")));
            this.Guest_Prod_Tab.Controls.Add(this.panel1);
            this.Guest_Prod_Tab.Location = new System.Drawing.Point(4, 29);
            this.Guest_Prod_Tab.Name = "Guest_Prod_Tab";
            this.Guest_Prod_Tab.Padding = new System.Windows.Forms.Padding(3);
            this.Guest_Prod_Tab.Size = new System.Drawing.Size(918, 419);
            this.Guest_Prod_Tab.TabIndex = 0;
            this.Guest_Prod_Tab.Text = "Products";
            this.Guest_Prod_Tab.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LawnGreen;
            this.panel1.Controls.Add(this.Guest_Order_ID);
            this.panel1.Controls.Add(this.Guest_Order_Email);
            this.panel1.Controls.Add(this.Guest_Prod_Quan);
            this.panel1.Controls.Add(this.Guess_Prod_ID);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.Guest_Make_Order);
            this.panel1.Controls.Add(this.Guest_InBasket);
            this.panel1.Location = new System.Drawing.Point(26, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(866, 360);
            this.panel1.TabIndex = 3;
            // 
            // Guest_Order_ID
            // 
            this.Guest_Order_ID.Location = new System.Drawing.Point(552, 303);
            this.Guest_Order_ID.Name = "Guest_Order_ID";
            this.Guest_Order_ID.Size = new System.Drawing.Size(261, 26);
            this.Guest_Order_ID.TabIndex = 10;
            // 
            // Guest_Order_Email
            // 
            this.Guest_Order_Email.Location = new System.Drawing.Point(17, 317);
            this.Guest_Order_Email.Name = "Guest_Order_Email";
            this.Guest_Order_Email.Size = new System.Drawing.Size(261, 26);
            this.Guest_Order_Email.TabIndex = 9;
            this.Guest_Order_Email.Text = "Enter your email";
            // 
            // Guest_Prod_Quan
            // 
            this.Guest_Prod_Quan.Location = new System.Drawing.Point(382, 242);
            this.Guest_Prod_Quan.Name = "Guest_Prod_Quan";
            this.Guest_Prod_Quan.Size = new System.Drawing.Size(261, 26);
            this.Guest_Prod_Quan.TabIndex = 8;
            this.Guest_Prod_Quan.Text = "Enter the number of items you want";
            // 
            // Guess_Prod_ID
            // 
            this.Guess_Prod_ID.Location = new System.Drawing.Point(17, 242);
            this.Guess_Prod_ID.Name = "Guess_Prod_ID";
            this.Guess_Prod_ID.Size = new System.Drawing.Size(308, 26);
            this.Guess_Prod_ID.TabIndex = 7;
            this.Guess_Prod_ID.Text = "Enter the product id of the item you want";
            this.Guess_Prod_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stockDataGridViewTextBoxColumn,
            this.prodnameDataGridViewTextBoxColumn,
            this.productIDDataGridViewTextBoxColumn,
            this.productTypeDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.manufacturerDataGridViewTextBoxColumn,
            this.proddesDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.pRODUCTBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(860, 216);
            this.dataGridView1.TabIndex = 0;
            // 
            // stockDataGridViewTextBoxColumn
            // 
            this.stockDataGridViewTextBoxColumn.DataPropertyName = "Stock";
            this.stockDataGridViewTextBoxColumn.HeaderText = "Stock";
            this.stockDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stockDataGridViewTextBoxColumn.Name = "stockDataGridViewTextBoxColumn";
            this.stockDataGridViewTextBoxColumn.ReadOnly = true;
            this.stockDataGridViewTextBoxColumn.Width = 150;
            // 
            // prodnameDataGridViewTextBoxColumn
            // 
            this.prodnameDataGridViewTextBoxColumn.DataPropertyName = "Prod_name";
            this.prodnameDataGridViewTextBoxColumn.HeaderText = "Prod_name";
            this.prodnameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.prodnameDataGridViewTextBoxColumn.Name = "prodnameDataGridViewTextBoxColumn";
            this.prodnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.prodnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // productIDDataGridViewTextBoxColumn
            // 
            this.productIDDataGridViewTextBoxColumn.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.productIDDataGridViewTextBoxColumn.Name = "productIDDataGridViewTextBoxColumn";
            this.productIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.productIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // productTypeDataGridViewTextBoxColumn
            // 
            this.productTypeDataGridViewTextBoxColumn.DataPropertyName = "Product_Type";
            this.productTypeDataGridViewTextBoxColumn.HeaderText = "Product_Type";
            this.productTypeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.productTypeDataGridViewTextBoxColumn.Name = "productTypeDataGridViewTextBoxColumn";
            this.productTypeDataGridViewTextBoxColumn.ReadOnly = true;
            this.productTypeDataGridViewTextBoxColumn.Width = 150;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            this.priceDataGridViewTextBoxColumn.Width = 150;
            // 
            // manufacturerDataGridViewTextBoxColumn
            // 
            this.manufacturerDataGridViewTextBoxColumn.DataPropertyName = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn.HeaderText = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.manufacturerDataGridViewTextBoxColumn.Name = "manufacturerDataGridViewTextBoxColumn";
            this.manufacturerDataGridViewTextBoxColumn.ReadOnly = true;
            this.manufacturerDataGridViewTextBoxColumn.Width = 150;
            // 
            // proddesDataGridViewTextBoxColumn
            // 
            this.proddesDataGridViewTextBoxColumn.DataPropertyName = "Prod_des";
            this.proddesDataGridViewTextBoxColumn.HeaderText = "Prod_des";
            this.proddesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.proddesDataGridViewTextBoxColumn.Name = "proddesDataGridViewTextBoxColumn";
            this.proddesDataGridViewTextBoxColumn.ReadOnly = true;
            this.proddesDataGridViewTextBoxColumn.Width = 150;
            // 
            // pRODUCTBindingSource
            // 
            this.pRODUCTBindingSource.DataMember = "PRODUCT";
            this.pRODUCTBindingSource.DataSource = this.mssql1903299DataSet5;
            // 
            // mssql1903299DataSet5
            // 
            this.mssql1903299DataSet5.DataSetName = "mssql1903299DataSet5";
            this.mssql1903299DataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Guest_Make_Order
            // 
            this.Guest_Make_Order.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Guest_Make_Order.Location = new System.Drawing.Point(343, 303);
            this.Guest_Make_Order.Name = "Guest_Make_Order";
            this.Guest_Make_Order.Size = new System.Drawing.Size(137, 54);
            this.Guest_Make_Order.TabIndex = 2;
            this.Guest_Make_Order.Text = "Make Basket";
            this.Guest_Make_Order.UseVisualStyleBackColor = false;
            this.Guest_Make_Order.Click += new System.EventHandler(this.Guest_Make_Order_Click);
            // 
            // Guest_InBasket
            // 
            this.Guest_InBasket.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Guest_InBasket.Enabled = false;
            this.Guest_InBasket.Location = new System.Drawing.Point(698, 242);
            this.Guest_InBasket.Name = "Guest_InBasket";
            this.Guest_InBasket.Size = new System.Drawing.Size(137, 54);
            this.Guest_InBasket.TabIndex = 1;
            this.Guest_InBasket.Text = "Put in Basket";
            this.Guest_InBasket.UseVisualStyleBackColor = false;
            this.Guest_InBasket.Click += new System.EventHandler(this.Guest_InBasket_Click);
            // 
            // Guest_Customer_Tab
            // 
            this.Guest_Customer_Tab.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Guest_Customer_Tab.BackgroundImage")));
            this.Guest_Customer_Tab.Controls.Add(this.panel2);
            this.Guest_Customer_Tab.Location = new System.Drawing.Point(4, 29);
            this.Guest_Customer_Tab.Name = "Guest_Customer_Tab";
            this.Guest_Customer_Tab.Padding = new System.Windows.Forms.Padding(3);
            this.Guest_Customer_Tab.Size = new System.Drawing.Size(918, 419);
            this.Guest_Customer_Tab.TabIndex = 1;
            this.Guest_Customer_Tab.Text = "Make Customer Account";
            this.Guest_Customer_Tab.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LawnGreen;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.Guest_Cus_Preference);
            this.panel2.Controls.Add(this.Guest_Cus_Address);
            this.panel2.Controls.Add(this.Guest_Cus_Lname);
            this.panel2.Controls.Add(this.Guest_Cus_Pass);
            this.panel2.Controls.Add(this.Guest_Cus_Pnum);
            this.panel2.Controls.Add(this.Guest_Cus_Fname);
            this.panel2.Controls.Add(this.Guest_Cus_Username);
            this.panel2.Controls.Add(this.Guest_Cus_Email);
            this.panel2.Controls.Add(this.Guest_Make_Account);
            this.panel2.Location = new System.Drawing.Point(38, 27);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(845, 346);
            this.panel2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(390, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(415, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "Please choose one of these comibook charaters or teams";
            // 
            // Guest_Cus_Preference
            // 
            this.Guest_Cus_Preference.FormattingEnabled = true;
            this.Guest_Cus_Preference.ItemHeight = 20;
            this.Guest_Cus_Preference.Items.AddRange(new object[] {
            "The Simpsons",
            "The Power Rangers",
            "The Incradable Hulk",
            "The Watchmen"});
            this.Guest_Cus_Preference.Location = new System.Drawing.Point(649, 64);
            this.Guest_Cus_Preference.Name = "Guest_Cus_Preference";
            this.Guest_Cus_Preference.Size = new System.Drawing.Size(156, 144);
            this.Guest_Cus_Preference.TabIndex = 8;
            // 
            // Guest_Cus_Address
            // 
            this.Guest_Cus_Address.Location = new System.Drawing.Point(437, 64);
            this.Guest_Cus_Address.Multiline = true;
            this.Guest_Cus_Address.Name = "Guest_Cus_Address";
            this.Guest_Cus_Address.Size = new System.Drawing.Size(186, 150);
            this.Guest_Cus_Address.TabIndex = 7;
            this.Guest_Cus_Address.Text = "Enter your Address";
            // 
            // Guest_Cus_Lname
            // 
            this.Guest_Cus_Lname.Location = new System.Drawing.Point(225, 107);
            this.Guest_Cus_Lname.Name = "Guest_Cus_Lname";
            this.Guest_Cus_Lname.Size = new System.Drawing.Size(173, 26);
            this.Guest_Cus_Lname.TabIndex = 6;
            this.Guest_Cus_Lname.Text = "Enter your last name";
            this.Guest_Cus_Lname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Guest_Cus_Pass
            // 
            this.Guest_Cus_Pass.Location = new System.Drawing.Point(225, 152);
            this.Guest_Cus_Pass.Name = "Guest_Cus_Pass";
            this.Guest_Cus_Pass.Size = new System.Drawing.Size(173, 26);
            this.Guest_Cus_Pass.TabIndex = 5;
            this.Guest_Cus_Pass.Text = "Enter your Password";
            this.Guest_Cus_Pass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Guest_Cus_Pnum
            // 
            this.Guest_Cus_Pnum.Location = new System.Drawing.Point(200, 64);
            this.Guest_Cus_Pnum.Name = "Guest_Cus_Pnum";
            this.Guest_Cus_Pnum.Size = new System.Drawing.Size(211, 26);
            this.Guest_Cus_Pnum.TabIndex = 4;
            this.Guest_Cus_Pnum.Text = "Enter your Phone number";
            this.Guest_Cus_Pnum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Guest_Cus_Fname
            // 
            this.Guest_Cus_Fname.Location = new System.Drawing.Point(32, 107);
            this.Guest_Cus_Fname.Name = "Guest_Cus_Fname";
            this.Guest_Cus_Fname.Size = new System.Drawing.Size(168, 26);
            this.Guest_Cus_Fname.TabIndex = 3;
            this.Guest_Cus_Fname.Text = "Enter you first name";
            this.Guest_Cus_Fname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Guest_Cus_Username
            // 
            this.Guest_Cus_Username.Location = new System.Drawing.Point(32, 152);
            this.Guest_Cus_Username.Name = "Guest_Cus_Username";
            this.Guest_Cus_Username.Size = new System.Drawing.Size(168, 26);
            this.Guest_Cus_Username.TabIndex = 2;
            this.Guest_Cus_Username.Text = "Enter your Username";
            this.Guest_Cus_Username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Guest_Cus_Email
            // 
            this.Guest_Cus_Email.Location = new System.Drawing.Point(32, 64);
            this.Guest_Cus_Email.Name = "Guest_Cus_Email";
            this.Guest_Cus_Email.Size = new System.Drawing.Size(144, 26);
            this.Guest_Cus_Email.TabIndex = 1;
            this.Guest_Cus_Email.Text = "Enter your Email";
            this.Guest_Cus_Email.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Guest_Make_Account
            // 
            this.Guest_Make_Account.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Guest_Make_Account.Location = new System.Drawing.Point(346, 245);
            this.Guest_Make_Account.Name = "Guest_Make_Account";
            this.Guest_Make_Account.Size = new System.Drawing.Size(143, 72);
            this.Guest_Make_Account.TabIndex = 0;
            this.Guest_Make_Account.Text = "Make account";
            this.Guest_Make_Account.UseVisualStyleBackColor = false;
            this.Guest_Make_Account.Click += new System.EventHandler(this.Guest_Make_Account_Click);
            // 
            // Guest_Order_tab
            // 
            this.Guest_Order_tab.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Guest_Order_tab.BackgroundImage")));
            this.Guest_Order_tab.Controls.Add(this.panel3);
            this.Guest_Order_tab.Location = new System.Drawing.Point(4, 29);
            this.Guest_Order_tab.Name = "Guest_Order_tab";
            this.Guest_Order_tab.Size = new System.Drawing.Size(918, 419);
            this.Guest_Order_tab.TabIndex = 2;
            this.Guest_Order_tab.Text = "orders";
            this.Guest_Order_tab.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LawnGreen;
            this.panel3.Controls.Add(this.Guest_S_Order);
            this.panel3.Controls.Add(this.Pay_order_num);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.Guest_Load_Spesific_Order);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.Guest_End_Order);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.Guset_Prod_ToCollect);
            this.panel3.Controls.Add(this.Guest_Order_settable);
            this.panel3.Controls.Add(this.Guest_Email);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.Guest_Order_Save);
            this.panel3.Controls.Add(this.Guest_Order_delete);
            this.panel3.Controls.Add(this.Guest_Orders_Grid_View2);
            this.panel3.Controls.Add(this.Guest_Orders_Grid_View);
            this.panel3.Location = new System.Drawing.Point(10, 17);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(897, 393);
            this.panel3.TabIndex = 0;
            // 
            // Guest_S_Order
            // 
            this.Guest_S_Order.Location = new System.Drawing.Point(204, 326);
            this.Guest_S_Order.Name = "Guest_S_Order";
            this.Guest_S_Order.Size = new System.Drawing.Size(111, 26);
            this.Guest_S_Order.TabIndex = 16;
            this.Guest_S_Order.Text = "Order number";
            // 
            // Pay_order_num
            // 
            this.Pay_order_num.Location = new System.Drawing.Point(442, 355);
            this.Pay_order_num.Name = "Pay_order_num";
            this.Pay_order_num.Size = new System.Drawing.Size(108, 26);
            this.Pay_order_num.TabIndex = 15;
            this.Pay_order_num.Text = "Order number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(147, 245);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 100);
            this.label2.TabIndex = 14;
            this.label2.Text = "select the\r\norder you \r\nwant to\r\n know more\r\n about";
            // 
            // Guest_Load_Spesific_Order
            // 
            this.Guest_Load_Spesific_Order.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Guest_Load_Spesific_Order.Enabled = false;
            this.Guest_Load_Spesific_Order.Location = new System.Drawing.Point(3, 292);
            this.Guest_Load_Spesific_Order.Name = "Guest_Load_Spesific_Order";
            this.Guest_Load_Spesific_Order.Size = new System.Drawing.Size(138, 48);
            this.Guest_Load_Spesific_Order.TabIndex = 13;
            this.Guest_Load_Spesific_Order.Text = "Load order spesifics ";
            this.Guest_Load_Spesific_Order.UseVisualStyleBackColor = false;
            this.Guest_Load_Spesific_Order.Click += new System.EventHandler(this.Guest_Load_Spesific_Order_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(388, 320);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(308, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "please select the order you want to finalise";
            // 
            // Guest_End_Order
            // 
            this.Guest_End_Order.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Guest_End_Order.Location = new System.Drawing.Point(556, 343);
            this.Guest_End_Order.Name = "Guest_End_Order";
            this.Guest_End_Order.Size = new System.Drawing.Size(140, 50);
            this.Guest_End_Order.TabIndex = 11;
            this.Guest_End_Order.Text = "Pay of Order";
            this.Guest_End_Order.UseVisualStyleBackColor = false;
            this.Guest_End_Order.Click += new System.EventHandler(this.Guest_End_Order_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(255, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 80);
            this.label5.TabIndex = 8;
            this.label5.Text = "Do you want\r\n to collect\r\n your order\r\n in store";
            // 
            // Guset_Prod_ToCollect
            // 
            this.Guset_Prod_ToCollect.FormattingEnabled = true;
            this.Guset_Prod_ToCollect.ItemHeight = 20;
            this.Guset_Prod_ToCollect.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.Guset_Prod_ToCollect.Location = new System.Drawing.Point(358, 250);
            this.Guset_Prod_ToCollect.Name = "Guset_Prod_ToCollect";
            this.Guset_Prod_ToCollect.Size = new System.Drawing.Size(45, 44);
            this.Guset_Prod_ToCollect.TabIndex = 7;
            // 
            // Guest_Order_settable
            // 
            this.Guest_Order_settable.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Guest_Order_settable.Location = new System.Drawing.Point(0, 243);
            this.Guest_Order_settable.Name = "Guest_Order_settable";
            this.Guest_Order_settable.Size = new System.Drawing.Size(138, 48);
            this.Guest_Order_settable.TabIndex = 6;
            this.Guest_Order_settable.Text = "Load Your Orders";
            this.Guest_Order_settable.UseVisualStyleBackColor = false;
            this.Guest_Order_settable.Click += new System.EventHandler(this.Guest_Order_settable_Click);
            // 
            // Guest_Email
            // 
            this.Guest_Email.Location = new System.Drawing.Point(13, 355);
            this.Guest_Email.Name = "Guest_Email";
            this.Guest_Email.Size = new System.Drawing.Size(364, 26);
            this.Guest_Email.TabIndex = 5;
            this.Guest_Email.Text = "Enter the email you used to make the order";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(409, 245);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(278, 60);
            this.label4.TabIndex = 4;
            this.label4.Text = "PLEASE do not change the Order ID\r\nthis could cause you to lose your order\r\nand y" +
    "ou will be fined ";
            // 
            // Guest_Order_Save
            // 
            this.Guest_Order_Save.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Guest_Order_Save.Location = new System.Drawing.Point(740, 300);
            this.Guest_Order_Save.Name = "Guest_Order_Save";
            this.Guest_Order_Save.Size = new System.Drawing.Size(138, 48);
            this.Guest_Order_Save.TabIndex = 3;
            this.Guest_Order_Save.Text = "Save Changes";
            this.Guest_Order_Save.UseVisualStyleBackColor = false;
            this.Guest_Order_Save.Click += new System.EventHandler(this.Guest_Order_Save_Click);
            // 
            // Guest_Order_delete
            // 
            this.Guest_Order_delete.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Guest_Order_delete.Location = new System.Drawing.Point(740, 246);
            this.Guest_Order_delete.Name = "Guest_Order_delete";
            this.Guest_Order_delete.Size = new System.Drawing.Size(138, 48);
            this.Guest_Order_delete.TabIndex = 2;
            this.Guest_Order_delete.Text = "Cancel Order";
            this.Guest_Order_delete.UseVisualStyleBackColor = false;
            this.Guest_Order_delete.Click += new System.EventHandler(this.Guest_Order_delete_Click);
            // 
            // Guest_Orders_Grid_View2
            // 
            this.Guest_Orders_Grid_View2.AllowUserToAddRows = false;
            this.Guest_Orders_Grid_View2.AllowUserToOrderColumns = true;
            this.Guest_Orders_Grid_View2.AutoGenerateColumns = false;
            this.Guest_Orders_Grid_View2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Guest_Orders_Grid_View2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderIdDataGridViewTextBoxColumn1,
            this.productIDDataGridViewTextBoxColumn1,
            this.quantityDataGridViewTextBoxColumn});
            this.Guest_Orders_Grid_View2.DataSource = this.cORDERCONTAINSBindingSource3;
            this.Guest_Orders_Grid_View2.Location = new System.Drawing.Point(648, 12);
            this.Guest_Orders_Grid_View2.Name = "Guest_Orders_Grid_View2";
            this.Guest_Orders_Grid_View2.ReadOnly = true;
            this.Guest_Orders_Grid_View2.RowHeadersWidth = 62;
            this.Guest_Orders_Grid_View2.RowTemplate.Height = 28;
            this.Guest_Orders_Grid_View2.Size = new System.Drawing.Size(246, 228);
            this.Guest_Orders_Grid_View2.TabIndex = 1;
            // 
            // orderIdDataGridViewTextBoxColumn1
            // 
            this.orderIdDataGridViewTextBoxColumn1.DataPropertyName = "Order_Id";
            this.orderIdDataGridViewTextBoxColumn1.HeaderText = "Order_Id";
            this.orderIdDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.orderIdDataGridViewTextBoxColumn1.Name = "orderIdDataGridViewTextBoxColumn1";
            this.orderIdDataGridViewTextBoxColumn1.ReadOnly = true;
            this.orderIdDataGridViewTextBoxColumn1.Width = 150;
            // 
            // productIDDataGridViewTextBoxColumn1
            // 
            this.productIDDataGridViewTextBoxColumn1.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.productIDDataGridViewTextBoxColumn1.Name = "productIDDataGridViewTextBoxColumn1";
            this.productIDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.productIDDataGridViewTextBoxColumn1.Width = 150;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.ReadOnly = true;
            this.quantityDataGridViewTextBoxColumn.Width = 150;
            // 
            // cORDERCONTAINSBindingSource2
            // 
            this.cORDERCONTAINSBindingSource2.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource2.DataSource = this.mssql1903299DataSet25;
            // 
            // mssql1903299DataSet25
            // 
            this.mssql1903299DataSet25.DataSetName = "mssql1903299DataSet25";
            this.mssql1903299DataSet25.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Guest_Orders_Grid_View
            // 
            this.Guest_Orders_Grid_View.AllowUserToAddRows = false;
            this.Guest_Orders_Grid_View.AllowUserToOrderColumns = true;
            this.Guest_Orders_Grid_View.AutoGenerateColumns = false;
            this.Guest_Orders_Grid_View.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Guest_Orders_Grid_View.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.toCollectDataGridViewTextBoxColumn,
            this.oRDERIDDataGridViewTextBoxColumn,
            this.customerIDDataGridViewTextBoxColumn,
            this.paidDataGridViewTextBoxColumn,
            this.orderDateDataGridViewTextBoxColumn});
            this.Guest_Orders_Grid_View.DataSource = this.cORDERBindingSource1;
            this.Guest_Orders_Grid_View.Location = new System.Drawing.Point(3, 12);
            this.Guest_Orders_Grid_View.Name = "Guest_Orders_Grid_View";
            this.Guest_Orders_Grid_View.ReadOnly = true;
            this.Guest_Orders_Grid_View.RowHeadersWidth = 62;
            this.Guest_Orders_Grid_View.RowTemplate.Height = 28;
            this.Guest_Orders_Grid_View.Size = new System.Drawing.Size(627, 228);
            this.Guest_Orders_Grid_View.TabIndex = 0;
            // 
            // toCollectDataGridViewTextBoxColumn
            // 
            this.toCollectDataGridViewTextBoxColumn.DataPropertyName = "ToCollect";
            this.toCollectDataGridViewTextBoxColumn.HeaderText = "ToCollect";
            this.toCollectDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.toCollectDataGridViewTextBoxColumn.Name = "toCollectDataGridViewTextBoxColumn";
            this.toCollectDataGridViewTextBoxColumn.ReadOnly = true;
            this.toCollectDataGridViewTextBoxColumn.Width = 150;
            // 
            // oRDERIDDataGridViewTextBoxColumn
            // 
            this.oRDERIDDataGridViewTextBoxColumn.DataPropertyName = "ORDER_ID";
            this.oRDERIDDataGridViewTextBoxColumn.HeaderText = "ORDER_ID";
            this.oRDERIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.oRDERIDDataGridViewTextBoxColumn.Name = "oRDERIDDataGridViewTextBoxColumn";
            this.oRDERIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.oRDERIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            this.customerIDDataGridViewTextBoxColumn.DataPropertyName = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.HeaderText = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            this.customerIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.customerIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // paidDataGridViewTextBoxColumn
            // 
            this.paidDataGridViewTextBoxColumn.DataPropertyName = "Paid";
            this.paidDataGridViewTextBoxColumn.HeaderText = "Paid";
            this.paidDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.paidDataGridViewTextBoxColumn.Name = "paidDataGridViewTextBoxColumn";
            this.paidDataGridViewTextBoxColumn.ReadOnly = true;
            this.paidDataGridViewTextBoxColumn.Width = 150;
            // 
            // orderDateDataGridViewTextBoxColumn
            // 
            this.orderDateDataGridViewTextBoxColumn.DataPropertyName = "Order_Date";
            this.orderDateDataGridViewTextBoxColumn.HeaderText = "Order_Date";
            this.orderDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orderDateDataGridViewTextBoxColumn.Name = "orderDateDataGridViewTextBoxColumn";
            this.orderDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.orderDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // cORDERBindingSource1
            // 
            this.cORDERBindingSource1.DataMember = "C_ORDER";
            this.cORDERBindingSource1.DataSource = this.mssql1903299DataSet22;
            // 
            // mssql1903299DataSet22
            // 
            this.mssql1903299DataSet22.DataSetName = "mssql1903299DataSet22";
            this.mssql1903299DataSet22.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cORDERCONTAINSBindingSource1
            // 
            this.cORDERCONTAINSBindingSource1.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource1.DataSource = this.mssql1903299DataSet16;
            // 
            // mssql1903299DataSet16
            // 
            this.mssql1903299DataSet16.DataSetName = "mssql1903299DataSet16";
            this.mssql1903299DataSet16.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cORDERBindingSource
            // 
            this.cORDERBindingSource.DataMember = "C_ORDER";
            this.cORDERBindingSource.DataSource = this.mssql1903299DataSet6;
            // 
            // mssql1903299DataSet6
            // 
            this.mssql1903299DataSet6.DataSetName = "mssql1903299DataSet6";
            this.mssql1903299DataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cORDERCONTAINSBindingSource
            // 
            this.cORDERCONTAINSBindingSource.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource.DataSource = this.mssql1903299DataSet7;
            // 
            // mssql1903299DataSet7
            // 
            this.mssql1903299DataSet7.DataSetName = "mssql1903299DataSet7";
            this.mssql1903299DataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pRODUCTTableAdapter
            // 
            this.pRODUCTTableAdapter.ClearBeforeFill = true;
            // 
            // c_ORDERTableAdapter
            // 
            this.c_ORDERTableAdapter.ClearBeforeFill = true;
            // 
            // c_ORDER_CONTAINSTableAdapter
            // 
            this.c_ORDER_CONTAINSTableAdapter.ClearBeforeFill = true;
            // 
            // c_ORDER_CONTAINSTableAdapter1
            // 
            this.c_ORDER_CONTAINSTableAdapter1.ClearBeforeFill = true;
            // 
            // c_ORDERTableAdapter1
            // 
            this.c_ORDERTableAdapter1.ClearBeforeFill = true;
            // 
            // c_ORDER_CONTAINSTableAdapter2
            // 
            this.c_ORDER_CONTAINSTableAdapter2.ClearBeforeFill = true;
            // 
            // mssql1903299DataSet27
            // 
            this.mssql1903299DataSet27.DataSetName = "mssql1903299DataSet27";
            this.mssql1903299DataSet27.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cORDERCONTAINSBindingSource3
            // 
            this.cORDERCONTAINSBindingSource3.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource3.DataSource = this.mssql1903299DataSet27;
            // 
            // c_ORDER_CONTAINSTableAdapter3
            // 
            this.c_ORDER_CONTAINSTableAdapter3.ClearBeforeFill = true;
            // 
            // Guest_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SpringGreen;
            this.ClientSize = new System.Drawing.Size(921, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Guest_Page";
            this.Text = "Guest";
            this.Load += new System.EventHandler(this.Guest_Page_Load);
            this.tabControl1.ResumeLayout(false);
            this.Guest_Prod_Tab.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet5)).EndInit();
            this.Guest_Customer_Tab.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.Guest_Order_tab.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Guest_Orders_Grid_View2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Guest_Orders_Grid_View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Guest_Prod_Tab;
        private System.Windows.Forms.TabPage Guest_Customer_Tab;
        private System.Windows.Forms.DataGridView dataGridView1;
        private mssql1903299DataSet5 mssql1903299DataSet5;
        private System.Windows.Forms.BindingSource pRODUCTBindingSource;
        private mssql1903299DataSet5TableAdapters.PRODUCTTableAdapter pRODUCTTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manufacturerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn proddesDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Guest_Make_Order;
        private System.Windows.Forms.Button Guest_InBasket;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox Guest_Cus_Preference;
        private System.Windows.Forms.TextBox Guest_Cus_Address;
        private System.Windows.Forms.TextBox Guest_Cus_Lname;
        private System.Windows.Forms.TextBox Guest_Cus_Pass;
        private System.Windows.Forms.TextBox Guest_Cus_Pnum;
        private System.Windows.Forms.TextBox Guest_Cus_Fname;
        private System.Windows.Forms.TextBox Guest_Cus_Username;
        private System.Windows.Forms.TextBox Guest_Cus_Email;
        private System.Windows.Forms.Button Guest_Make_Account;
        private System.Windows.Forms.TextBox Guest_Order_Email;
        private System.Windows.Forms.TextBox Guest_Prod_Quan;
        private System.Windows.Forms.TextBox Guess_Prod_ID;
        private System.Windows.Forms.TabPage Guest_Order_tab;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView Guest_Orders_Grid_View;
        private mssql1903299DataSet6 mssql1903299DataSet6;
        private System.Windows.Forms.BindingSource cORDERBindingSource;
        private mssql1903299DataSet6TableAdapters.C_ORDERTableAdapter c_ORDERTableAdapter;
        private System.Windows.Forms.DataGridView Guest_Orders_Grid_View2;
        private System.Windows.Forms.DataGridViewTextBoxColumn toCollectDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oRDERIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderDateDataGridViewTextBoxColumn;
        private mssql1903299DataSet7 mssql1903299DataSet7;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource;
        private mssql1903299DataSet7TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Guest_Order_Save;
        private System.Windows.Forms.Button Guest_Order_delete;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIdDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Guest_Order_settable;
        private System.Windows.Forms.Button Guest_End_Order;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox Guset_Prod_ToCollect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Guest_Email;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Guest_Load_Spesific_Order;
        private mssql1903299DataSet16 mssql1903299DataSet16;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource1;
        private mssql1903299DataSet16TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter1;
        private System.Windows.Forms.TextBox Guest_S_Order;
        private System.Windows.Forms.TextBox Pay_order_num;
        private System.Windows.Forms.TextBox Guest_Order_ID;
        private mssql1903299DataSet22 mssql1903299DataSet22;
        private System.Windows.Forms.BindingSource cORDERBindingSource1;
        private mssql1903299DataSet22TableAdapters.C_ORDERTableAdapter c_ORDERTableAdapter1;
        private mssql1903299DataSet25 mssql1903299DataSet25;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource2;
        private mssql1903299DataSet25TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter2;
        private mssql1903299DataSet27 mssql1903299DataSet27;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource3;
        private mssql1903299DataSet27TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter3;
    }
}