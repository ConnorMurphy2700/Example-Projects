﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Comic_book_store
{
    class Functions
    {
        Comic_book_store.mssql1903299Entities3 db = new Comic_book_store.mssql1903299Entities3();
        readonly Comic_book_store.STAFF admin = new Comic_book_store.STAFF();
        readonly Comic_book_store.CUSTOMER cus = new Comic_book_store.CUSTOMER();
        readonly Comic_book_store.PRODUCT Product = new Comic_book_store.PRODUCT();
        readonly Comic_book_store.C_ORDER order = new Comic_book_store.C_ORDER();
        readonly Comic_book_store.C_ORDER_CONTAINS order_con = new Comic_book_store.C_ORDER_CONTAINS();

        public bool Staff_Login(int id, string pass)
        {
            try
            {
                var Log = (from a in db.STAFFs
                           where a.Staff_ID == id && a.Pass == pass
                           select a).First<Comic_book_store.STAFF>();
                
                if (Log != null)
                {
                    return true;
                }

            }

            catch (Exception x)
            {
                MessageBox.Show("You have entered incorrect login information.");
                return false;
            }
            return false;
        }


        public bool Customer_Login(string id, string pass)
        {
            try
            {
                var Log = (from a in db.CUSTOMERs
                           where a.Username == id && a.Pass == pass
                           select a).First<Comic_book_store.CUSTOMER>();

                if (Log != null)
                {
                    return true;
                }

            }

            catch (Exception x)
            {
                MessageBox.Show("You have entered incorrect login information.");
                return false;
            }
            return false;
        }


        public void Customer_Calculat_Total(int o_id)
        {
            List<CalPrice> cal = new List<CalPrice>();
            double Total=0;

            int send = (from e in db.C_ORDER
                        where e.ORDER_ID == o_id
                        select e.ToCollect).First();
          

            if (send == 1 ) { Total += 2.50; }

            var con = (from e in db.C_ORDER_CONTAINS
                       where e.Order_Id == o_id
                       select new CalPrice
                       {
                           Price = (double)e.Price,
                           Quan = e.Quantity
                       }) .ToList();
            cal.AddRange(con);

            foreach (var CalPrice in cal)
            {
                Total += (CalPrice.Price * CalPrice.Quan);
            }

            MessageBox.Show(string.Format("The total price of you order is {0}", Total.ToString()));
          

            cal.Clear();

        }


        public void Staff_Total_Profit()
        {
            List<CalPrice> Staff_cal = new List<CalPrice>();
            List<Used> contains = new List<Used>();
            double Total = 0;

            var include = (from e in db.C_ORDER
                           where e.Paid == 1
                           select new Used
                           {
                               Con = (int)e.ORDER_ID,

                           }).ToList();

            contains.AddRange(include);

            foreach (var Used in contains )
            {
             var con = (from e in db.C_ORDER_CONTAINS
                       where e.Order_Id ==Used.Con
                       select new CalPrice
                       {
                           Price = (double)e.Price,
                           Quan = (double)e.Quantity
                       }).ToList();

            Staff_cal.AddRange(con);       
            
            }

            foreach (var CalPrice in Staff_cal)
            {
                MessageBox.Show(CalPrice.Price.ToString());
                MessageBox.Show(CalPrice.Quan.ToString());
            }

            foreach (var CalPrice in Staff_cal)
            {
                Total += CalPrice.Price * CalPrice.Quan;
            }

            MessageBox.Show(string.Format("The total Profit is {0}", Total.ToString()));

            Staff_cal.Clear();
            contains.Clear();

        }


        public void Collection()
        {
            List<Used> contains = new List<Used>();
            List<PutAsside> Asside = new List<PutAsside>();
                    
            var include = (from e in db.C_ORDER
                           where e.Paid == 1
                           select new Used
                           {
                               Con = (int)e.ORDER_ID,
                               
                           }).ToList();

            contains.AddRange(include);

            foreach (var Used in contains)
            {

                var con = (from e in db.C_ORDER_CONTAINS
                           where e.Order_Id == Used.Con
                           select new PutAsside
                           {
                               ID = (int)e.Product_ID,
                               Quan = (int)e.Quantity
                           }).ToList();

                Asside.AddRange(con);
            }

            foreach (var PutAsside in Asside)
            {
                MessageBox.Show(string.Format("Put asside {0} of {1}", PutAsside.ID.ToString(), PutAsside.Quan));
            }

        }

        public IEnumerable<string> Check_Inventory(int level)
        {
            
            if (level <= 100)
            {
                MessageBox.Show(string.Format("These Products have less than {0} restock will be needed", level.ToString()));

                var newly = from p in db.PRODUCTs
                        where p.Stock >= level
                        select p.ToString();                
                return newly;

            };            

            if (level <= 0)
            {
                MessageBox.Show(string.Format("These product are out of stock"));
                var newly = from p in db.PRODUCTs
                             where p.Stock >= level
                             select p.ToString();
                return newly;
            };
            return null;
        }


        public class CalPrice
        {
            public double Price { get; set; }
            public double Quan { get; set; }
        }

        public class PutAsside
        {
            public int ID { get; set; }
            public int Quan { get; set; }
        }

        public class Used
        {
            public int Con { get; set; }

        }
    }
}
