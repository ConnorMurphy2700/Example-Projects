﻿
namespace Comic_book_store
{
    partial class Staff_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Staff_Product_tab = new System.Windows.Forms.TabPage();
            this.Staff_Product_ID = new System.Windows.Forms.TextBox();
            this.Staff_Prod_name = new System.Windows.Forms.TextBox();
            this.Staff_Prod_Type = new System.Windows.Forms.TextBox();
            this.Staff_Prod_Manu = new System.Windows.Forms.TextBox();
            this.Staff_Prod_Stock = new System.Windows.Forms.TextBox();
            this.Staff_Prod_Des = new System.Windows.Forms.TextBox();
            this.Staff_Prod_Price = new System.Windows.Forms.TextBox();
            this.Check_Inventory = new System.Windows.Forms.Button();
            this.Staff_Prod_Save = new System.Windows.Forms.Button();
            this.Staff_Products_Delete = new System.Windows.Forms.Button();
            this.Staff_Product_Reload = new System.Windows.Forms.Button();
            this.Staff_Products_Grid_View = new System.Windows.Forms.DataGridView();
            this.stockDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manufacturerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.proddesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pRODUCTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet3 = new Comic_book_store.mssql1903299DataSet3();
            this.Staff_Customer_Tab = new System.Windows.Forms.TabPage();
            this.Staff_cus_text_delete = new System.Windows.Forms.TextBox();
            this.Staff_Cus_Reload = new System.Windows.Forms.Button();
            this.Staff_Customer_Delete = new System.Windows.Forms.Button();
            this.Staff_Customer_Grid_View = new System.Windows.Forms.DataGridView();
            this.eMAILDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prefDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cUSTOMERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet2 = new Comic_book_store.mssql1903299DataSet2();
            this.Staff_Order_tab = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.Staff_Order_ID_delete = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Staff_ToCollect = new System.Windows.Forms.Button();
            this.Staff_Orders_Delete = new System.Windows.Forms.Button();
            this.Staff_Orders_Save = new System.Windows.Forms.Button();
            this.Staff_order_Calculate = new System.Windows.Forms.Button();
            this.Staff_Orders_Reload = new System.Windows.Forms.Button();
            this.Staff_Orders_Grid_View_2 = new System.Windows.Forms.DataGridView();
            this.orderIdDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cORDERCONTAINSBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet28 = new Comic_book_store.mssql1903299DataSet28();
            this.Staff_Orders_Grid_View = new System.Windows.Forms.DataGridView();
            this.toCollectDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oRDERIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cORDERBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet20 = new Comic_book_store.mssql1903299DataSet20();
            this.Staff_Admin_Login = new System.Windows.Forms.TabPage();
            this.Staff_Admin_Submit = new System.Windows.Forms.Button();
            this.Staff_Admin_Password = new System.Windows.Forms.TextBox();
            this.Staff_Admin_ID = new System.Windows.Forms.TextBox();
            this.cORDERCONTAINSBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet23 = new Comic_book_store.mssql1903299DataSet23();
            this.cORDERCONTAINSBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet17 = new Comic_book_store.mssql1903299DataSet17();
            this.cORDERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet = new Comic_book_store.mssql1903299DataSet();
            this.cORDERCONTAINSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet1 = new Comic_book_store.mssql1903299DataSet1();
            this.c_ORDERTableAdapter = new Comic_book_store.mssql1903299DataSetTableAdapters.C_ORDERTableAdapter();
            this.c_ORDER_CONTAINSTableAdapter = new Comic_book_store.mssql1903299DataSet1TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.cUSTOMERTableAdapter = new Comic_book_store.mssql1903299DataSet2TableAdapters.CUSTOMERTableAdapter();
            this.pRODUCTTableAdapter = new Comic_book_store.mssql1903299DataSet3TableAdapters.PRODUCTTableAdapter();
            this.c_ORDER_CONTAINSTableAdapter1 = new Comic_book_store.mssql1903299DataSet17TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.c_ORDERTableAdapter1 = new Comic_book_store.mssql1903299DataSet20TableAdapters.C_ORDERTableAdapter();
            this.c_ORDER_CONTAINSTableAdapter2 = new Comic_book_store.mssql1903299DataSet23TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.c_ORDER_CONTAINSTableAdapter3 = new Comic_book_store.mssql1903299DataSet28TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.tabControl1.SuspendLayout();
            this.Staff_Product_tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Staff_Products_Grid_View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet3)).BeginInit();
            this.Staff_Customer_Tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Staff_Customer_Grid_View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet2)).BeginInit();
            this.Staff_Order_tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Staff_Orders_Grid_View_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Staff_Orders_Grid_View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet20)).BeginInit();
            this.Staff_Admin_Login.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Staff_Product_tab);
            this.tabControl1.Controls.Add(this.Staff_Customer_Tab);
            this.tabControl1.Controls.Add(this.Staff_Order_tab);
            this.tabControl1.Controls.Add(this.Staff_Admin_Login);
            this.tabControl1.Location = new System.Drawing.Point(1, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(990, 471);
            this.tabControl1.TabIndex = 0;
            // 
            // Staff_Product_tab
            // 
            this.Staff_Product_tab.BackColor = System.Drawing.Color.Silver;
            this.Staff_Product_tab.Controls.Add(this.Staff_Product_ID);
            this.Staff_Product_tab.Controls.Add(this.Staff_Prod_name);
            this.Staff_Product_tab.Controls.Add(this.Staff_Prod_Type);
            this.Staff_Product_tab.Controls.Add(this.Staff_Prod_Manu);
            this.Staff_Product_tab.Controls.Add(this.Staff_Prod_Stock);
            this.Staff_Product_tab.Controls.Add(this.Staff_Prod_Des);
            this.Staff_Product_tab.Controls.Add(this.Staff_Prod_Price);
            this.Staff_Product_tab.Controls.Add(this.Check_Inventory);
            this.Staff_Product_tab.Controls.Add(this.Staff_Prod_Save);
            this.Staff_Product_tab.Controls.Add(this.Staff_Products_Delete);
            this.Staff_Product_tab.Controls.Add(this.Staff_Product_Reload);
            this.Staff_Product_tab.Controls.Add(this.Staff_Products_Grid_View);
            this.Staff_Product_tab.Location = new System.Drawing.Point(4, 29);
            this.Staff_Product_tab.Name = "Staff_Product_tab";
            this.Staff_Product_tab.Padding = new System.Windows.Forms.Padding(3);
            this.Staff_Product_tab.Size = new System.Drawing.Size(982, 438);
            this.Staff_Product_tab.TabIndex = 0;
            this.Staff_Product_tab.Text = "Products";
            // 
            // Staff_Product_ID
            // 
            this.Staff_Product_ID.Location = new System.Drawing.Point(484, 389);
            this.Staff_Product_ID.Name = "Staff_Product_ID";
            this.Staff_Product_ID.Size = new System.Drawing.Size(135, 26);
            this.Staff_Product_ID.TabIndex = 16;
            this.Staff_Product_ID.Text = "Enter Product ID";
            this.Staff_Product_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Prod_name
            // 
            this.Staff_Prod_name.Location = new System.Drawing.Point(7, 301);
            this.Staff_Prod_name.Name = "Staff_Prod_name";
            this.Staff_Prod_name.Size = new System.Drawing.Size(211, 26);
            this.Staff_Prod_name.TabIndex = 15;
            this.Staff_Prod_name.Text = "Enter Product Name";
            this.Staff_Prod_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Prod_Type
            // 
            this.Staff_Prod_Type.Location = new System.Drawing.Point(224, 301);
            this.Staff_Prod_Type.Name = "Staff_Prod_Type";
            this.Staff_Prod_Type.Size = new System.Drawing.Size(211, 26);
            this.Staff_Prod_Type.TabIndex = 14;
            this.Staff_Prod_Type.Text = "Enter Product Type";
            this.Staff_Prod_Type.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Prod_Manu
            // 
            this.Staff_Prod_Manu.Location = new System.Drawing.Point(7, 333);
            this.Staff_Prod_Manu.Name = "Staff_Prod_Manu";
            this.Staff_Prod_Manu.Size = new System.Drawing.Size(211, 26);
            this.Staff_Prod_Manu.TabIndex = 13;
            this.Staff_Prod_Manu.Text = "Enter Manucacture name";
            this.Staff_Prod_Manu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Prod_Stock
            // 
            this.Staff_Prod_Stock.Location = new System.Drawing.Point(224, 333);
            this.Staff_Prod_Stock.Name = "Staff_Prod_Stock";
            this.Staff_Prod_Stock.Size = new System.Drawing.Size(211, 26);
            this.Staff_Prod_Stock.TabIndex = 12;
            this.Staff_Prod_Stock.Text = "Enter Product Stock";
            this.Staff_Prod_Stock.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Prod_Des
            // 
            this.Staff_Prod_Des.Location = new System.Drawing.Point(7, 370);
            this.Staff_Prod_Des.Multiline = true;
            this.Staff_Prod_Des.Name = "Staff_Prod_Des";
            this.Staff_Prod_Des.Size = new System.Drawing.Size(445, 62);
            this.Staff_Prod_Des.TabIndex = 11;
            this.Staff_Prod_Des.Text = "Enter Product Description";
            this.Staff_Prod_Des.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Prod_Price
            // 
            this.Staff_Prod_Price.Location = new System.Drawing.Point(441, 301);
            this.Staff_Prod_Price.Name = "Staff_Prod_Price";
            this.Staff_Prod_Price.Size = new System.Drawing.Size(193, 26);
            this.Staff_Prod_Price.TabIndex = 10;
            this.Staff_Prod_Price.Text = "Enter Product Price";
            this.Staff_Prod_Price.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Check_Inventory
            // 
            this.Check_Inventory.Location = new System.Drawing.Point(640, 283);
            this.Check_Inventory.Name = "Check_Inventory";
            this.Check_Inventory.Size = new System.Drawing.Size(165, 63);
            this.Check_Inventory.TabIndex = 9;
            this.Check_Inventory.Text = "Check Inventory";
            this.Check_Inventory.UseVisualStyleBackColor = true;
            this.Check_Inventory.Click += new System.EventHandler(this.Check_Inventory_Click);
            // 
            // Staff_Prod_Save
            // 
            this.Staff_Prod_Save.Location = new System.Drawing.Point(640, 352);
            this.Staff_Prod_Save.Name = "Staff_Prod_Save";
            this.Staff_Prod_Save.Size = new System.Drawing.Size(165, 63);
            this.Staff_Prod_Save.TabIndex = 8;
            this.Staff_Prod_Save.Text = "Save";
            this.Staff_Prod_Save.UseVisualStyleBackColor = true;
            this.Staff_Prod_Save.Click += new System.EventHandler(this.Staff_Prod_Save_Click);
            // 
            // Staff_Products_Delete
            // 
            this.Staff_Products_Delete.Location = new System.Drawing.Point(811, 352);
            this.Staff_Products_Delete.Name = "Staff_Products_Delete";
            this.Staff_Products_Delete.Size = new System.Drawing.Size(165, 63);
            this.Staff_Products_Delete.TabIndex = 7;
            this.Staff_Products_Delete.Text = "Delete";
            this.Staff_Products_Delete.UseVisualStyleBackColor = true;
            this.Staff_Products_Delete.Click += new System.EventHandler(this.Staff_Products_Delete_Click);
            // 
            // Staff_Product_Reload
            // 
            this.Staff_Product_Reload.Location = new System.Drawing.Point(811, 283);
            this.Staff_Product_Reload.Name = "Staff_Product_Reload";
            this.Staff_Product_Reload.Size = new System.Drawing.Size(165, 63);
            this.Staff_Product_Reload.TabIndex = 4;
            this.Staff_Product_Reload.Text = "Reload Table";
            this.Staff_Product_Reload.UseVisualStyleBackColor = true;
            this.Staff_Product_Reload.Click += new System.EventHandler(this.Staff_Product_Reload_Click);
            // 
            // Staff_Products_Grid_View
            // 
            this.Staff_Products_Grid_View.AutoGenerateColumns = false;
            this.Staff_Products_Grid_View.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Staff_Products_Grid_View.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stockDataGridViewTextBoxColumn,
            this.prodnameDataGridViewTextBoxColumn,
            this.productIDDataGridViewTextBoxColumn1,
            this.productTypeDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.manufacturerDataGridViewTextBoxColumn,
            this.proddesDataGridViewTextBoxColumn});
            this.Staff_Products_Grid_View.DataSource = this.pRODUCTBindingSource;
            this.Staff_Products_Grid_View.Location = new System.Drawing.Point(-4, 0);
            this.Staff_Products_Grid_View.Name = "Staff_Products_Grid_View";
            this.Staff_Products_Grid_View.RowHeadersWidth = 62;
            this.Staff_Products_Grid_View.RowTemplate.Height = 28;
            this.Staff_Products_Grid_View.Size = new System.Drawing.Size(990, 277);
            this.Staff_Products_Grid_View.TabIndex = 0;
            this.Staff_Products_Grid_View.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Staff_Products_Grid_View_DoubleClick_1);
            // 
            // stockDataGridViewTextBoxColumn
            // 
            this.stockDataGridViewTextBoxColumn.DataPropertyName = "Stock";
            this.stockDataGridViewTextBoxColumn.HeaderText = "Stock";
            this.stockDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stockDataGridViewTextBoxColumn.Name = "stockDataGridViewTextBoxColumn";
            this.stockDataGridViewTextBoxColumn.Width = 150;
            // 
            // prodnameDataGridViewTextBoxColumn
            // 
            this.prodnameDataGridViewTextBoxColumn.DataPropertyName = "Prod_name";
            this.prodnameDataGridViewTextBoxColumn.HeaderText = "Prod_name";
            this.prodnameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.prodnameDataGridViewTextBoxColumn.Name = "prodnameDataGridViewTextBoxColumn";
            this.prodnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // productIDDataGridViewTextBoxColumn1
            // 
            this.productIDDataGridViewTextBoxColumn1.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.productIDDataGridViewTextBoxColumn1.Name = "productIDDataGridViewTextBoxColumn1";
            this.productIDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.productIDDataGridViewTextBoxColumn1.Width = 150;
            // 
            // productTypeDataGridViewTextBoxColumn
            // 
            this.productTypeDataGridViewTextBoxColumn.DataPropertyName = "Product_Type";
            this.productTypeDataGridViewTextBoxColumn.HeaderText = "Product_Type";
            this.productTypeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.productTypeDataGridViewTextBoxColumn.Name = "productTypeDataGridViewTextBoxColumn";
            this.productTypeDataGridViewTextBoxColumn.Width = 150;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.Width = 150;
            // 
            // manufacturerDataGridViewTextBoxColumn
            // 
            this.manufacturerDataGridViewTextBoxColumn.DataPropertyName = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn.HeaderText = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.manufacturerDataGridViewTextBoxColumn.Name = "manufacturerDataGridViewTextBoxColumn";
            this.manufacturerDataGridViewTextBoxColumn.Width = 150;
            // 
            // proddesDataGridViewTextBoxColumn
            // 
            this.proddesDataGridViewTextBoxColumn.DataPropertyName = "Prod_des";
            this.proddesDataGridViewTextBoxColumn.HeaderText = "Prod_des";
            this.proddesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.proddesDataGridViewTextBoxColumn.Name = "proddesDataGridViewTextBoxColumn";
            this.proddesDataGridViewTextBoxColumn.Width = 150;
            // 
            // pRODUCTBindingSource
            // 
            this.pRODUCTBindingSource.DataMember = "PRODUCT";
            this.pRODUCTBindingSource.DataSource = this.mssql1903299DataSet3;
            // 
            // mssql1903299DataSet3
            // 
            this.mssql1903299DataSet3.DataSetName = "mssql1903299DataSet3";
            this.mssql1903299DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Staff_Customer_Tab
            // 
            this.Staff_Customer_Tab.BackColor = System.Drawing.Color.Silver;
            this.Staff_Customer_Tab.Controls.Add(this.Staff_cus_text_delete);
            this.Staff_Customer_Tab.Controls.Add(this.Staff_Cus_Reload);
            this.Staff_Customer_Tab.Controls.Add(this.Staff_Customer_Delete);
            this.Staff_Customer_Tab.Controls.Add(this.Staff_Customer_Grid_View);
            this.Staff_Customer_Tab.Location = new System.Drawing.Point(4, 29);
            this.Staff_Customer_Tab.Name = "Staff_Customer_Tab";
            this.Staff_Customer_Tab.Padding = new System.Windows.Forms.Padding(3);
            this.Staff_Customer_Tab.Size = new System.Drawing.Size(982, 438);
            this.Staff_Customer_Tab.TabIndex = 1;
            this.Staff_Customer_Tab.Text = "Customers";
            // 
            // Staff_cus_text_delete
            // 
            this.Staff_cus_text_delete.Location = new System.Drawing.Point(343, 367);
            this.Staff_cus_text_delete.Name = "Staff_cus_text_delete";
            this.Staff_cus_text_delete.Size = new System.Drawing.Size(397, 26);
            this.Staff_cus_text_delete.TabIndex = 6;
            this.Staff_cus_text_delete.Text = "Enter the email of the account you want to delete";
            this.Staff_cus_text_delete.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Cus_Reload
            // 
            this.Staff_Cus_Reload.Location = new System.Drawing.Point(775, 280);
            this.Staff_Cus_Reload.Name = "Staff_Cus_Reload";
            this.Staff_Cus_Reload.Size = new System.Drawing.Size(165, 63);
            this.Staff_Cus_Reload.TabIndex = 5;
            this.Staff_Cus_Reload.Text = "Reload Table";
            this.Staff_Cus_Reload.UseVisualStyleBackColor = true;
            this.Staff_Cus_Reload.Click += new System.EventHandler(this.Staff_Cus_Reload_Click);
            // 
            // Staff_Customer_Delete
            // 
            this.Staff_Customer_Delete.Location = new System.Drawing.Point(775, 349);
            this.Staff_Customer_Delete.Name = "Staff_Customer_Delete";
            this.Staff_Customer_Delete.Size = new System.Drawing.Size(165, 63);
            this.Staff_Customer_Delete.TabIndex = 4;
            this.Staff_Customer_Delete.Text = "Delete";
            this.Staff_Customer_Delete.UseVisualStyleBackColor = true;
            this.Staff_Customer_Delete.Click += new System.EventHandler(this.Staff_Customer_Delete_Click);
            // 
            // Staff_Customer_Grid_View
            // 
            this.Staff_Customer_Grid_View.AllowUserToAddRows = false;
            this.Staff_Customer_Grid_View.AutoGenerateColumns = false;
            this.Staff_Customer_Grid_View.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Staff_Customer_Grid_View.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.eMAILDataGridViewTextBoxColumn,
            this.cAddressDataGridViewTextBoxColumn,
            this.phoneNumDataGridViewTextBoxColumn,
            this.fnameDataGridViewTextBoxColumn,
            this.lnameDataGridViewTextBoxColumn,
            this.usernameDataGridViewTextBoxColumn,
            this.prefDataGridViewTextBoxColumn});
            this.Staff_Customer_Grid_View.DataSource = this.cUSTOMERBindingSource;
            this.Staff_Customer_Grid_View.Location = new System.Drawing.Point(0, 0);
            this.Staff_Customer_Grid_View.Name = "Staff_Customer_Grid_View";
            this.Staff_Customer_Grid_View.ReadOnly = true;
            this.Staff_Customer_Grid_View.RowHeadersWidth = 62;
            this.Staff_Customer_Grid_View.RowTemplate.Height = 28;
            this.Staff_Customer_Grid_View.Size = new System.Drawing.Size(986, 262);
            this.Staff_Customer_Grid_View.TabIndex = 0;
            // 
            // eMAILDataGridViewTextBoxColumn
            // 
            this.eMAILDataGridViewTextBoxColumn.DataPropertyName = "EMAIL";
            this.eMAILDataGridViewTextBoxColumn.HeaderText = "EMAIL";
            this.eMAILDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.eMAILDataGridViewTextBoxColumn.Name = "eMAILDataGridViewTextBoxColumn";
            this.eMAILDataGridViewTextBoxColumn.ReadOnly = true;
            this.eMAILDataGridViewTextBoxColumn.Width = 150;
            // 
            // cAddressDataGridViewTextBoxColumn
            // 
            this.cAddressDataGridViewTextBoxColumn.DataPropertyName = "CAddress";
            this.cAddressDataGridViewTextBoxColumn.HeaderText = "CAddress";
            this.cAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.cAddressDataGridViewTextBoxColumn.Name = "cAddressDataGridViewTextBoxColumn";
            this.cAddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.cAddressDataGridViewTextBoxColumn.Width = 150;
            // 
            // phoneNumDataGridViewTextBoxColumn
            // 
            this.phoneNumDataGridViewTextBoxColumn.DataPropertyName = "Phone_Num";
            this.phoneNumDataGridViewTextBoxColumn.HeaderText = "Phone_Num";
            this.phoneNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.phoneNumDataGridViewTextBoxColumn.Name = "phoneNumDataGridViewTextBoxColumn";
            this.phoneNumDataGridViewTextBoxColumn.ReadOnly = true;
            this.phoneNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // fnameDataGridViewTextBoxColumn
            // 
            this.fnameDataGridViewTextBoxColumn.DataPropertyName = "Fname";
            this.fnameDataGridViewTextBoxColumn.HeaderText = "Fname";
            this.fnameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.fnameDataGridViewTextBoxColumn.Name = "fnameDataGridViewTextBoxColumn";
            this.fnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.fnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // lnameDataGridViewTextBoxColumn
            // 
            this.lnameDataGridViewTextBoxColumn.DataPropertyName = "Lname";
            this.lnameDataGridViewTextBoxColumn.HeaderText = "Lname";
            this.lnameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.lnameDataGridViewTextBoxColumn.Name = "lnameDataGridViewTextBoxColumn";
            this.lnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.lnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "Username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "Username";
            this.usernameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            this.usernameDataGridViewTextBoxColumn.ReadOnly = true;
            this.usernameDataGridViewTextBoxColumn.Width = 150;
            // 
            // prefDataGridViewTextBoxColumn
            // 
            this.prefDataGridViewTextBoxColumn.DataPropertyName = "pref";
            this.prefDataGridViewTextBoxColumn.HeaderText = "pref";
            this.prefDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.prefDataGridViewTextBoxColumn.Name = "prefDataGridViewTextBoxColumn";
            this.prefDataGridViewTextBoxColumn.ReadOnly = true;
            this.prefDataGridViewTextBoxColumn.Width = 150;
            // 
            // cUSTOMERBindingSource
            // 
            this.cUSTOMERBindingSource.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource.DataSource = this.mssql1903299DataSet2;
            // 
            // mssql1903299DataSet2
            // 
            this.mssql1903299DataSet2.DataSetName = "mssql1903299DataSet2";
            this.mssql1903299DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Staff_Order_tab
            // 
            this.Staff_Order_tab.BackColor = System.Drawing.Color.Silver;
            this.Staff_Order_tab.Controls.Add(this.button1);
            this.Staff_Order_tab.Controls.Add(this.Staff_Order_ID_delete);
            this.Staff_Order_tab.Controls.Add(this.label1);
            this.Staff_Order_tab.Controls.Add(this.Staff_ToCollect);
            this.Staff_Order_tab.Controls.Add(this.Staff_Orders_Delete);
            this.Staff_Order_tab.Controls.Add(this.Staff_Orders_Save);
            this.Staff_Order_tab.Controls.Add(this.Staff_order_Calculate);
            this.Staff_Order_tab.Controls.Add(this.Staff_Orders_Reload);
            this.Staff_Order_tab.Controls.Add(this.Staff_Orders_Grid_View_2);
            this.Staff_Order_tab.Controls.Add(this.Staff_Orders_Grid_View);
            this.Staff_Order_tab.Location = new System.Drawing.Point(4, 29);
            this.Staff_Order_tab.Name = "Staff_Order_tab";
            this.Staff_Order_tab.Size = new System.Drawing.Size(982, 438);
            this.Staff_Order_tab.TabIndex = 2;
            this.Staff_Order_tab.Text = "Orders";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(190, 174);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(165, 63);
            this.button1.TabIndex = 10;
            this.button1.Text = "Calculate Profit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Staff_Order_ID_delete
            // 
            this.Staff_Order_ID_delete.Location = new System.Drawing.Point(453, 349);
            this.Staff_Order_ID_delete.Name = "Staff_Order_ID_delete";
            this.Staff_Order_ID_delete.Size = new System.Drawing.Size(387, 26);
            this.Staff_Order_ID_delete.TabIndex = 9;
            this.Staff_Order_ID_delete.Text = "Enter the ID number of the order you want to delete";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 349);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(359, 60);
            this.label1.TabIndex = 8;
            this.label1.Text = "Staff should be aware that they should be careful \r\nwhen changing order informati" +
    "on some info is vital\r\nto the database\'s continued function\r\n";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Staff_ToCollect
            // 
            this.Staff_ToCollect.Location = new System.Drawing.Point(7, 265);
            this.Staff_ToCollect.Name = "Staff_ToCollect";
            this.Staff_ToCollect.Size = new System.Drawing.Size(165, 63);
            this.Staff_ToCollect.TabIndex = 7;
            this.Staff_ToCollect.Text = "Find Stock to put aside";
            this.Staff_ToCollect.UseVisualStyleBackColor = true;
            this.Staff_ToCollect.Click += new System.EventHandler(this.Staff_ToCollect_Click_1);
            // 
            // Staff_Orders_Delete
            // 
            this.Staff_Orders_Delete.Location = new System.Drawing.Point(561, 265);
            this.Staff_Orders_Delete.Name = "Staff_Orders_Delete";
            this.Staff_Orders_Delete.Size = new System.Drawing.Size(165, 63);
            this.Staff_Orders_Delete.TabIndex = 6;
            this.Staff_Orders_Delete.Text = "Delete";
            this.Staff_Orders_Delete.UseVisualStyleBackColor = true;
            this.Staff_Orders_Delete.Click += new System.EventHandler(this.Staff_Orders_Delete_Click_1);
            // 
            // Staff_Orders_Save
            // 
            this.Staff_Orders_Save.Location = new System.Drawing.Point(375, 265);
            this.Staff_Orders_Save.Name = "Staff_Orders_Save";
            this.Staff_Orders_Save.Size = new System.Drawing.Size(165, 63);
            this.Staff_Orders_Save.TabIndex = 5;
            this.Staff_Orders_Save.Text = "Save";
            this.Staff_Orders_Save.UseVisualStyleBackColor = true;
            this.Staff_Orders_Save.Click += new System.EventHandler(this.Staff_Orders_Save_Click_1);
            // 
            // Staff_order_Calculate
            // 
            this.Staff_order_Calculate.Location = new System.Drawing.Point(190, 265);
            this.Staff_order_Calculate.Name = "Staff_order_Calculate";
            this.Staff_order_Calculate.Size = new System.Drawing.Size(165, 63);
            this.Staff_order_Calculate.TabIndex = 4;
            this.Staff_order_Calculate.Text = "Calculate Profit";
            this.Staff_order_Calculate.UseVisualStyleBackColor = true;
            this.Staff_order_Calculate.Click += new System.EventHandler(this.Staff_order_Calculate_Click_1);
            // 
            // Staff_Orders_Reload
            // 
            this.Staff_Orders_Reload.Location = new System.Drawing.Point(753, 265);
            this.Staff_Orders_Reload.Name = "Staff_Orders_Reload";
            this.Staff_Orders_Reload.Size = new System.Drawing.Size(165, 63);
            this.Staff_Orders_Reload.TabIndex = 3;
            this.Staff_Orders_Reload.Text = "Reload Table";
            this.Staff_Orders_Reload.UseVisualStyleBackColor = true;
            this.Staff_Orders_Reload.Click += new System.EventHandler(this.Staff_Orders_Reload_Click_1);
            // 
            // Staff_Orders_Grid_View_2
            // 
            this.Staff_Orders_Grid_View_2.AllowUserToAddRows = false;
            this.Staff_Orders_Grid_View_2.AutoGenerateColumns = false;
            this.Staff_Orders_Grid_View_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Staff_Orders_Grid_View_2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderIdDataGridViewTextBoxColumn1,
            this.productIDDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn});
            this.Staff_Orders_Grid_View_2.DataSource = this.cORDERCONTAINSBindingSource3;
            this.Staff_Orders_Grid_View_2.Location = new System.Drawing.Point(636, 3);
            this.Staff_Orders_Grid_View_2.Name = "Staff_Orders_Grid_View_2";
            this.Staff_Orders_Grid_View_2.RowHeadersWidth = 62;
            this.Staff_Orders_Grid_View_2.RowTemplate.Height = 28;
            this.Staff_Orders_Grid_View_2.Size = new System.Drawing.Size(343, 247);
            this.Staff_Orders_Grid_View_2.TabIndex = 1;
            // 
            // orderIdDataGridViewTextBoxColumn1
            // 
            this.orderIdDataGridViewTextBoxColumn1.DataPropertyName = "Order_Id";
            this.orderIdDataGridViewTextBoxColumn1.HeaderText = "Order_Id";
            this.orderIdDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.orderIdDataGridViewTextBoxColumn1.Name = "orderIdDataGridViewTextBoxColumn1";
            this.orderIdDataGridViewTextBoxColumn1.Width = 150;
            // 
            // productIDDataGridViewTextBoxColumn
            // 
            this.productIDDataGridViewTextBoxColumn.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.productIDDataGridViewTextBoxColumn.Name = "productIDDataGridViewTextBoxColumn";
            this.productIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.Width = 150;
            // 
            // cORDERCONTAINSBindingSource3
            // 
            this.cORDERCONTAINSBindingSource3.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource3.DataSource = this.mssql1903299DataSet28;
            // 
            // mssql1903299DataSet28
            // 
            this.mssql1903299DataSet28.DataSetName = "mssql1903299DataSet28";
            this.mssql1903299DataSet28.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Staff_Orders_Grid_View
            // 
            this.Staff_Orders_Grid_View.AllowUserToAddRows = false;
            this.Staff_Orders_Grid_View.AutoGenerateColumns = false;
            this.Staff_Orders_Grid_View.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Staff_Orders_Grid_View.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.toCollectDataGridViewTextBoxColumn,
            this.oRDERIDDataGridViewTextBoxColumn,
            this.customerIDDataGridViewTextBoxColumn,
            this.paidDataGridViewTextBoxColumn,
            this.orderDateDataGridViewTextBoxColumn});
            this.Staff_Orders_Grid_View.DataSource = this.cORDERBindingSource1;
            this.Staff_Orders_Grid_View.Location = new System.Drawing.Point(3, 3);
            this.Staff_Orders_Grid_View.Name = "Staff_Orders_Grid_View";
            this.Staff_Orders_Grid_View.RowHeadersWidth = 62;
            this.Staff_Orders_Grid_View.RowTemplate.Height = 28;
            this.Staff_Orders_Grid_View.Size = new System.Drawing.Size(627, 247);
            this.Staff_Orders_Grid_View.TabIndex = 0;
            // 
            // toCollectDataGridViewTextBoxColumn
            // 
            this.toCollectDataGridViewTextBoxColumn.DataPropertyName = "ToCollect";
            this.toCollectDataGridViewTextBoxColumn.HeaderText = "ToCollect";
            this.toCollectDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.toCollectDataGridViewTextBoxColumn.Name = "toCollectDataGridViewTextBoxColumn";
            this.toCollectDataGridViewTextBoxColumn.Width = 150;
            // 
            // oRDERIDDataGridViewTextBoxColumn
            // 
            this.oRDERIDDataGridViewTextBoxColumn.DataPropertyName = "ORDER_ID";
            this.oRDERIDDataGridViewTextBoxColumn.HeaderText = "ORDER_ID";
            this.oRDERIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.oRDERIDDataGridViewTextBoxColumn.Name = "oRDERIDDataGridViewTextBoxColumn";
            this.oRDERIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.oRDERIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            this.customerIDDataGridViewTextBoxColumn.DataPropertyName = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.HeaderText = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            this.customerIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // paidDataGridViewTextBoxColumn
            // 
            this.paidDataGridViewTextBoxColumn.DataPropertyName = "Paid";
            this.paidDataGridViewTextBoxColumn.HeaderText = "Paid";
            this.paidDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.paidDataGridViewTextBoxColumn.Name = "paidDataGridViewTextBoxColumn";
            this.paidDataGridViewTextBoxColumn.Width = 150;
            // 
            // orderDateDataGridViewTextBoxColumn
            // 
            this.orderDateDataGridViewTextBoxColumn.DataPropertyName = "Order_Date";
            this.orderDateDataGridViewTextBoxColumn.HeaderText = "Order_Date";
            this.orderDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orderDateDataGridViewTextBoxColumn.Name = "orderDateDataGridViewTextBoxColumn";
            this.orderDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // cORDERBindingSource1
            // 
            this.cORDERBindingSource1.DataMember = "C_ORDER";
            this.cORDERBindingSource1.DataSource = this.mssql1903299DataSet20;
            // 
            // mssql1903299DataSet20
            // 
            this.mssql1903299DataSet20.DataSetName = "mssql1903299DataSet20";
            this.mssql1903299DataSet20.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Staff_Admin_Login
            // 
            this.Staff_Admin_Login.BackColor = System.Drawing.Color.Silver;
            this.Staff_Admin_Login.Controls.Add(this.Staff_Admin_Submit);
            this.Staff_Admin_Login.Controls.Add(this.Staff_Admin_Password);
            this.Staff_Admin_Login.Controls.Add(this.Staff_Admin_ID);
            this.Staff_Admin_Login.Location = new System.Drawing.Point(4, 29);
            this.Staff_Admin_Login.Name = "Staff_Admin_Login";
            this.Staff_Admin_Login.Size = new System.Drawing.Size(982, 438);
            this.Staff_Admin_Login.TabIndex = 3;
            this.Staff_Admin_Login.Text = "Admin Login";
            // 
            // Staff_Admin_Submit
            // 
            this.Staff_Admin_Submit.Location = new System.Drawing.Point(375, 282);
            this.Staff_Admin_Submit.Name = "Staff_Admin_Submit";
            this.Staff_Admin_Submit.Size = new System.Drawing.Size(211, 63);
            this.Staff_Admin_Submit.TabIndex = 2;
            this.Staff_Admin_Submit.Text = "Submit";
            this.Staff_Admin_Submit.UseVisualStyleBackColor = true;
            this.Staff_Admin_Submit.Click += new System.EventHandler(this.Staff_Admin_Submit_Click);
            // 
            // Staff_Admin_Password
            // 
            this.Staff_Admin_Password.Location = new System.Drawing.Point(375, 173);
            this.Staff_Admin_Password.Name = "Staff_Admin_Password";
            this.Staff_Admin_Password.PasswordChar = '*';
            this.Staff_Admin_Password.Size = new System.Drawing.Size(211, 26);
            this.Staff_Admin_Password.TabIndex = 1;
            this.Staff_Admin_Password.Text = "sgbdffda";
            this.Staff_Admin_Password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Admin_ID
            // 
            this.Staff_Admin_ID.Location = new System.Drawing.Point(375, 114);
            this.Staff_Admin_ID.Name = "Staff_Admin_ID";
            this.Staff_Admin_ID.Size = new System.Drawing.Size(211, 26);
            this.Staff_Admin_ID.TabIndex = 0;
            this.Staff_Admin_ID.Text = "Enter your ID";
            this.Staff_Admin_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cORDERCONTAINSBindingSource2
            // 
            this.cORDERCONTAINSBindingSource2.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource2.DataSource = this.mssql1903299DataSet23;
            // 
            // mssql1903299DataSet23
            // 
            this.mssql1903299DataSet23.DataSetName = "mssql1903299DataSet23";
            this.mssql1903299DataSet23.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cORDERCONTAINSBindingSource1
            // 
            this.cORDERCONTAINSBindingSource1.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource1.DataSource = this.mssql1903299DataSet17;
            // 
            // mssql1903299DataSet17
            // 
            this.mssql1903299DataSet17.DataSetName = "mssql1903299DataSet17";
            this.mssql1903299DataSet17.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cORDERBindingSource
            // 
            this.cORDERBindingSource.DataMember = "C_ORDER";
            this.cORDERBindingSource.DataSource = this.mssql1903299DataSet;
            // 
            // mssql1903299DataSet
            // 
            this.mssql1903299DataSet.DataSetName = "mssql1903299DataSet";
            this.mssql1903299DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cORDERCONTAINSBindingSource
            // 
            this.cORDERCONTAINSBindingSource.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource.DataSource = this.mssql1903299DataSet1;
            // 
            // mssql1903299DataSet1
            // 
            this.mssql1903299DataSet1.DataSetName = "mssql1903299DataSet1";
            this.mssql1903299DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // c_ORDERTableAdapter
            // 
            this.c_ORDERTableAdapter.ClearBeforeFill = true;
            // 
            // c_ORDER_CONTAINSTableAdapter
            // 
            this.c_ORDER_CONTAINSTableAdapter.ClearBeforeFill = true;
            // 
            // cUSTOMERTableAdapter
            // 
            this.cUSTOMERTableAdapter.ClearBeforeFill = true;
            // 
            // pRODUCTTableAdapter
            // 
            this.pRODUCTTableAdapter.ClearBeforeFill = true;
            // 
            // c_ORDER_CONTAINSTableAdapter1
            // 
            this.c_ORDER_CONTAINSTableAdapter1.ClearBeforeFill = true;
            // 
            // c_ORDERTableAdapter1
            // 
            this.c_ORDERTableAdapter1.ClearBeforeFill = true;
            // 
            // c_ORDER_CONTAINSTableAdapter2
            // 
            this.c_ORDER_CONTAINSTableAdapter2.ClearBeforeFill = true;
            // 
            // c_ORDER_CONTAINSTableAdapter3
            // 
            this.c_ORDER_CONTAINSTableAdapter3.ClearBeforeFill = true;
            // 
            // Staff_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(993, 471);
            this.Controls.Add(this.tabControl1);
            this.Name = "Staff_Page";
            this.Text = "Staff";
            this.Load += new System.EventHandler(this.Staff_Page_Load);
            this.tabControl1.ResumeLayout(false);
            this.Staff_Product_tab.ResumeLayout(false);
            this.Staff_Product_tab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Staff_Products_Grid_View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet3)).EndInit();
            this.Staff_Customer_Tab.ResumeLayout(false);
            this.Staff_Customer_Tab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Staff_Customer_Grid_View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet2)).EndInit();
            this.Staff_Order_tab.ResumeLayout(false);
            this.Staff_Order_tab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Staff_Orders_Grid_View_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Staff_Orders_Grid_View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet20)).EndInit();
            this.Staff_Admin_Login.ResumeLayout(false);
            this.Staff_Admin_Login.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Staff_Product_tab;
        private System.Windows.Forms.TabPage Staff_Customer_Tab;
        private System.Windows.Forms.TabPage Staff_Order_tab;
        private System.Windows.Forms.DataGridView Staff_Orders_Grid_View;
        private System.Windows.Forms.TabPage Staff_Admin_Login;
        private System.Windows.Forms.Button Staff_Admin_Submit;
        private System.Windows.Forms.TextBox Staff_Admin_Password;
        private System.Windows.Forms.TextBox Staff_Admin_ID;
        private mssql1903299DataSet mssql1903299DataSet;
        private System.Windows.Forms.BindingSource cORDERBindingSource;
        private mssql1903299DataSetTableAdapters.C_ORDERTableAdapter c_ORDERTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn toCollectDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oRDERIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView Staff_Orders_Grid_View_2;
        private mssql1903299DataSet1 mssql1903299DataSet1;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource;
        private mssql1903299DataSet1TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIdDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Staff_ToCollect;
        private System.Windows.Forms.Button Staff_Orders_Delete;
        private System.Windows.Forms.Button Staff_Orders_Save;
        private System.Windows.Forms.Button Staff_order_Calculate;
        private System.Windows.Forms.Button Staff_Orders_Reload;
        private System.Windows.Forms.DataGridView Staff_Customer_Grid_View;
        private mssql1903299DataSet2 mssql1903299DataSet2;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource;
        private mssql1903299DataSet2TableAdapters.CUSTOMERTableAdapter cUSTOMERTableAdapter;
        private System.Windows.Forms.DataGridView Staff_Products_Grid_View;
        private System.Windows.Forms.Button Staff_Cus_Reload;
        private System.Windows.Forms.Button Staff_Customer_Delete;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMAILDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prefDataGridViewTextBoxColumn;
        private mssql1903299DataSet3 mssql1903299DataSet3;
        private System.Windows.Forms.BindingSource pRODUCTBindingSource;
        private mssql1903299DataSet3TableAdapters.PRODUCTTableAdapter pRODUCTTableAdapter;
        private System.Windows.Forms.TextBox Staff_Prod_name;
        private System.Windows.Forms.TextBox Staff_Prod_Type;
        private System.Windows.Forms.TextBox Staff_Prod_Manu;
        private System.Windows.Forms.TextBox Staff_Prod_Stock;
        private System.Windows.Forms.TextBox Staff_Prod_Des;
        private System.Windows.Forms.TextBox Staff_Prod_Price;
        private System.Windows.Forms.Button Check_Inventory;
        private System.Windows.Forms.Button Staff_Prod_Save;
        private System.Windows.Forms.Button Staff_Products_Delete;
        private System.Windows.Forms.Button Staff_Product_Reload;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn productTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manufacturerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn proddesDataGridViewTextBoxColumn;
        private mssql1903299DataSet17 mssql1903299DataSet17;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource1;
        private mssql1903299DataSet17TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter1;
        private System.Windows.Forms.TextBox Staff_cus_text_delete;
        private System.Windows.Forms.TextBox Staff_Order_ID_delete;
        private System.Windows.Forms.TextBox Staff_Product_ID;
        private mssql1903299DataSet20 mssql1903299DataSet20;
        private System.Windows.Forms.BindingSource cORDERBindingSource1;
        private mssql1903299DataSet20TableAdapters.C_ORDERTableAdapter c_ORDERTableAdapter1;
        private mssql1903299DataSet23 mssql1903299DataSet23;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource2;
        private mssql1903299DataSet23TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter2;
        private mssql1903299DataSet28 mssql1903299DataSet28;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource3;
        private mssql1903299DataSet28TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter3;
        private System.Windows.Forms.Button button1;
    }
}