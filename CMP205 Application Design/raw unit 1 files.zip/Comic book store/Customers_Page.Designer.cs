﻿
namespace Comic_book_store
{
    partial class Customers_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customers_Page));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Cus_Order_ID = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Cus_Show_All_prod = new System.Windows.Forms.Button();
            this.Cus_Recomend = new System.Windows.Forms.Button();
            this.Customer_Prod_Quan = new System.Windows.Forms.TextBox();
            this.Customer_Prod_ID = new System.Windows.Forms.TextBox();
            this.Customer_Make_Order = new System.Windows.Forms.Button();
            this.Customer_InBasket = new System.Windows.Forms.Button();
            this.Customer_Prod_Data_View = new System.Windows.Forms.DataGridView();
            this.stockDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manufacturerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.proddesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pRODUCTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet11 = new Comic_book_store.mssql1903299DataSet11();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Account_Del = new System.Windows.Forms.TextBox();
            this.Customer_CUS_Delete = new System.Windows.Forms.Button();
            this.Customer_CUS_Save = new System.Windows.Forms.Button();
            this.Customer_Cus_Data_View = new System.Windows.Forms.DataGridView();
            this.eMAILDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prefDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cUSTOMERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet12 = new Comic_book_store.mssql1903299DataSet12();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Cus_S_Order = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Customer_Spesific_Load_Order = new System.Windows.Forms.Button();
            this.Customer_End_Order = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Customer_Prod_ToCollect = new System.Windows.Forms.ListBox();
            this.Customer_Order_settable = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.Customer_Order_Save = new System.Windows.Forms.Button();
            this.Customer_Order_delete = new System.Windows.Forms.Button();
            this.Customer_Orders_Grid_View2 = new System.Windows.Forms.DataGridView();
            this.orderIdDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cORDERCONTAINSBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet24 = new Comic_book_store.mssql1903299DataSet24();
            this.Customer_Orders_Grid_View = new System.Windows.Forms.DataGridView();
            this.toCollectDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oRDERIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cORDERBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet21 = new Comic_book_store.mssql1903299DataSet21();
            this.cORDERCONTAINSBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet18 = new Comic_book_store.mssql1903299DataSet18();
            this.cORDERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet14 = new Comic_book_store.mssql1903299DataSet14();
            this.cORDERCONTAINSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet15 = new Comic_book_store.mssql1903299DataSet15();
            this.pRODUCTTableAdapter = new Comic_book_store.mssql1903299DataSet11TableAdapters.PRODUCTTableAdapter();
            this.cUSTOMERTableAdapter = new Comic_book_store.mssql1903299DataSet12TableAdapters.CUSTOMERTableAdapter();
            this.c_ORDERTableAdapter = new Comic_book_store.mssql1903299DataSet14TableAdapters.C_ORDERTableAdapter();
            this.c_ORDER_CONTAINSTableAdapter = new Comic_book_store.mssql1903299DataSet15TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.c_ORDER_CONTAINSTableAdapter1 = new Comic_book_store.mssql1903299DataSet18TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.c_ORDERTableAdapter1 = new Comic_book_store.mssql1903299DataSet21TableAdapters.C_ORDERTableAdapter();
            this.c_ORDER_CONTAINSTableAdapter2 = new Comic_book_store.mssql1903299DataSet24TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.Customer_info_Load = new System.Windows.Forms.Button();
            this.mssql1903299DataSet26 = new Comic_book_store.mssql1903299DataSet26();
            this.cORDERCONTAINSBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.c_ORDER_CONTAINSTableAdapter3 = new Comic_book_store.mssql1903299DataSet26TableAdapters.C_ORDER_CONTAINSTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_Prod_Data_View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet11)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_Cus_Data_View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet12)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_Orders_Grid_View2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_Orders_Grid_View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(-3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1008, 455);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage1.BackgroundImage")));
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1000, 422);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Product";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LawnGreen;
            this.panel1.Controls.Add(this.Cus_Order_ID);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.Cus_Show_All_prod);
            this.panel1.Controls.Add(this.Cus_Recomend);
            this.panel1.Controls.Add(this.Customer_Prod_Quan);
            this.panel1.Controls.Add(this.Customer_Prod_ID);
            this.panel1.Controls.Add(this.Customer_Make_Order);
            this.panel1.Controls.Add(this.Customer_InBasket);
            this.panel1.Controls.Add(this.Customer_Prod_Data_View);
            this.panel1.Location = new System.Drawing.Point(30, 26);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(947, 371);
            this.panel1.TabIndex = 0;
            // 
            // Cus_Order_ID
            // 
            this.Cus_Order_ID.Location = new System.Drawing.Point(665, 306);
            this.Cus_Order_ID.Name = "Cus_Order_ID";
            this.Cus_Order_ID.Size = new System.Drawing.Size(100, 26);
            this.Cus_Order_ID.TabIndex = 14;
            this.Cus_Order_ID.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(549, 306);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 26);
            this.textBox3.TabIndex = 13;
            this.textBox3.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(443, 306);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 26);
            this.textBox2.TabIndex = 12;
            this.textBox2.Visible = false;
            // 
            // Cus_Show_All_prod
            // 
            this.Cus_Show_All_prod.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Cus_Show_All_prod.Location = new System.Drawing.Point(175, 306);
            this.Cus_Show_All_prod.Name = "Cus_Show_All_prod";
            this.Cus_Show_All_prod.Size = new System.Drawing.Size(137, 54);
            this.Cus_Show_All_prod.TabIndex = 11;
            this.Cus_Show_All_prod.Text = "See All Products";
            this.Cus_Show_All_prod.UseVisualStyleBackColor = false;
            this.Cus_Show_All_prod.Click += new System.EventHandler(this.Cus_Show_All_prod_Click);
            // 
            // Cus_Recomend
            // 
            this.Cus_Recomend.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Cus_Recomend.Location = new System.Drawing.Point(21, 306);
            this.Cus_Recomend.Name = "Cus_Recomend";
            this.Cus_Recomend.Size = new System.Drawing.Size(137, 54);
            this.Cus_Recomend.TabIndex = 10;
            this.Cus_Recomend.Text = "See Your Recomended";
            this.Cus_Recomend.UseVisualStyleBackColor = false;
            this.Cus_Recomend.Click += new System.EventHandler(this.Cus_Recomend_Click);
            // 
            // Customer_Prod_Quan
            // 
            this.Customer_Prod_Quan.Location = new System.Drawing.Point(455, 274);
            this.Customer_Prod_Quan.Name = "Customer_Prod_Quan";
            this.Customer_Prod_Quan.Size = new System.Drawing.Size(261, 26);
            this.Customer_Prod_Quan.TabIndex = 9;
            this.Customer_Prod_Quan.Text = "Enter the number of items you want";
            // 
            // Customer_Prod_ID
            // 
            this.Customer_Prod_ID.Location = new System.Drawing.Point(76, 274);
            this.Customer_Prod_ID.Name = "Customer_Prod_ID";
            this.Customer_Prod_ID.Size = new System.Drawing.Size(308, 26);
            this.Customer_Prod_ID.TabIndex = 8;
            this.Customer_Prod_ID.Text = "Enter the product id of the item you want";
            this.Customer_Prod_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Customer_Make_Order
            // 
            this.Customer_Make_Order.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Customer_Make_Order.Location = new System.Drawing.Point(797, 314);
            this.Customer_Make_Order.Name = "Customer_Make_Order";
            this.Customer_Make_Order.Size = new System.Drawing.Size(137, 54);
            this.Customer_Make_Order.TabIndex = 3;
            this.Customer_Make_Order.Text = "Make Basket";
            this.Customer_Make_Order.UseVisualStyleBackColor = false;
            this.Customer_Make_Order.Click += new System.EventHandler(this.Customer_Make_Order_Click);
            // 
            // Customer_InBasket
            // 
            this.Customer_InBasket.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Customer_InBasket.Enabled = false;
            this.Customer_InBasket.Location = new System.Drawing.Point(797, 260);
            this.Customer_InBasket.Name = "Customer_InBasket";
            this.Customer_InBasket.Size = new System.Drawing.Size(137, 54);
            this.Customer_InBasket.TabIndex = 2;
            this.Customer_InBasket.Text = "Put in Basket";
            this.Customer_InBasket.UseVisualStyleBackColor = false;
            this.Customer_InBasket.Click += new System.EventHandler(this.Customer_InBasket_Click);
            // 
            // Customer_Prod_Data_View
            // 
            this.Customer_Prod_Data_View.AllowUserToAddRows = false;
            this.Customer_Prod_Data_View.AllowUserToDeleteRows = false;
            this.Customer_Prod_Data_View.AllowUserToOrderColumns = true;
            this.Customer_Prod_Data_View.AutoGenerateColumns = false;
            this.Customer_Prod_Data_View.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Customer_Prod_Data_View.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stockDataGridViewTextBoxColumn,
            this.prodnameDataGridViewTextBoxColumn,
            this.productIDDataGridViewTextBoxColumn,
            this.productTypeDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.manufacturerDataGridViewTextBoxColumn,
            this.proddesDataGridViewTextBoxColumn});
            this.Customer_Prod_Data_View.DataSource = this.pRODUCTBindingSource;
            this.Customer_Prod_Data_View.Location = new System.Drawing.Point(3, 3);
            this.Customer_Prod_Data_View.Name = "Customer_Prod_Data_View";
            this.Customer_Prod_Data_View.ReadOnly = true;
            this.Customer_Prod_Data_View.RowHeadersWidth = 62;
            this.Customer_Prod_Data_View.RowTemplate.Height = 28;
            this.Customer_Prod_Data_View.Size = new System.Drawing.Size(941, 251);
            this.Customer_Prod_Data_View.TabIndex = 0;
            // 
            // stockDataGridViewTextBoxColumn
            // 
            this.stockDataGridViewTextBoxColumn.DataPropertyName = "Stock";
            this.stockDataGridViewTextBoxColumn.HeaderText = "Stock";
            this.stockDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stockDataGridViewTextBoxColumn.Name = "stockDataGridViewTextBoxColumn";
            this.stockDataGridViewTextBoxColumn.ReadOnly = true;
            this.stockDataGridViewTextBoxColumn.Width = 150;
            // 
            // prodnameDataGridViewTextBoxColumn
            // 
            this.prodnameDataGridViewTextBoxColumn.DataPropertyName = "Prod_name";
            this.prodnameDataGridViewTextBoxColumn.HeaderText = "Prod_name";
            this.prodnameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.prodnameDataGridViewTextBoxColumn.Name = "prodnameDataGridViewTextBoxColumn";
            this.prodnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.prodnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // productIDDataGridViewTextBoxColumn
            // 
            this.productIDDataGridViewTextBoxColumn.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.productIDDataGridViewTextBoxColumn.Name = "productIDDataGridViewTextBoxColumn";
            this.productIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.productIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // productTypeDataGridViewTextBoxColumn
            // 
            this.productTypeDataGridViewTextBoxColumn.DataPropertyName = "Product_Type";
            this.productTypeDataGridViewTextBoxColumn.HeaderText = "Product_Type";
            this.productTypeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.productTypeDataGridViewTextBoxColumn.Name = "productTypeDataGridViewTextBoxColumn";
            this.productTypeDataGridViewTextBoxColumn.ReadOnly = true;
            this.productTypeDataGridViewTextBoxColumn.Width = 150;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            this.priceDataGridViewTextBoxColumn.Width = 150;
            // 
            // manufacturerDataGridViewTextBoxColumn
            // 
            this.manufacturerDataGridViewTextBoxColumn.DataPropertyName = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn.HeaderText = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.manufacturerDataGridViewTextBoxColumn.Name = "manufacturerDataGridViewTextBoxColumn";
            this.manufacturerDataGridViewTextBoxColumn.ReadOnly = true;
            this.manufacturerDataGridViewTextBoxColumn.Width = 150;
            // 
            // proddesDataGridViewTextBoxColumn
            // 
            this.proddesDataGridViewTextBoxColumn.DataPropertyName = "Prod_des";
            this.proddesDataGridViewTextBoxColumn.HeaderText = "Prod_des";
            this.proddesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.proddesDataGridViewTextBoxColumn.Name = "proddesDataGridViewTextBoxColumn";
            this.proddesDataGridViewTextBoxColumn.ReadOnly = true;
            this.proddesDataGridViewTextBoxColumn.Width = 150;
            // 
            // pRODUCTBindingSource
            // 
            this.pRODUCTBindingSource.DataMember = "PRODUCT";
            this.pRODUCTBindingSource.DataSource = this.mssql1903299DataSet11;
            // 
            // mssql1903299DataSet11
            // 
            this.mssql1903299DataSet11.DataSetName = "mssql1903299DataSet11";
            this.mssql1903299DataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage2.BackgroundImage")));
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1000, 422);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "customer";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LawnGreen;
            this.panel2.Controls.Add(this.Customer_info_Load);
            this.panel2.Controls.Add(this.Account_Del);
            this.panel2.Controls.Add(this.Customer_CUS_Delete);
            this.panel2.Controls.Add(this.Customer_CUS_Save);
            this.panel2.Controls.Add(this.Customer_Cus_Data_View);
            this.panel2.Location = new System.Drawing.Point(27, 26);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(947, 371);
            this.panel2.TabIndex = 1;
            // 
            // Account_Del
            // 
            this.Account_Del.Location = new System.Drawing.Point(483, 328);
            this.Account_Del.Name = "Account_Del";
            this.Account_Del.Size = new System.Drawing.Size(284, 26);
            this.Account_Del.TabIndex = 4;
            this.Account_Del.Text = "Enter your email to delete yor account ";
            // 
            // Customer_CUS_Delete
            // 
            this.Customer_CUS_Delete.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Customer_CUS_Delete.Location = new System.Drawing.Point(797, 314);
            this.Customer_CUS_Delete.Name = "Customer_CUS_Delete";
            this.Customer_CUS_Delete.Size = new System.Drawing.Size(137, 54);
            this.Customer_CUS_Delete.TabIndex = 3;
            this.Customer_CUS_Delete.Text = "Delete Account";
            this.Customer_CUS_Delete.UseVisualStyleBackColor = false;
            this.Customer_CUS_Delete.Click += new System.EventHandler(this.Customer_CUS_Delete_Click);
            // 
            // Customer_CUS_Save
            // 
            this.Customer_CUS_Save.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Customer_CUS_Save.Location = new System.Drawing.Point(797, 260);
            this.Customer_CUS_Save.Name = "Customer_CUS_Save";
            this.Customer_CUS_Save.Size = new System.Drawing.Size(137, 54);
            this.Customer_CUS_Save.TabIndex = 2;
            this.Customer_CUS_Save.Text = "Save Changes";
            this.Customer_CUS_Save.UseVisualStyleBackColor = false;
            this.Customer_CUS_Save.Click += new System.EventHandler(this.Customer_CUS_Save_Click);
            // 
            // Customer_Cus_Data_View
            // 
            this.Customer_Cus_Data_View.AllowUserToAddRows = false;
            this.Customer_Cus_Data_View.AllowUserToDeleteRows = false;
            this.Customer_Cus_Data_View.AllowUserToOrderColumns = true;
            this.Customer_Cus_Data_View.AutoGenerateColumns = false;
            this.Customer_Cus_Data_View.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Customer_Cus_Data_View.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.eMAILDataGridViewTextBoxColumn,
            this.cAddressDataGridViewTextBoxColumn,
            this.phoneNumDataGridViewTextBoxColumn,
            this.fnameDataGridViewTextBoxColumn,
            this.lnameDataGridViewTextBoxColumn,
            this.usernameDataGridViewTextBoxColumn,
            this.passDataGridViewTextBoxColumn,
            this.prefDataGridViewTextBoxColumn});
            this.Customer_Cus_Data_View.DataSource = this.cUSTOMERBindingSource;
            this.Customer_Cus_Data_View.Location = new System.Drawing.Point(3, 3);
            this.Customer_Cus_Data_View.Name = "Customer_Cus_Data_View";
            this.Customer_Cus_Data_View.RowHeadersWidth = 62;
            this.Customer_Cus_Data_View.RowTemplate.Height = 28;
            this.Customer_Cus_Data_View.Size = new System.Drawing.Size(941, 251);
            this.Customer_Cus_Data_View.TabIndex = 0;
            // 
            // eMAILDataGridViewTextBoxColumn
            // 
            this.eMAILDataGridViewTextBoxColumn.DataPropertyName = "EMAIL";
            this.eMAILDataGridViewTextBoxColumn.HeaderText = "EMAIL";
            this.eMAILDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.eMAILDataGridViewTextBoxColumn.Name = "eMAILDataGridViewTextBoxColumn";
            this.eMAILDataGridViewTextBoxColumn.ReadOnly = true;
            this.eMAILDataGridViewTextBoxColumn.Width = 150;
            // 
            // cAddressDataGridViewTextBoxColumn
            // 
            this.cAddressDataGridViewTextBoxColumn.DataPropertyName = "CAddress";
            this.cAddressDataGridViewTextBoxColumn.HeaderText = "CAddress";
            this.cAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.cAddressDataGridViewTextBoxColumn.Name = "cAddressDataGridViewTextBoxColumn";
            this.cAddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.cAddressDataGridViewTextBoxColumn.Width = 150;
            // 
            // phoneNumDataGridViewTextBoxColumn
            // 
            this.phoneNumDataGridViewTextBoxColumn.DataPropertyName = "Phone_Num";
            this.phoneNumDataGridViewTextBoxColumn.HeaderText = "Phone_Num";
            this.phoneNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.phoneNumDataGridViewTextBoxColumn.Name = "phoneNumDataGridViewTextBoxColumn";
            this.phoneNumDataGridViewTextBoxColumn.ReadOnly = true;
            this.phoneNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // fnameDataGridViewTextBoxColumn
            // 
            this.fnameDataGridViewTextBoxColumn.DataPropertyName = "Fname";
            this.fnameDataGridViewTextBoxColumn.HeaderText = "Fname";
            this.fnameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.fnameDataGridViewTextBoxColumn.Name = "fnameDataGridViewTextBoxColumn";
            this.fnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.fnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // lnameDataGridViewTextBoxColumn
            // 
            this.lnameDataGridViewTextBoxColumn.DataPropertyName = "Lname";
            this.lnameDataGridViewTextBoxColumn.HeaderText = "Lname";
            this.lnameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.lnameDataGridViewTextBoxColumn.Name = "lnameDataGridViewTextBoxColumn";
            this.lnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.lnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "Username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "Username";
            this.usernameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            this.usernameDataGridViewTextBoxColumn.ReadOnly = true;
            this.usernameDataGridViewTextBoxColumn.Width = 150;
            // 
            // passDataGridViewTextBoxColumn
            // 
            this.passDataGridViewTextBoxColumn.DataPropertyName = "Pass";
            this.passDataGridViewTextBoxColumn.HeaderText = "Pass";
            this.passDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.passDataGridViewTextBoxColumn.Name = "passDataGridViewTextBoxColumn";
            this.passDataGridViewTextBoxColumn.ReadOnly = true;
            this.passDataGridViewTextBoxColumn.Width = 150;
            // 
            // prefDataGridViewTextBoxColumn
            // 
            this.prefDataGridViewTextBoxColumn.DataPropertyName = "pref";
            this.prefDataGridViewTextBoxColumn.HeaderText = "pref";
            this.prefDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.prefDataGridViewTextBoxColumn.Name = "prefDataGridViewTextBoxColumn";
            this.prefDataGridViewTextBoxColumn.ReadOnly = true;
            this.prefDataGridViewTextBoxColumn.Width = 150;
            // 
            // cUSTOMERBindingSource
            // 
            this.cUSTOMERBindingSource.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource.DataSource = this.mssql1903299DataSet12;
            // 
            // mssql1903299DataSet12
            // 
            this.mssql1903299DataSet12.DataSetName = "mssql1903299DataSet12";
            this.mssql1903299DataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage3
            // 
            this.tabPage3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage3.BackgroundImage")));
            this.tabPage3.Controls.Add(this.panel3);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1000, 422);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "orders";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LawnGreen;
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.Cus_S_Order);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.Customer_Spesific_Load_Order);
            this.panel3.Controls.Add(this.Customer_End_Order);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.Customer_Prod_ToCollect);
            this.panel3.Controls.Add(this.Customer_Order_settable);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.Customer_Order_Save);
            this.panel3.Controls.Add(this.Customer_Order_delete);
            this.panel3.Controls.Add(this.Customer_Orders_Grid_View2);
            this.panel3.Controls.Add(this.Customer_Orders_Grid_View);
            this.panel3.Location = new System.Drawing.Point(52, 15);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(897, 393);
            this.panel3.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(234, 348);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(354, 26);
            this.textBox1.TabIndex = 12;
            this.textBox1.Text = "Enter the order id of the order you want to pay for ";
            // 
            // Cus_S_Order
            // 
            this.Cus_S_Order.Location = new System.Drawing.Point(223, 268);
            this.Cus_S_Order.Name = "Cus_S_Order";
            this.Cus_S_Order.Size = new System.Drawing.Size(50, 26);
            this.Cus_S_Order.TabIndex = 16;
            this.Cus_S_Order.Text = "Num";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(147, 248);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 120);
            this.label2.TabIndex = 15;
            this.label2.Text = "Enter number\r\nof the\r\norder you \r\nwant to\r\n know more\r\n about";
            // 
            // Customer_Spesific_Load_Order
            // 
            this.Customer_Spesific_Load_Order.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Customer_Spesific_Load_Order.Enabled = false;
            this.Customer_Spesific_Load_Order.Location = new System.Drawing.Point(3, 300);
            this.Customer_Spesific_Load_Order.Name = "Customer_Spesific_Load_Order";
            this.Customer_Spesific_Load_Order.Size = new System.Drawing.Size(138, 48);
            this.Customer_Spesific_Load_Order.TabIndex = 13;
            this.Customer_Spesific_Load_Order.Text = "Load spesific order contence";
            this.Customer_Spesific_Load_Order.UseVisualStyleBackColor = false;
            this.Customer_Spesific_Load_Order.Click += new System.EventHandler(this.Customer_Spesific_Load_Order_Click);
            // 
            // Customer_End_Order
            // 
            this.Customer_End_Order.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Customer_End_Order.Location = new System.Drawing.Point(594, 336);
            this.Customer_End_Order.Name = "Customer_End_Order";
            this.Customer_End_Order.Size = new System.Drawing.Size(140, 50);
            this.Customer_End_Order.TabIndex = 11;
            this.Customer_End_Order.Text = "Pay of Order";
            this.Customer_End_Order.UseVisualStyleBackColor = false;
            this.Customer_End_Order.Click += new System.EventHandler(this.Customer_End_Order_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(289, 250);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 80);
            this.label5.TabIndex = 8;
            this.label5.Text = "Do you want\r\n to collect\r\n your order\r\n in store";
            // 
            // Customer_Prod_ToCollect
            // 
            this.Customer_Prod_ToCollect.FormattingEnabled = true;
            this.Customer_Prod_ToCollect.ItemHeight = 20;
            this.Customer_Prod_ToCollect.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.Customer_Prod_ToCollect.Location = new System.Drawing.Point(392, 250);
            this.Customer_Prod_ToCollect.Name = "Customer_Prod_ToCollect";
            this.Customer_Prod_ToCollect.Size = new System.Drawing.Size(45, 44);
            this.Customer_Prod_ToCollect.TabIndex = 7;
            // 
            // Customer_Order_settable
            // 
            this.Customer_Order_settable.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Customer_Order_settable.Location = new System.Drawing.Point(3, 246);
            this.Customer_Order_settable.Name = "Customer_Order_settable";
            this.Customer_Order_settable.Size = new System.Drawing.Size(138, 48);
            this.Customer_Order_settable.TabIndex = 6;
            this.Customer_Order_settable.Text = "Load Your orders";
            this.Customer_Order_settable.UseVisualStyleBackColor = false;
            this.Customer_Order_settable.Click += new System.EventHandler(this.Customer_Order_settable_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(456, 250);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(278, 60);
            this.label4.TabIndex = 4;
            this.label4.Text = "PLEASE do not change the Order ID\r\nthis could cause you to lose your order\r\nand y" +
    "ou will be fined ";
            // 
            // Customer_Order_Save
            // 
            this.Customer_Order_Save.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Customer_Order_Save.Location = new System.Drawing.Point(740, 300);
            this.Customer_Order_Save.Name = "Customer_Order_Save";
            this.Customer_Order_Save.Size = new System.Drawing.Size(138, 48);
            this.Customer_Order_Save.TabIndex = 3;
            this.Customer_Order_Save.Text = "Save Changes";
            this.Customer_Order_Save.UseVisualStyleBackColor = false;
            this.Customer_Order_Save.Click += new System.EventHandler(this.Customer_Order_Save_Click);
            // 
            // Customer_Order_delete
            // 
            this.Customer_Order_delete.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Customer_Order_delete.Location = new System.Drawing.Point(740, 246);
            this.Customer_Order_delete.Name = "Customer_Order_delete";
            this.Customer_Order_delete.Size = new System.Drawing.Size(138, 48);
            this.Customer_Order_delete.TabIndex = 2;
            this.Customer_Order_delete.Text = "Cancel Order";
            this.Customer_Order_delete.UseVisualStyleBackColor = false;
            this.Customer_Order_delete.Click += new System.EventHandler(this.Customer_Order_delete_Click);
            // 
            // Customer_Orders_Grid_View2
            // 
            this.Customer_Orders_Grid_View2.AllowUserToAddRows = false;
            this.Customer_Orders_Grid_View2.AllowUserToOrderColumns = true;
            this.Customer_Orders_Grid_View2.AutoGenerateColumns = false;
            this.Customer_Orders_Grid_View2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Customer_Orders_Grid_View2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderIdDataGridViewTextBoxColumn1,
            this.productIDDataGridViewTextBoxColumn1,
            this.quantityDataGridViewTextBoxColumn});
            this.Customer_Orders_Grid_View2.DataSource = this.cORDERCONTAINSBindingSource3;
            this.Customer_Orders_Grid_View2.Location = new System.Drawing.Point(648, 12);
            this.Customer_Orders_Grid_View2.Name = "Customer_Orders_Grid_View2";
            this.Customer_Orders_Grid_View2.RowHeadersWidth = 62;
            this.Customer_Orders_Grid_View2.RowTemplate.Height = 28;
            this.Customer_Orders_Grid_View2.Size = new System.Drawing.Size(246, 228);
            this.Customer_Orders_Grid_View2.TabIndex = 1;
            // 
            // orderIdDataGridViewTextBoxColumn1
            // 
            this.orderIdDataGridViewTextBoxColumn1.DataPropertyName = "Order_Id";
            this.orderIdDataGridViewTextBoxColumn1.HeaderText = "Order_Id";
            this.orderIdDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.orderIdDataGridViewTextBoxColumn1.Name = "orderIdDataGridViewTextBoxColumn1";
            this.orderIdDataGridViewTextBoxColumn1.Width = 150;
            // 
            // productIDDataGridViewTextBoxColumn1
            // 
            this.productIDDataGridViewTextBoxColumn1.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.productIDDataGridViewTextBoxColumn1.Name = "productIDDataGridViewTextBoxColumn1";
            this.productIDDataGridViewTextBoxColumn1.Width = 150;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.Width = 150;
            // 
            // cORDERCONTAINSBindingSource2
            // 
            this.cORDERCONTAINSBindingSource2.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource2.DataSource = this.mssql1903299DataSet24;
            // 
            // mssql1903299DataSet24
            // 
            this.mssql1903299DataSet24.DataSetName = "mssql1903299DataSet24";
            this.mssql1903299DataSet24.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Customer_Orders_Grid_View
            // 
            this.Customer_Orders_Grid_View.AllowUserToAddRows = false;
            this.Customer_Orders_Grid_View.AllowUserToOrderColumns = true;
            this.Customer_Orders_Grid_View.AutoGenerateColumns = false;
            this.Customer_Orders_Grid_View.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Customer_Orders_Grid_View.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.toCollectDataGridViewTextBoxColumn,
            this.oRDERIDDataGridViewTextBoxColumn,
            this.customerIDDataGridViewTextBoxColumn,
            this.paidDataGridViewTextBoxColumn,
            this.orderDateDataGridViewTextBoxColumn});
            this.Customer_Orders_Grid_View.DataSource = this.cORDERBindingSource1;
            this.Customer_Orders_Grid_View.Location = new System.Drawing.Point(3, 12);
            this.Customer_Orders_Grid_View.Name = "Customer_Orders_Grid_View";
            this.Customer_Orders_Grid_View.RowHeadersWidth = 62;
            this.Customer_Orders_Grid_View.RowTemplate.Height = 28;
            this.Customer_Orders_Grid_View.Size = new System.Drawing.Size(627, 228);
            this.Customer_Orders_Grid_View.TabIndex = 0;
            // 
            // toCollectDataGridViewTextBoxColumn
            // 
            this.toCollectDataGridViewTextBoxColumn.DataPropertyName = "ToCollect";
            this.toCollectDataGridViewTextBoxColumn.HeaderText = "ToCollect";
            this.toCollectDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.toCollectDataGridViewTextBoxColumn.Name = "toCollectDataGridViewTextBoxColumn";
            this.toCollectDataGridViewTextBoxColumn.Width = 150;
            // 
            // oRDERIDDataGridViewTextBoxColumn
            // 
            this.oRDERIDDataGridViewTextBoxColumn.DataPropertyName = "ORDER_ID";
            this.oRDERIDDataGridViewTextBoxColumn.HeaderText = "ORDER_ID";
            this.oRDERIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.oRDERIDDataGridViewTextBoxColumn.Name = "oRDERIDDataGridViewTextBoxColumn";
            this.oRDERIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.oRDERIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            this.customerIDDataGridViewTextBoxColumn.DataPropertyName = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.HeaderText = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            this.customerIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // paidDataGridViewTextBoxColumn
            // 
            this.paidDataGridViewTextBoxColumn.DataPropertyName = "Paid";
            this.paidDataGridViewTextBoxColumn.HeaderText = "Paid";
            this.paidDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.paidDataGridViewTextBoxColumn.Name = "paidDataGridViewTextBoxColumn";
            this.paidDataGridViewTextBoxColumn.Width = 150;
            // 
            // orderDateDataGridViewTextBoxColumn
            // 
            this.orderDateDataGridViewTextBoxColumn.DataPropertyName = "Order_Date";
            this.orderDateDataGridViewTextBoxColumn.HeaderText = "Order_Date";
            this.orderDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orderDateDataGridViewTextBoxColumn.Name = "orderDateDataGridViewTextBoxColumn";
            this.orderDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // cORDERBindingSource1
            // 
            this.cORDERBindingSource1.DataMember = "C_ORDER";
            this.cORDERBindingSource1.DataSource = this.mssql1903299DataSet21;
            // 
            // mssql1903299DataSet21
            // 
            this.mssql1903299DataSet21.DataSetName = "mssql1903299DataSet21";
            this.mssql1903299DataSet21.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cORDERCONTAINSBindingSource1
            // 
            this.cORDERCONTAINSBindingSource1.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource1.DataSource = this.mssql1903299DataSet18;
            // 
            // mssql1903299DataSet18
            // 
            this.mssql1903299DataSet18.DataSetName = "mssql1903299DataSet18";
            this.mssql1903299DataSet18.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cORDERBindingSource
            // 
            this.cORDERBindingSource.DataMember = "C_ORDER";
            this.cORDERBindingSource.DataSource = this.mssql1903299DataSet14;
            // 
            // mssql1903299DataSet14
            // 
            this.mssql1903299DataSet14.DataSetName = "mssql1903299DataSet14";
            this.mssql1903299DataSet14.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cORDERCONTAINSBindingSource
            // 
            this.cORDERCONTAINSBindingSource.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource.DataSource = this.mssql1903299DataSet15;
            // 
            // mssql1903299DataSet15
            // 
            this.mssql1903299DataSet15.DataSetName = "mssql1903299DataSet15";
            this.mssql1903299DataSet15.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pRODUCTTableAdapter
            // 
            this.pRODUCTTableAdapter.ClearBeforeFill = true;
            // 
            // cUSTOMERTableAdapter
            // 
            this.cUSTOMERTableAdapter.ClearBeforeFill = true;
            // 
            // c_ORDERTableAdapter
            // 
            this.c_ORDERTableAdapter.ClearBeforeFill = true;
            // 
            // c_ORDER_CONTAINSTableAdapter
            // 
            this.c_ORDER_CONTAINSTableAdapter.ClearBeforeFill = true;
            // 
            // c_ORDER_CONTAINSTableAdapter1
            // 
            this.c_ORDER_CONTAINSTableAdapter1.ClearBeforeFill = true;
            // 
            // c_ORDERTableAdapter1
            // 
            this.c_ORDERTableAdapter1.ClearBeforeFill = true;
            // 
            // c_ORDER_CONTAINSTableAdapter2
            // 
            this.c_ORDER_CONTAINSTableAdapter2.ClearBeforeFill = true;
            // 
            // Customer_info_Load
            // 
            this.Customer_info_Load.BackColor = System.Drawing.Color.DarkTurquoise;
            this.Customer_info_Load.Location = new System.Drawing.Point(630, 260);
            this.Customer_info_Load.Name = "Customer_info_Load";
            this.Customer_info_Load.Size = new System.Drawing.Size(137, 54);
            this.Customer_info_Load.TabIndex = 5;
            this.Customer_info_Load.Text = "Load your information";
            this.Customer_info_Load.UseVisualStyleBackColor = false;
            this.Customer_info_Load.Click += new System.EventHandler(this.Customer_info_Load_Click);
            // 
            // mssql1903299DataSet26
            // 
            this.mssql1903299DataSet26.DataSetName = "mssql1903299DataSet26";
            this.mssql1903299DataSet26.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cORDERCONTAINSBindingSource3
            // 
            this.cORDERCONTAINSBindingSource3.DataMember = "C_ORDER_CONTAINS";
            this.cORDERCONTAINSBindingSource3.DataSource = this.mssql1903299DataSet26;
            // 
            // c_ORDER_CONTAINSTableAdapter3
            // 
            this.c_ORDER_CONTAINSTableAdapter3.ClearBeforeFill = true;
            // 
            // Customers_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGreen;
            this.ClientSize = new System.Drawing.Size(1004, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Customers_Page";
            this.Text = "Customers";
            this.Load += new System.EventHandler(this.Customers_Page_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_Prod_Data_View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet11)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_Cus_Data_View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet12)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_Orders_Grid_View2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Customer_Orders_Grid_View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cORDERCONTAINSBindingSource3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView Customer_Prod_Data_View;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private mssql1903299DataSet11 mssql1903299DataSet11;
        private System.Windows.Forms.BindingSource pRODUCTBindingSource;
        private mssql1903299DataSet11TableAdapters.PRODUCTTableAdapter pRODUCTTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manufacturerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn proddesDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Customer_InBasket;
        private System.Windows.Forms.Button Customer_Make_Order;
        private System.Windows.Forms.TextBox Customer_Prod_ID;
        private System.Windows.Forms.TextBox Customer_Prod_Quan;
        private System.Windows.Forms.Button Cus_Recomend;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button Customer_CUS_Delete;
        private System.Windows.Forms.Button Customer_CUS_Save;
        private System.Windows.Forms.DataGridView Customer_Cus_Data_View;
        private mssql1903299DataSet12 mssql1903299DataSet12;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource;
        private mssql1903299DataSet12TableAdapters.CUSTOMERTableAdapter cUSTOMERTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMAILDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prefDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Customer_End_Order;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox Customer_Prod_ToCollect;
        private System.Windows.Forms.Button Customer_Order_settable;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Customer_Order_Save;
        private System.Windows.Forms.Button Customer_Order_delete;
        private System.Windows.Forms.DataGridView Customer_Orders_Grid_View2;
        private System.Windows.Forms.DataGridView Customer_Orders_Grid_View;
        private mssql1903299DataSet14 mssql1903299DataSet14;
        private System.Windows.Forms.BindingSource cORDERBindingSource;
        private mssql1903299DataSet14TableAdapters.C_ORDERTableAdapter c_ORDERTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn toCollectDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oRDERIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderDateDataGridViewTextBoxColumn;
        private mssql1903299DataSet15 mssql1903299DataSet15;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource;
        private mssql1903299DataSet15TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIdDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Cus_Show_All_prod;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button Customer_Spesific_Load_Order;
        private System.Windows.Forms.Label label2;
        private mssql1903299DataSet18 mssql1903299DataSet18;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource1;
        private mssql1903299DataSet18TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter1;
        private System.Windows.Forms.TextBox Cus_S_Order;
        private System.Windows.Forms.TextBox Account_Del;
        private mssql1903299DataSet21 mssql1903299DataSet21;
        private System.Windows.Forms.BindingSource cORDERBindingSource1;
        private mssql1903299DataSet21TableAdapters.C_ORDERTableAdapter c_ORDERTableAdapter1;
        private System.Windows.Forms.TextBox Cus_Order_ID;
        private mssql1903299DataSet24 mssql1903299DataSet24;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource2;
        private mssql1903299DataSet24TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter2;
        private System.Windows.Forms.Button Customer_info_Load;
        private mssql1903299DataSet26 mssql1903299DataSet26;
        private System.Windows.Forms.BindingSource cORDERCONTAINSBindingSource3;
        private mssql1903299DataSet26TableAdapters.C_ORDER_CONTAINSTableAdapter c_ORDER_CONTAINSTableAdapter3;
    }
}