﻿
namespace Comic_book_store
{
    partial class Startpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Staff = new System.Windows.Forms.Button();
            this.Guest = new System.Windows.Forms.Button();
            this.Staff_Login = new System.Windows.Forms.Panel();
            this.Submit_Staff = new System.Windows.Forms.Button();
            this.PassWord_Staff = new System.Windows.Forms.TextBox();
            this.Username_Staff = new System.Windows.Forms.TextBox();
            this.CustomerLogin = new System.Windows.Forms.Panel();
            this.Submit_customer = new System.Windows.Forms.Button();
            this.Password_customer = new System.Windows.Forms.TextBox();
            this.Username_customer = new System.Windows.Forms.TextBox();
            this.Staff_Login.SuspendLayout();
            this.CustomerLogin.SuspendLayout();
            this.SuspendLayout();
            // 
            // Staff
            // 
            this.Staff.Location = new System.Drawing.Point(121, 67);
            this.Staff.Name = "Staff";
            this.Staff.Size = new System.Drawing.Size(178, 65);
            this.Staff.TabIndex = 0;
            this.Staff.Text = "Staff Login";
            this.Staff.UseVisualStyleBackColor = true;
            // 
            // Guest
            // 
            this.Guest.Location = new System.Drawing.Point(531, 67);
            this.Guest.Name = "Guest";
            this.Guest.Size = new System.Drawing.Size(174, 65);
            this.Guest.TabIndex = 1;
            this.Guest.Text = "Log in as a Guest";
            this.Guest.UseVisualStyleBackColor = true;
            this.Guest.Click += new System.EventHandler(this.Guest_Click);
            // 
            // Staff_Login
            // 
            this.Staff_Login.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Staff_Login.Controls.Add(this.Submit_Staff);
            this.Staff_Login.Controls.Add(this.PassWord_Staff);
            this.Staff_Login.Controls.Add(this.Username_Staff);
            this.Staff_Login.Location = new System.Drawing.Point(109, 159);
            this.Staff_Login.Name = "Staff_Login";
            this.Staff_Login.Size = new System.Drawing.Size(200, 279);
            this.Staff_Login.TabIndex = 2;
            // 
            // Submit_Staff
            // 
            this.Submit_Staff.Location = new System.Drawing.Point(12, 185);
            this.Submit_Staff.Name = "Submit_Staff";
            this.Submit_Staff.Size = new System.Drawing.Size(178, 65);
            this.Submit_Staff.TabIndex = 5;
            this.Submit_Staff.Text = "Staff Login";
            this.Submit_Staff.UseVisualStyleBackColor = true;
            this.Submit_Staff.Click += new System.EventHandler(this.Submit_Staff_Click_1);
            // 
            // PassWord_Staff
            // 
            this.PassWord_Staff.Location = new System.Drawing.Point(12, 112);
            this.PassWord_Staff.Name = "PassWord_Staff";
            this.PassWord_Staff.PasswordChar = '*';
            this.PassWord_Staff.Size = new System.Drawing.Size(178, 26);
            this.PassWord_Staff.TabIndex = 1;
            this.PassWord_Staff.Text = "sgwesdgsd";
            this.PassWord_Staff.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Username_Staff
            // 
            this.Username_Staff.Location = new System.Drawing.Point(12, 55);
            this.Username_Staff.Name = "Username_Staff";
            this.Username_Staff.Size = new System.Drawing.Size(178, 26);
            this.Username_Staff.TabIndex = 0;
            this.Username_Staff.Text = "Enter your username";
            this.Username_Staff.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CustomerLogin
            // 
            this.CustomerLogin.BackColor = System.Drawing.Color.Turquoise;
            this.CustomerLogin.Controls.Add(this.Submit_customer);
            this.CustomerLogin.Controls.Add(this.Password_customer);
            this.CustomerLogin.Controls.Add(this.Username_customer);
            this.CustomerLogin.Location = new System.Drawing.Point(517, 159);
            this.CustomerLogin.Name = "CustomerLogin";
            this.CustomerLogin.Size = new System.Drawing.Size(200, 279);
            this.CustomerLogin.TabIndex = 3;
            // 
            // Submit_customer
            // 
            this.Submit_customer.BackColor = System.Drawing.Color.PaleGreen;
            this.Submit_customer.Location = new System.Drawing.Point(14, 185);
            this.Submit_customer.Name = "Submit_customer";
            this.Submit_customer.Size = new System.Drawing.Size(174, 65);
            this.Submit_customer.TabIndex = 4;
            this.Submit_customer.Text = "Customer Login";
            this.Submit_customer.UseVisualStyleBackColor = false;
            this.Submit_customer.Click += new System.EventHandler(this.Submit_customer_Click_1);
            // 
            // Password_customer
            // 
            this.Password_customer.Location = new System.Drawing.Point(14, 112);
            this.Password_customer.Name = "Password_customer";
            this.Password_customer.PasswordChar = '*';
            this.Password_customer.Size = new System.Drawing.Size(174, 26);
            this.Password_customer.TabIndex = 2;
            this.Password_customer.Text = "dvasdvsdv";
            this.Password_customer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Username_customer
            // 
            this.Username_customer.Location = new System.Drawing.Point(14, 55);
            this.Username_customer.Name = "Username_customer";
            this.Username_customer.Size = new System.Drawing.Size(174, 26);
            this.Username_customer.TabIndex = 3;
            this.Username_customer.Text = "Enter your username";
            this.Username_customer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Startpage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SpringGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.CustomerLogin);
            this.Controls.Add(this.Staff_Login);
            this.Controls.Add(this.Guest);
            this.Controls.Add(this.Staff);
            this.Name = "Startpage";
            this.Text = "Welcome";
            this.Staff_Login.ResumeLayout(false);
            this.Staff_Login.PerformLayout();
            this.CustomerLogin.ResumeLayout(false);
            this.CustomerLogin.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Staff;
        private System.Windows.Forms.Button Guest;
        private System.Windows.Forms.Panel Staff_Login;
        private System.Windows.Forms.Button Submit_Staff;
        private System.Windows.Forms.TextBox PassWord_Staff;
        private System.Windows.Forms.TextBox Username_Staff;
        private System.Windows.Forms.Panel CustomerLogin;
        private System.Windows.Forms.Button Submit_customer;
        private System.Windows.Forms.TextBox Password_customer;
        private System.Windows.Forms.TextBox Username_customer;
    }
}