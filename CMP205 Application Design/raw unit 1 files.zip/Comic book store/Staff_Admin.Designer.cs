﻿
namespace Comic_book_store
{
    partial class Staff_Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Staff_Admin_Grid_View = new System.Windows.Forms.DataGridView();
            this.sTAFFBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet4 = new Comic_book_store.mssql1903299DataSet4();
            this.sTAFFTableAdapter = new Comic_book_store.mssql1903299DataSet4TableAdapters.STAFFTableAdapter();
            this.Staff_Admin_ID = new System.Windows.Forms.TextBox();
            this.Staff_Admin_Salary = new System.Windows.Forms.TextBox();
            this.Staff_Admin_Pos = new System.Windows.Forms.TextBox();
            this.Staff_Admin_FName = new System.Windows.Forms.TextBox();
            this.Staff_Admin_LName = new System.Windows.Forms.TextBox();
            this.Staff_Admin_Reload = new System.Windows.Forms.Button();
            this.BackToStaff = new System.Windows.Forms.Button();
            this.Staff_Admin_Save = new System.Windows.Forms.Button();
            this.Staff_Admin_Delete = new System.Windows.Forms.Button();
            this.staffIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.posDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salaryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Staff_Admin_Grid_View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTAFFBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet4)).BeginInit();
            this.SuspendLayout();
            // 
            // Staff_Admin_Grid_View
            // 
            this.Staff_Admin_Grid_View.AutoGenerateColumns = false;
            this.Staff_Admin_Grid_View.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Staff_Admin_Grid_View.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.staffIDDataGridViewTextBoxColumn,
            this.posDataGridViewTextBoxColumn,
            this.salaryDataGridViewTextBoxColumn,
            this.fnameDataGridViewTextBoxColumn,
            this.lnameDataGridViewTextBoxColumn});
            this.Staff_Admin_Grid_View.DataSource = this.sTAFFBindingSource;
            this.Staff_Admin_Grid_View.Location = new System.Drawing.Point(1, -2);
            this.Staff_Admin_Grid_View.Name = "Staff_Admin_Grid_View";
            this.Staff_Admin_Grid_View.RowHeadersWidth = 62;
            this.Staff_Admin_Grid_View.RowTemplate.Height = 28;
            this.Staff_Admin_Grid_View.Size = new System.Drawing.Size(971, 257);
            this.Staff_Admin_Grid_View.TabIndex = 0;
            this.Staff_Admin_Grid_View.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Staff_Admin_Grid_View_DoubleClick);
            // 
            // sTAFFBindingSource
            // 
            this.sTAFFBindingSource.DataMember = "STAFF";
            this.sTAFFBindingSource.DataSource = this.mssql1903299DataSet4;
            // 
            // mssql1903299DataSet4
            // 
            this.mssql1903299DataSet4.DataSetName = "mssql1903299DataSet4";
            this.mssql1903299DataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sTAFFTableAdapter
            // 
            this.sTAFFTableAdapter.ClearBeforeFill = true;
            // 
            // Staff_Admin_ID
            // 
            this.Staff_Admin_ID.Location = new System.Drawing.Point(12, 272);
            this.Staff_Admin_ID.Name = "Staff_Admin_ID";
            this.Staff_Admin_ID.Size = new System.Drawing.Size(145, 26);
            this.Staff_Admin_ID.TabIndex = 1;
            this.Staff_Admin_ID.Text = "Enter Staff ID";
            this.Staff_Admin_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Admin_Salary
            // 
            this.Staff_Admin_Salary.Location = new System.Drawing.Point(346, 272);
            this.Staff_Admin_Salary.Name = "Staff_Admin_Salary";
            this.Staff_Admin_Salary.Size = new System.Drawing.Size(145, 26);
            this.Staff_Admin_Salary.TabIndex = 2;
            this.Staff_Admin_Salary.Text = "Enter Staff Salary";
            this.Staff_Admin_Salary.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Admin_Pos
            // 
            this.Staff_Admin_Pos.Location = new System.Drawing.Point(180, 272);
            this.Staff_Admin_Pos.Name = "Staff_Admin_Pos";
            this.Staff_Admin_Pos.Size = new System.Drawing.Size(145, 26);
            this.Staff_Admin_Pos.TabIndex = 3;
            this.Staff_Admin_Pos.Text = "Enter Staff Position";
            // 
            // Staff_Admin_FName
            // 
            this.Staff_Admin_FName.Location = new System.Drawing.Point(12, 320);
            this.Staff_Admin_FName.Name = "Staff_Admin_FName";
            this.Staff_Admin_FName.Size = new System.Drawing.Size(162, 26);
            this.Staff_Admin_FName.TabIndex = 4;
            this.Staff_Admin_FName.Text = "Enter Staff first Name";
            this.Staff_Admin_FName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Admin_LName
            // 
            this.Staff_Admin_LName.Location = new System.Drawing.Point(194, 320);
            this.Staff_Admin_LName.Name = "Staff_Admin_LName";
            this.Staff_Admin_LName.Size = new System.Drawing.Size(170, 26);
            this.Staff_Admin_LName.TabIndex = 5;
            this.Staff_Admin_LName.Text = "Enter Staff Last Name";
            this.Staff_Admin_LName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Staff_Admin_Reload
            // 
            this.Staff_Admin_Reload.Location = new System.Drawing.Point(620, 285);
            this.Staff_Admin_Reload.Name = "Staff_Admin_Reload";
            this.Staff_Admin_Reload.Size = new System.Drawing.Size(145, 61);
            this.Staff_Admin_Reload.TabIndex = 6;
            this.Staff_Admin_Reload.Text = "Reload Table";
            this.Staff_Admin_Reload.UseVisualStyleBackColor = true;
            this.Staff_Admin_Reload.Click += new System.EventHandler(this.Staff_Admin_Reload_Click);
            // 
            // BackToStaff
            // 
            this.BackToStaff.Location = new System.Drawing.Point(12, 377);
            this.BackToStaff.Name = "BackToStaff";
            this.BackToStaff.Size = new System.Drawing.Size(145, 61);
            this.BackToStaff.TabIndex = 7;
            this.BackToStaff.Text = "Back";
            this.BackToStaff.UseVisualStyleBackColor = true;
            this.BackToStaff.Click += new System.EventHandler(this.BackToStaff_Click);
            // 
            // Staff_Admin_Save
            // 
            this.Staff_Admin_Save.Location = new System.Drawing.Point(783, 357);
            this.Staff_Admin_Save.Name = "Staff_Admin_Save";
            this.Staff_Admin_Save.Size = new System.Drawing.Size(145, 61);
            this.Staff_Admin_Save.TabIndex = 8;
            this.Staff_Admin_Save.Text = "Save";
            this.Staff_Admin_Save.UseVisualStyleBackColor = true;
            this.Staff_Admin_Save.Click += new System.EventHandler(this.Staff_Admin_Save_Click);
            // 
            // Staff_Admin_Delete
            // 
            this.Staff_Admin_Delete.Location = new System.Drawing.Point(783, 285);
            this.Staff_Admin_Delete.Name = "Staff_Admin_Delete";
            this.Staff_Admin_Delete.Size = new System.Drawing.Size(145, 61);
            this.Staff_Admin_Delete.TabIndex = 9;
            this.Staff_Admin_Delete.Text = "Delete";
            this.Staff_Admin_Delete.UseVisualStyleBackColor = true;
            this.Staff_Admin_Delete.Click += new System.EventHandler(this.Staff_Admin_Delete_Click);
            // 
            // staffIDDataGridViewTextBoxColumn
            // 
            this.staffIDDataGridViewTextBoxColumn.DataPropertyName = "Staff_ID";
            this.staffIDDataGridViewTextBoxColumn.HeaderText = "Staff_ID";
            this.staffIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.staffIDDataGridViewTextBoxColumn.Name = "staffIDDataGridViewTextBoxColumn";
            this.staffIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // posDataGridViewTextBoxColumn
            // 
            this.posDataGridViewTextBoxColumn.DataPropertyName = "Pos";
            this.posDataGridViewTextBoxColumn.HeaderText = "Pos";
            this.posDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.posDataGridViewTextBoxColumn.Name = "posDataGridViewTextBoxColumn";
            this.posDataGridViewTextBoxColumn.Width = 150;
            // 
            // salaryDataGridViewTextBoxColumn
            // 
            this.salaryDataGridViewTextBoxColumn.DataPropertyName = "Salary";
            this.salaryDataGridViewTextBoxColumn.HeaderText = "Salary";
            this.salaryDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.salaryDataGridViewTextBoxColumn.Name = "salaryDataGridViewTextBoxColumn";
            this.salaryDataGridViewTextBoxColumn.Width = 150;
            // 
            // fnameDataGridViewTextBoxColumn
            // 
            this.fnameDataGridViewTextBoxColumn.DataPropertyName = "Fname";
            this.fnameDataGridViewTextBoxColumn.HeaderText = "Fname";
            this.fnameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.fnameDataGridViewTextBoxColumn.Name = "fnameDataGridViewTextBoxColumn";
            this.fnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // lnameDataGridViewTextBoxColumn
            // 
            this.lnameDataGridViewTextBoxColumn.DataPropertyName = "Lname";
            this.lnameDataGridViewTextBoxColumn.HeaderText = "Lname";
            this.lnameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.lnameDataGridViewTextBoxColumn.Name = "lnameDataGridViewTextBoxColumn";
            this.lnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // Staff_Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(970, 450);
            this.Controls.Add(this.Staff_Admin_Delete);
            this.Controls.Add(this.Staff_Admin_Save);
            this.Controls.Add(this.BackToStaff);
            this.Controls.Add(this.Staff_Admin_Reload);
            this.Controls.Add(this.Staff_Admin_LName);
            this.Controls.Add(this.Staff_Admin_FName);
            this.Controls.Add(this.Staff_Admin_Pos);
            this.Controls.Add(this.Staff_Admin_Salary);
            this.Controls.Add(this.Staff_Admin_ID);
            this.Controls.Add(this.Staff_Admin_Grid_View);
            this.Name = "Staff_Admin";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Staff_Admin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Staff_Admin_Grid_View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTAFFBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Staff_Admin_Grid_View;
        private mssql1903299DataSet4 mssql1903299DataSet4;
        private System.Windows.Forms.BindingSource sTAFFBindingSource;
        private mssql1903299DataSet4TableAdapters.STAFFTableAdapter sTAFFTableAdapter;
        private System.Windows.Forms.TextBox Staff_Admin_ID;
        private System.Windows.Forms.TextBox Staff_Admin_Salary;
        private System.Windows.Forms.TextBox Staff_Admin_Pos;
        private System.Windows.Forms.TextBox Staff_Admin_FName;
        private System.Windows.Forms.TextBox Staff_Admin_LName;
        private System.Windows.Forms.Button Staff_Admin_Reload;
        private System.Windows.Forms.Button BackToStaff;
        private System.Windows.Forms.Button Staff_Admin_Save;
        private System.Windows.Forms.Button Staff_Admin_Delete;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn posDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salaryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lnameDataGridViewTextBoxColumn;
    }
}