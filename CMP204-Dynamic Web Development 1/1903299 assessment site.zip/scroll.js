//$npm i js - cookie;
let created = false;

function loadDoc() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            document.getElementById("Old").innerHTML = xhttp.responseText;
        }
    };
    xhttp.open("GET", "Old_Chorus.txt", true);
    xhttp.send();
}

$(document).ready(function () {
  // Initialize Tooltip
  $('[data-toggle="tooltip"]').tooltip(); 
  
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {

      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
})

if (localStorage.getItem("cookieShown") != "shown") {
    $(".cookie-banner2").fadeIn();
    localStorage.setItem("cookieShown", "shown")
};

if (localStorage.getItem("cookieShown") == "shown") {
    $(".cookie-banner2").fadeIn();
};

$(".Agree").click(function () {
    $(".cookie-banner2").fadeOut();
    localStorage.setItem("cookieShown", "s");

});

$(".DisAgree").click(function () {
    $(".cookie-banner2").fadeOut();
    localStorage.setItem("cookieShown", "s");
});

function AHG() {
    
        var addon = document.createElement("p");
       var textaddon = document.createTextNode("Everything is nothing like before I've always hated goodbyes, I've tried to hold it together, Clinging onto memories I swore, That I could hang on forever, But the end of the road wasn't far ahead, I let go and I suddenly woke in my bed, Rubbed the haze from my eyes, I've always hated goodbyes");
       addon.appendChild(textaddon);
       document.getElementById("AHG2").appendChild(addon);
       
      created = true;
          
}

function AHGOnce() {
    if (!created) AHG(); 
}

function AHG_C() {

    
        var x = document.getElementById("AHG2");
        if (x.style.display === "none") {
          x.style.display = "block";
        } else {
          x.style.display = "none";
        }
    
}

$(document).ready(function() {


    $("#Old_remove").click(function () {        
        $("Old").toggle();
    });

    $("#Two_remove").click(function () {
        $("#two").toggle();
    });

});   

$("#Two_tog").click(function () {
        $.ajax({
            url: "Two_Chorus.txt", success: function (result) {
                $("#Two").html(result);
                
            }
        });
        $("Two").toggle();    
});

