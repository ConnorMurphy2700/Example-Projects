<?php

require ('connect.php');
$myusername=test_input($_post['name']);
$mypassword=test_input($_post['password']);


echo $mypassword;
echo $myusername;

$sql = $conn->prepare("SELECT * FROM Music_Account WHERE username == ?");
echo $sql;
mysqli_stmt_bind_param($sql, 's', $myusername);
mysqli_stmt_execute($sql);
mysqli_stmt_bind_result ($sql, $Uname, $pass); 


while (mysqli_stmt_fetch($sql)) {
    if(password_verify( $mypassword, $pass)) 
    { 

    $_SESSION['name'] = $myusername ;
    $cookie_name = 'username';
    $cookie_value = $_SESSION['username'];
    setcookie($cookie_name,$cookie_value, time() + (86400), "/");
    $_SESSION['password'] = $mypassword;
    header('location: comment.php');
    }
    
    elseif ($Uname == "")  {
        echo "<p>Username: $myusername is not registered</p>";
        echo "<p>No matching User account</p>";
        header('Refresh: 2; URL = index.php');
    }

    else
            {
            echo "<p>Incorrect Credentials entered $username</p>";
            header('Refresh: 2; URL = index.php');
            }
}

mysqli_close($conn);

function test_input($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
