<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  
  <title>Divide Music Profile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style.css" />



</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50">

<?php 
  ini_set('display_errors', 1);  
  ini_set('display_startup_errors', 1);  
  error_reporting(E_ALL);  
      
?>

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <img src="logo.png" alt="Takt OP websites logo" style="width:60px;height:60px;">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#myPage">HOME</a></li>
        <li><a href="req.html">Requierments</a></li>
        <li><a href="#band">BAND</a></li>
        <li><a href="#tour">TOUR</a></li>
        <li><a href="#contact">CONTACT</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">MORE
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Merchandise</a></li>
            <li><a href="#">Extras</a></li>
            <li><a href="#">Media</a></li> 
          </ul>
        </li>
        <li><a href="#"><span class="glyphicon glyphicon-search"></span></a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="cookie-banner2" >
<table>
  <tr>
    <th>Takt OP.COM PRIVACY POLICY </th>
  </tr>
  <tr>
    <td>If you sign up to use this website’s services, we may keep personal information about you. This will include your name, home address, email, and phone number.</td>
    <td><img src="Stamp.jpg" alt="A Wax Stamp" style="width:60px;height:60px;"></td>    
  </tr>
  <tr>
    <td>We would like to use your information to provide better services to you, and adverts from 3rd parties. Opt in here.</td>
    <td><img src="Timer.png" alt="An hour glass" style="width:60px;height:60px;"></td>    
  </tr>
  <tr>
    <td>We would like to collect all order information to help us to predict global trends. Opt in here</th>
  </tr>
  <tr>
    <td>If you have any questions or comments about this privacy policy, or the data collected, email gdpr@website.com</th>
    <td><button type="button"  class="Agree">Agree</button></td>
  </tr>
  <tr>
    <td>Your data is stored safely and securely. If we do lose your data we will be fined by the Information Commissioner</th>
  </tr>
  <tr>
    <td>Order information is kept to meet legal requirements. Your personal Information will be deleted if you do not use this website for a Month</th>
    <td><button type="button" class="DisAgree">DisAgree</button></td>
  </tr>
 </table> 
</div>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="DivideLogo2.jfif" alt="Divides frist logo" class="logo">
        <img src="DivideLogo.png" alt="Divides frist logo" class="logo">
        <img src="DivideLogo1.png" alt="Divides frist logo" class="logo">
        <div class="carousel-caption">
          <h3>His new logo</h3>
          <p>The new logo for Divide Music in a long line of personaly made logos</p>
        </div>      
      </div>

      <div class="item">
        <img src="Divide_Inperson.jpg" alt="Divide Music in portrait">
        <div class="carousel-caption">
          <h3>Divide Music</h3>
          <p>Divide music or real name Alex</p>
        </div>      
      </div>
    
      <div class="item">
        <img src="Divide_concert.jpg" alt="Divide Music at a concert">
        <div class="carousel-caption">
          <h3>Concert</h3>
          <p>Divide music at concert</p>
        </div>      
      </div>
    </div>

    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
</div>

<div id="band" class="container text-center">
  <h3>THE SINGER</h3>
  <p><em>He love's music!</em></p>
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse vulputate nibh eget urna scelerisque efficitur. Proin a sem ac nunc condimentum ultrices quis eget neque. Cras a accumsan tellus. Proin eget sagittis nisi, in fringilla ex. Ut nec mattis justo. Sed convallis enim ut accumsan hendrerit. Sed imperdiet efficitur dui non pretium. Cras ut arcu eget leo pulvinar ultricies.</p>
  <p>Praesent a iaculis lacus. Phasellus vitae ultricies metus. Aliquam vel ex eleifend, placerat ante quis, congue nisi. Sed sagittis lacus quis elementum facilisis. In rhoncus lobortis leo eget dictum. Proin sapien velit, malesuada a blandit id, consectetur vitae odio. In hac habitasse platea dictumst. Aliquam sapien urna, sollicitudin nec sagittis et, imperdiet sit amet libero. Pellentesque laoreet id elit at interdum. Nunc quis varius nulla, non consectetur sem. Vivamus pretium enim iaculis velit viverra auctor. Ut dapibus augue urna, vel ullamcorper tellus sodales ac. Nullam quis lectus ac dolor maximus sagittis. Curabitur tristique eleifend maximus. In tempor in magna at dignissim. Nullam finibus sed nibh vel ornare.</p>
  <p>click on the albums below to see their coruses</p>
  <br>
  <div class="row">
    <div class="col-sm-4">
      <p class="text-center"><strong>always hated goodbyes</strong></p><br>
      <a href="#demo" data-toggle="collapse">
        <img src="always hated goodbyes.jfif" class="img-circle person" alt="Divide's single always hated goodbyes" width="255" height="255">
      </a>
      <div id="demo" class="collapse">
        <p>always hated goodbyes</p>
        <p>Release Date: 2021-05-11</p>
        <p>Soft Rock</p>
        <button id = "AHG" onclick="AHGOnce()"><p><b>Click here to hide or show the courus</b></p></button>
        <p id = "AHG2"></p>
        
      </div>
    </div>
    <div class="col-sm-4">
      <p class="text-center"><strong>old habits</strong></p><br>
      <a href="#demo2" data-toggle="collapse">
        <img src="old habits.png" class="img-circle person" alt="Divide's single old habits" width="255" height="255">
      </a>
      <div id="demo2" class="collapse">
        <p>Old Habits</p>
        <p>Release Date: 2018-21-04</p>
        <p>Soft Rock</p>
        <button id = "Old_tog" onclick="loadDoc()"><p><b>Click here to see the Songs courus</b></p></button>
        <p id = "Old"></p>
       
     </div>
    </div>
    <div class="col-sm-4">
      <p class="text-center"><strong>Two Faces</strong></p><br>
      <a href="#demo3" data-toggle="collapse">
        <img src="Two Faces.png" class="img-circle person" alt="Divide's single Two Faces" width="255" height="255">
      </a>
      <div id="demo3" class="collapse">
        <p>Two Faces</p>
        <p>Release Date: 2021-11-06</p>
        <p>Soft Rock</p>
        <button id = "Two_tog" onclick="two();"><p><b>Click here to see the Songs courus</b></p></button>
         <p id = "Two"></p>
   
      </div>
    </div>
  </div>
</div>

<!-- TOUR Section -->
<div id="tour" class="bg-1">
 
  <div class="container"> 
  <h3 class="text-center">Fan Submissions</h3>
  <p class="text-center"><em>We love our hearing from our fans!</em></p>


<?php
require ('connect.php');

$sql = "SELECT ID,username, Input_date, comment FROM Music_Comments2";

$result = mysqli_query($conn, $sql);


if (mysqli_num_rows($result)>0) {
          while ($row = mysqli_fetch_assoc($result)) {
            echo "ID " .$row["ID"]. " Username " .$row["username"]. " Posted " .$row["Input_date"]. " Comment made " .$row["comment"]. "</p>";
          }
}else {
  echo "0 Results";
}

mysqli_close($conn);

?>

  <div class="row">
    <div class="col-md-4">
      <p>Fan? Drop a note.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span>WakeFeild, UK</p>
      <p><span class="glyphicon glyphicon-phone"></span>Phone: +00 1515151515</p>
      <p><span class="glyphicon glyphicon-envelope"></span>Email: mail@mail.com</p>
    </div>
    <div class="col-md-4">
      <div class="row">
          <h1>Login to your account<h1>
          <form action="Password_Check.php" method="post">
          <input type="text" id="name" name="name">
          <br>
          <input type="password" id="password" name="password">
          <br>
          <input type="submit">
         </form>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="row">
      <h1>make an account <h1>
          <form action="register.php" method="post">
            <input type="text" id="name" name="name">
            <br>
            <input type="password" id="password" name="password">
            <br>
            <input type="submit">
          </form>
      </div>
    </div>  
</div>    
</div>

<!-- Contact Section -->
<div id="contact" class="container">

<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Update</a></li>
    <li><a data-toggle="tab" href="#menu1">Insert</a></li>
    <li><a data-toggle="tab" href="#menu2">Delete</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
        <form id="form" name="form" method="post" action="update.php">  
         <label>Enter the ID number of the comment you want to change  -  
          <input type="number" name="ID" id="ID" />  
         </label>  
        <p>    
         <label>New comment -    
          <input type="text" name="comments" id="comments" />    
         </label>  
        </p>  
        <p>    
         <input type="hidden" id="choice" name="choice" value="1"> 
         <input type="submit" name="button"  value="Submit" />  
        </p>
        </form>
    </div>
    <div id="menu1" class="tab-pane fade">
        <form id="form" name="form" method="post" action="insert.php">  
         <label>Enter the Comment you want to make -    
          <input type="text" name="comments" id="comments" />    
         </label>  
          <input type="hidden" id="choice" name="choice" value="2"> 
          <input type="submit" name="button"  value="Submit" />  
        </form>
    </div>
    <div id="menu2" class="tab-pane fade">
    <form id="form" name="form" method="post" action="delete.php">  
     <label>Enter the ID number of the comment you want to delete  -  
      <input type="number" name="ID" id="ID" />  
     </label>  
    <p>    
     <input type="hidden" id="choice" name="choice" value="3"> 
     <input type="submit" name="button"  value="Submit" />  
    </p>
    </form>
    </div>
  </div>


  
  <br>
  <h3 class="text-center">From The Blog</h3>  
  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Rustage</a></li>
    <li><a data-toggle="tab" href="#menu1">Chandler</a></li>
    <li><a data-toggle="tab" href="#menu2">Charlie</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <h2 class="text-center">Rustage, Fellow Rapper</h2>
      <p class="text-center">Relly Chill dude and a bastion of creativity</p>
    </div>
    <div id="menu1" class="tab-pane fade">
      <h2 class="text-center">Chandler Bing, Editor</h2>
      <p class="text-center">Always a pleasure to work with!</p>
    </div>
    <div id="menu2" class="tab-pane fade">
      <h2 class="text-center">Charlie Day, Event Orginiser</h2>
      <p class="text-center">Sometimes I enjoy the show, but other times I'm jealous of the crowd since i cant join in.</p>
    </div>
  </div>
</div>

<footer class="text-center">
  <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>
</footer>
<script src="scroll.js"></script>
</body>
</html>
