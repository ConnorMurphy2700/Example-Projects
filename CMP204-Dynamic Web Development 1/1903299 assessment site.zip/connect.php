<?php
           //connection details
           $servername = "lochnagar.abertay.ac.uk";
           $dbusername = "sql1903299" ;
           $dbpassword = "2Gfjtqa6Kp4h";
           $dbname = "sql1903299";
       
           
           $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
           
       
         if ($conn->connect_error) {
          die("Connection failure: try again" . $conn->connect_error);
            }
?>