<?php

    session_start();
    $call=$_POST['choice'];
    $com=$_POST['comments'];
    $find=$_POST['ID'];
    



    $com=htmlspecialchars($com);
    $find=htmlspecialchars($find);
    $com=trim($com);
    $find=trim($find);
    $com=stripslashes($com); 
    $find=stripslashes($find);

 switch ($call)
 {
    case 1:
        update();
        echo"test1";
       // header("location: comment.php"); 
        break;
    case 2:
        delete();
        echo"test2";
       // header("location: comment.php");
        break;
    case 3:
        insert();
        echo"test3";
      //  header("location: comment.php");
        break;
  }  

  function update ($){
    //connection details
    $servername = "lochnagar.abertay.ac.uk";
    $dbusername = "sql1903299";
    $dbpassword = "2Gfjtqa6Kp4h";
    $dbname = "sql1903299";


    $conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);

   if ($find != null) {
     echo "please enter information in each box";
   }

   if ($com != null) {
    echo "please enter information in each box";
  }

    if (!$conn) {
        die("Connection Failed: ".mysqli_connect_errorr());
    };

    else {
      $query->prepare("UPDATE Music_Comments SET comment =? WHERE id = ? "); 
      $query->bind_param("si",$com,$find);  
      $query->execute();
     
    };
     mysqli_close($conn);
  };


  function delete(){
    //connection details
   $servername = "lochnagar.abertay.ac.uk";
   $dbusername = "sql1903299";
    $dbpassword = "2Gfjtqa6Kp4h";
    $dbname = "sql1903299";

    if ($find != null) {
      echo "please enter information in each box";
    }


    $conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);

      if (!$conn) {
        die("Connection Failed: ".mysqli_connect_errorr());
    }

    else {
      $query->prepare("DELETE * FROM Music_Comments WHERE id = ?" ); 
      $query->bind_param("i",$find);  
      $query->execute();
    }
    mysqli_close($conn);
  };
  
    function insert($com){
        //connection details
      $servername = "lochnagar.abertay.ac.uk";
      $dbusername = "sql1903299";
      $dbpassword = "2Gfjtqa6Kp4h";
      $dbname = "sql1903299";

      if ($com != null) {
        echo "please enter information in each box";
      }


      $conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);

        if (!$conn) {
            die("Connection Failed: ".mysqli_connect_errorr());
        }

        else {
          $query->prepare("INSERT INTO (username,Input_date, comment, pass) VALUE($_SESSION['name'], date("Y/m/d h:i:sa"), ?, $_SESSION['password']"); 
          $query->bind_param("s",$com);  
          $query->execute();
        }
        mysqli_close($conn);
    }

?>