<?php
// Start the session
session_start();

if (isset($_SESSION['name'])) {
  header("location: index.php");
};
$_SESSION['start'] = time();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  
  <title>Divide Music Profile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="style.css" />



</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50">

<?php
  
?>
<?php 
  ini_set('display_errors', 1);  
  ini_set('display_startup_errors', 1);  
  error_reporting(E_ALL);  
?>

<div class="cookie-banner" style="display: none">
<table>
  <tr>
    <th>Takt OP.COM PRIVACY POLICY </th>
  </tr>
  <tr>
    <td>If you sign up to use this website’s services, we may keep personal information about you. This will include your name, home address, email, and phone number.</td>
    <td><img src="Stamp.jpg" alt="A Wax Stamp" style="width:60px;height:60px;"></td>    
  </tr>
  <tr>
    <td>We would like to use your information to provide better services to you, and adverts from 3rd parties. Opt in here.</td>
    <td><img src="Timer.png" alt="An hour glass" style="width:60px;height:60px;"></td>    
  </tr>
  <tr>
    <td>We would like to collect all order information to help us to predict global trends. Opt in here</th>
  </tr>
  <tr>
    <td>If you have any questions or comments about this privacy policy, or the data collected, email gdpr@website.com</th>
    <td><button type="button" onclick="Agree()" class="Agree">Agree</button></td>
  </tr>
  <tr>
    <td>Your data is stored safely and securely. If we do lose your data we will be fined by the Information Commissioner</th>
  </tr>
  <tr>
    <td>Order information is kept to meet legal requirements. Your personal Information will be deleted if you do not use this website for a Month</th>
    <td><button type="button" onclick="Disagree()" class="DisAgree">DisAgree</button></td>
  </tr>
 </table>
 
</div>



<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <img src="logo.png" alt="Takt OP websites logo" style="width:60px;height:60px;">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#myPage">HOME</a></li>
        <li><a href="req.html">Requierments</a></li>
        <li><a href="#band">BAND</a></li>
        <li><a href="#tour">TOUR</a></li>
        <li><a href="#contact">CONTACT</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">MORE
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Merchandise</a></li>
            <li><a href="#">Extras</a></li>
            <li><a href="#">Media</a></li> 
          </ul>
        </li>
        <li><a href="#"><span class="glyphicon glyphicon-search"></span></a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Contact Section -->
<div id="contact" class="container">
  <h1 class="text-center"><a href="index.php">Click here to go back to main screen</a></h1>
  <h1 class="text-center"><bold>WARNING<bold>this session will only last 15 minuets befor forceable colseing</h1>
  <h3 class="text-center">Fan Submissions</h3>
  <p class="text-center"><em>We love our hearing from our fans!</em></p>


<?php
 require ('connect.php');
 $Uname = $_SESSION['name']

$sql = "SELECT * FROM Music_Comments2 WHERE username = ?" ;
mysqli_stmt_bind_param($query, 's', $Uname);
 
$result = mysqli_query($conn, $sql);


if (mysqli_num_rows($result)>0) {
          while ($row = mysqli_fetch_assoc($result)) {
            echo "ID " .$row["ID"]. " Username " .$row["username"]. " Posted " .$row["Input_date"]. " Comment made " .$row["comment"]. "</p>";
          }
}else {
  echo "0 Results";
}

mysqli_close($conn);

?>

<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Update</a></li>
    <li><a data-toggle="tab" href="#menu1">Insert</a></li>
    <li><a data-toggle="tab" href="#menu2">Delete</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
        <form id="form" name="form" method="post" action="update.php">  
         <label>Enter the ID number of the comment you want to change  -  
          <input type="number" name="ID" id="ID" />  
         </label>  
        <p>    
         <label>New Comment -    
          <input type="text" name="comments" id="comments" />    
         </label>  
        </p>  
        <p>    
         <input type="hidden" id="choice" name="choice" value="1"> 
         <input type="submit" name="button"  value="Submit" />  
        </p>
        </form>
    </div>
    <div id="menu1" class="tab-pane fade">
        <form id="form" name="form" method="post" action="insert.php">  
         <label>Enter the Comment you want to make -    
          <input type="text" name="comments" id="comments" />    
         </label>  
          <input type="hidden" id="choice" name="choice" value="2"> 
          <input type="submit" name="button"  value="Submit" />  
        </form>
    </div>
    <div id="menu2" class="tab-pane fade">
    <form id="form" name="form" method="post" action="delete.php">  
     <label>Enter the ID number of the comment you want to delete  -  
      <input type="number" name="ID" id="ID" />  
     </label>  
    <p>    
     <input type="hidden" id="choice" name="choice" value="3"> 
     <input type="submit" name="button"  value="Submit" />  
    </p>
    </form>
    </div>
  </div>
   
<footer class="text-center">
  <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>
</footer>
<script src="scroll.js"></script>
</body>
</html>
