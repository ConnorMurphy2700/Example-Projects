<?php
            startsession(); 
            require ('connect.php');
             $com=$_POST['comments'];
             $find=htmlspecialchars($com);
             $find=trim($com);
             $find=stripslashes($com);    
             $name=User;
             $pass=;
             
      $query = mysqli_prepare("INSERT INTO 'Music_comment2' (username,Input_date, comment) VALUE($_SESSION['name'], date("Y/m/d h:i:sa"), ?"); 
      mysqli_stmt_bind_param($query,'s',$com);  
      mysqli_stmt_execute($query);

      if (!$com) {
        echo "please enter information in each box";
        header("location: comment.php");
      }

?>