<?php
          startsession();
          require ('connect.php');
          $com=$_POST['comments'];
          $find=$_POST['ID'];
          
          $com=htmlspecialchars($com);
          $find=htmlspecialchars($find);
          $com=trim($com);
          $find=trim($find);
          $com=stripslashes($com); 
          $find=stripslashes($find);   


           $query = mysqli_prepare("UPDATE Music_Comments2 SET comment = ? WHERE id = ? "); 
           mysqli_stmt_bind_param($query,'si', $com, $find);  
           mysqli_stmt_execute($query);
     
           if ($query)
           {
            header("location: comment.php");
           }
        
        
        else{
           echo "please enter information in each box";
           header("location: comment.php");    
         }  


?>