<?php 

    require ('connect.php');
    $myusername=test_input($_post['name']);
    $mypassword=test_input($_post['password']);
	$mypassword= password_hash($mypassword, PASSWORD_DEFAULT);


    $query = mysqli_prepare("INSERT INTO 'Music_Account' (username, pass) VALUE($myusername, $mypassword"); 
    mysqli_stmt_bind_param($query,'s',$com);  
    mysqli_stmt_execute($query);
		
    if($query)
		{
			echo "Registration successfully";
            header('location: comment.php');
		}

        function test_input($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
	
?>