<?php
     session_start();
     require ('connect.php');

     $find=$_POST['ID'];
     $find=htmlspecialchars($find);
     $find=trim($find);
     $find=stripslashes($find);      
     

      $query = $conn->prepare("DELETE FROM Music_Comments2 WHERE id = ?"); 
      mysqli_stmt_bind_param($query, 'i', $find);
      mysqli_stmt_execute($query); 


     if ($query)
        {
         header("location: comment.php");
        }
     
     
     else{
        echo "please enter information in each box";
        header("location: comment.php");    
      }  
?>