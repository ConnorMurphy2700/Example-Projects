import pandas as pd 
import os
from datetime import datetime , timedelta
import mysql.connector



#modification check
path = 'C:\\Users\\ninja\\Documents\\cmp419\\portfoliopart2\\pokemon.csv'
modtime = os.path.getmtime(path)
modtimed = datetime.fromtimestamp(modtime)
bounderytime = datetime.now()+ timedelta(days=-2)

if modtimed > bounderytime:
    print('time to run')
    #read in csv
    raw_data = pd.read_csv('C:\\Users\\ninja\\Documents\\cmp419\\portfoliopart2\\pokemon.csv', delimiter=",")

    #convert csv data types
    raw_data['capture_rate'] = raw_data['capture_rate'].astype('int')
    raw_data['classfication'] = raw_data['classfication'].astype('str')
    raw_data['japanese_name'] = raw_data['japanese_name'].astype('str')
    raw_data['name'] = raw_data['name'].astype('str')
    raw_data['type1'] = raw_data['type1'].astype('str')
    raw_data['type2'] = raw_data['type2'].astype('str')

    #data clean up
    raw_data['height_m'] = raw_data['height_m'].fillna(-1.0)
    raw_data['percentage_male'] = raw_data['percentage_male'].fillna(-1.0)
    raw_data['type2'] = raw_data['type2'].replace('nan', ' ')
    raw_data['weight_kg'] = raw_data['weight_kg'].fillna(-1.0)
    raw_data['abilities'] = raw_data['abilities'].str.replace(',',' ')
    raw_data['abilities'] = raw_data['abilities'].str.replace('[','')
    raw_data['abilities'] = raw_data['abilities'].str.replace(']','')

    mydb = mysql.connector.connect(
    host="lochnagar.abertay.ac.uk",
    user="sql1903299",
    password="2Gfjtqa6Kp4h",
      database="sql1903299"
    )

    mycursor = mydb.cursor()
    
    list_test = raw_data.values.tolist()

    sql = "REPLACE INTO `PokemonData`(`abilities`, `Abug`, `Adark`, `Adragon`, `Aelectric`, `Afairy`, `Afight`, `Afire`, `Aflying`, `Aghost`, `Agrass`, `Aground`, `Aice`, `Anormal`, `Apoison`, `Apsychic`, `Arock`, `Asteel`, `Awater`, `attack`, `bse`, `bhappy`, `btotal`, `cr`, `classfication`, `defense`, `eg`, `height`, `hp`, `Jname`, `name`, `pmale`, `PN`, `spAttack`, `spDefense`, `speed`, `Mtype`, `Stype`, `weight`, `generation`, `isLegend`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"

    mycursor.executemany(sql, list_test)
    mydb.commit()
else:
    print('do not update')

