# -*- coding: utf-8 -*-
'''
Created on Tur OCT 31 15:14:20 2024

@author: ninja

code within this program has been addapted from 
https://stackoverflow.com/questions/56408988/plotting-scatterplots-from-a-dataframe-on-a-grid-with-matplotlib
https://www.kaggle.com/code/jnikhilsai/cross-validation-with-linear-regression#3.-Cross-Validation:-A-Quick-Recap
https://scikit-learn.org/1.5/modules/model_evaluation.html
https://stackoverflow.com/questions/18689823/pandas-dataframe-replace-nan-values-with-average-of-columns
as well as code examples from mat510 practicals
week 8 MAT510 Practical for Week 8 AI Performance Analysis.py 
'''

import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns
import itertools
from scipy.stats import kstest
from sklearn import linear_model 
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sklearn.model_selection import GridSearchCV
from sklearn.feature_selection import RFE

def readWineData(): #reads in the wine data set preforms some EDA and returns it as a pandas data frame. 
   try:
   
      features_names = ['Alcohol','Vinyard' , 'Malic acid', 'Ash', 'Alcalinity of ash','Magnesium', 'Total phenols', 'Flavanoids', 'Nonflavanoid phenols', 'Proanthocyanins', 'Color intensity', 'Hue', 'OD280/OD315','Proline']	
      rawData_filename = "C:\\Users\\ninja\\Documents\\mat510\\Unit 2\\wine.csv"
      rawData = pd.read_csv(rawData_filename, header=None, delimiter=",", names=features_names) 
      #EDA
      print (rawData.head())
      print (rawData.shape)
      print (rawData.info())
      print (rawData.describe())
      print (rawData.isnull())
      for i in rawData.columns[rawData.isnull().any(axis=0)]:     #looping through datafran and only Applying on variables with NaN values
        rawData[i].fillna(rawData[i].mean(),inplace=True)
      return rawData
   except:
    print('error while reading data. Try again')

def normTest(testData):# takes in pandas data frame normality tests for each feature in the dataset and displays it  
      #add if to ensure correct tes and add try catch encase of errors
   
   try:
      sizeCheck = len(testData)
      if sizeCheck<50:
         print('the number of data points invalidates this test')
         return None
      for colName, colData in testData.items():
         print(colName)
         normTest=kstest(colData,'norm',mode='asymp')
         print(normTest)
   except:
    print('error while calculating try again')


def corralations(testData):#takes in pandas dataframe and displays calculated corralation coefficients as a heat map
   try:
      corr = testData.corr(method = 'spearman')
      plt.figure(figsize=(10,8))
      #plt.gca().set_xticks(rotation=45)
      #plt.gca().set_yticks(rotation=45)
      sns.heatmap(corr,annot=True,fmt=".2f", linewidth=.5)
      plt.show()   
   except:
      print('error while calculating try again')
         

def plotScatter(testData, target): #takes in pandas data frame and the name of the target variable as a string then uses the data to plot a graph for each feature 
   try: 
         #plot scatter graph for all features 
      fig, ax = plt.subplots(2, 7, figsize=(25,6))
      colours = itertools.cycle(["r", "b", "g"])

      for i,col in enumerate(testData.columns[1:]):
         #random_df.plot(kind='scatter', x=col, y='MEDV', ax=ax[i])
         if i <= 6:
            sns.regplot(x=testData[col], y=testData[target], ax=ax[0,i], color=next(colours))
         else:
            sns.regplot(x=testData[col], y=testData[target], ax=ax[1,i-7], color=next(colours))     

      ax[1,6].axis('off')                  # HIDES AXES ON LAST ROW AND COL

      fig.suptitle('Scatter Plots of '+target+' vs all the wines components ')
      fig.tight_layout()
      fig.subplots_adjust(top=0.95)

      plt.show()
      plt.clf()
      plt.close()   
   except:
      print('error while calculating try again')

#takes in the results of a GridSearchCV() with the scoring metrics of r2, neg_mean_absolute_error, neg_mean_squared_error, neg_root_mean_squared_error
#takes in the name of the paired test and train results for one of the above metrics as strings
#also takes in the name for the y label of the graph, the graphs title and the model beeing tested as strings 
#then plots the results as a graph
def displayTrainingResults(testResults, testVariable, trainVariable, Ylabel, title, MLModel):
   plt.plot(testResults["param_n_features_to_select"], testResults[testVariable])
   plt.plot(testResults["param_n_features_to_select"], testResults[trainVariable])
   plt.xlabel('number of features')
   plt.ylabel(Ylabel)
   plt.title('Kfold '+ title + MLModel)
   plt.legend(['test score', 'train score'], loc='lower right')
   plt.show()


#takes in a data frame the names of the featurs being plotted the tital of the graph and the metric for the y axis
#plots the metric results from a girdserchCV
def displayResultsComparison(results, model1, model2, model3, Title, metric):
   ax = results[[model1,model2, model3]].plot(kind='line', title =Title, figsize=(15, 10), fontsize=12)
   ax.legend(['Lasso', 'ElasticNet', 'Ridge'])
   ax.set_xlabel("N Feature", fontsize=12)
   ax.set_ylabel(metric, fontsize=12)
   plt.show()

def main():
   #taking in data
   try:
    wineData = readWineData()
   except:
      print('Error reading in data program closing')
      exit(0)
   #preforming a normality test on all fearures 
   normTest(wineData)

   #calculating and displaying coralations 
   corralations(wineData)

   #pot scattagraph for all features 
   plotScatter(wineData, 'Alcohol')
  

   # transform data
   scaler = StandardScaler()
   scaledData =  pd.DataFrame(scaler.fit_transform(wineData),columns = wineData.columns)
   #print(scaledData)


   #split the data into training and testing data sets 
   cols = ['Vinyard', 'Malic acid', 'Ash', 'Alcalinity of ash','Magnesium', 'Total phenols', 'Flavanoids', 'Nonflavanoid phenols', 'Proanthocyanins', 'Color intensity', 'Hue', 'OD280/OD315','Proline']	
   X = scaledData.loc[:, cols].values
   y = scaledData.loc[:,'Alcohol'].values
   X_train, X_test, y_train, y_test = train_test_split(X,y, train_size=0.7, test_size=0.3, shuffle=True)
   print ("X_train, y_train:", X_train.shape, y_train.shape)
   print ("X_test, y_test:", X_test.shape, y_test.shape)

   # step-1: create a cross-validation scheme
   folds = KFold(n_splits = 5, shuffle = True, random_state = 100)

   # step-2: specify range of hyperparameters to tune
   hyper_params = [{'n_features_to_select': list(range(1, 14))}]


   turn = 0
   testResults = pd.DataFrame()
   trainResults = pd.DataFrame()

   # loops for each model tested 
   while turn <3:
      # step-3: perform grid search
      # 3.1 specify model
      if turn == 0:
         model = "Lasso"
         lm = linear_model.Lasso(alpha=0.1)
         lm.fit(X_train, y_train)
         rfe = RFE(lm)    
      if turn == 1:
         model = "ElasticNet"
         lm = linear_model.ElasticNet()
         lm.fit(X_train, y_train)
         rfe = RFE(lm)    
      if turn == 2:
         model = "Ridge"
         lm = linear_model.Ridge(alpha=1.0)
         lm.fit(X_train, y_train)
         rfe = RFE(lm)             

      # 3.2 call GridSearchCV()
      model_cv = GridSearchCV(estimator = rfe, 
                              param_grid = hyper_params, 
                              scoring= ['r2', 'neg_mean_absolute_error', 'neg_mean_squared_error', 'neg_root_mean_squared_error'],
                              refit='r2', 
                              cv = folds, 
                              verbose = 1,
                              return_train_score=True)      

      # fit the model
      model_cv.fit(X_train, y_train) 

      ##print results 
      cv_results = pd.DataFrame(model_cv.cv_results_)
      print(cv_results[['mean_test_r2', 'mean_train_r2']])
      print(cv_results[['mean_test_neg_mean_absolute_error', 'mean_train_neg_mean_absolute_error']])
      print(cv_results[['mean_test_neg_mean_squared_error', 'mean_train_neg_mean_squared_error']])
      print(cv_results[['mean_test_neg_root_mean_squared_error', 'mean_train_neg_root_mean_squared_error']])

      testResults['R2'+str(turn)] = cv_results['mean_test_r2']
      testResults['MAE'+str(turn)] = abs(cv_results['mean_test_neg_mean_absolute_error'])
      testResults['MSE'+str(turn)] = abs(cv_results['mean_test_neg_mean_squared_error'])
      testResults['RMSE'+str(turn)] = abs(cv_results['mean_test_neg_root_mean_squared_error'])

      trainResults['R2'+str(turn)] = cv_results['mean_train_r2']
      trainResults['MAE'+str(turn)] = abs(cv_results['mean_train_neg_mean_absolute_error'])
      trainResults['MSE'+str(turn)] = abs(cv_results['mean_train_neg_mean_squared_error'])
      trainResults['RMSE'+str(turn)] = abs(cv_results['mean_train_neg_root_mean_squared_error'])

      #plot results as graphs 
      displayTrainingResults(cv_results, "mean_test_r2", "mean_train_r2", "r-squared", "R2 scores", model)
      displayTrainingResults(cv_results, "mean_test_neg_mean_absolute_error", "mean_train_neg_mean_absolute_error", "MAE", "mean absolute error scores", model)
      displayTrainingResults(cv_results, "mean_test_neg_mean_squared_error", "mean_train_neg_mean_squared_error", "MSE", "Mean Squared Error scores", model)
      displayTrainingResults(cv_results, "mean_test_neg_root_mean_squared_error", "mean_train_neg_root_mean_squared_error", "RMSE", "Root Mean Squared Error scores", model)
      
      #incramenting the loop
      turn = turn + 1 
   
   #plotting test results 
   displayResultsComparison(testResults, "R20", "R21", "R22", "R2 comp test", "R2")
   displayResultsComparison(testResults, "MAE0", "MAE1", "MAE2", "MAE comp test", "MAE")
   displayResultsComparison(testResults, "MSE0", "MSE1", "MSE2", "MSE comp test", "MSE")
   displayResultsComparison(testResults, "RMSE0", "RMSE1", "RMSE2", "RMSE comp test ", "RMSE")

   # plotting training results  
   displayResultsComparison(trainResults, "R20", "R21", "R22", "R2 comp train", "R2")
   displayResultsComparison(trainResults, "MAE0", "MAE1", "MAE2", "MAE comp train", "MAE")
   displayResultsComparison(trainResults, "MSE0", "MSE1", "MSE2", "MSE comp train", "MSE")
   displayResultsComparison(trainResults, "RMSE0", "RMSE1", "RMSE2", "RMSE comp train", "RMSE")

   

if __name__=="__main__": # used encase the srip is being used as an addition so the loops dont effect the "Main" program
   main()