'''
code within this program has been addapted from 
https://stackoverflow.com/questions/26785354/normalizing-a-list-of-numbers-in-python
https://stackoverflow.com/questions/6193498/pythonic-way-to-find-maximum-value-and-its-index-in-a-list
https://datascience.stackexchange.com/questions/45118/cutting-numbers-into-fixed-buckets
as well as code examples from mat510 practicals
week 3d 
'''

import csv
import pandas as pd
import numpy as np
from bisect import bisect

def readMyFile(filename): #gets the exit data, takes in the name of the desired file
    name = []
    type = []
    attack = []
    exp = []
    catchRate = []

    with open('c:\\Users\\ninja\\Documents\\mat510\\Unitt 1\\'+ filename +'.csv', encoding="utf-8") as csvDataFile:
        csvReader = csv.reader(csvDataFile) #reads in csv file then skips the headers
        next(csvReader)


        row_count = sum(1 for row in csvReader) #chesks that the correct ammount of data has been readin hence read correctly
        if(row_count ==801):
         print('File Loaded Corectly')
        else:
         print('File Loaded Incorectly')

        csvDataFile.seek(0)
        csvReader = csv.reader(csvDataFile) #reads in csv file then skips the headers
        next(csvReader)
        for row in csvReader:        #Storing the wanted data as arrays for later use 
         name.append(row[30])
         type.append(row[36])
         attack.append(row[19])
         exp.append(row[19])
         catchRate.append(row[23])
    return name, type, attack, catchRate #returns lists of the desired columns 

def showRawData(names, types, attacks, CRate): # displays raw data takes all recorded data 
   
   print('Name   type   attack  capture rate')
   for x in range(len(names)):      
    print(''+names[x]+'  '+types[x]+'  '+attacks[x]+ '  '+CRate[x]+ '\n')
    
def transformData(names, attacks): # normalizes and displays the attack values for each pokemon, takes the name and attack lists
   temp =[eval(i) for i in attacks]
   total = max(temp)
   tData = [float(x)/total for x in attacks] # normalize function 
   for x in range(len(names)):      
    print(''+names[x]+' '+attacks[x]+'\n')
    print(''+names[x]+' '+str(tData[x])+'\n')


def Bucetisation(CaptureRate):   # takes the capture rates of the pokemon and puts them in to buckets, thakes the capture rate list
   temp =[eval(i) for i in CaptureRate]
   temp.sort()
   buckets = {}
   breakpoints = [0, 51, 101, 151, 201, 251, 271] # the partitions for the buckets 
   total = []

   for i in temp:
    buckets.setdefault(breakpoints[bisect(breakpoints, i)], []).append(i)  # spliting the data into buckets 

   for count in buckets.values():  #  finds the total number of values in each bucket.
      totalCount = sum(1 for row in count)
      total.append(totalCount)
   
   x=0
   for key in buckets:   # prints the total with in each bucket 
      print('Bucket: '+str(key)+' Bucket Count: '+ str(total[x]))
      x = x + 1
      
   

    
def minmax(names, attacks):            # gets min max for all attacks, takes the name and attack lists 
   temp = [eval(i) for i in attacks] 
   maxAttack = max(temp)
   maxAttackIndex = temp.index(maxAttack) #gets the index of the max variable in the list

   minAttack = min(temp)
   minAttackIntex = temp.index(minAttack) #gets the index of the min variable in the list

   avgAttack = sum(temp)/ len(temp) # gets the avarage of the list

   print('pokemon     Attack stat')
   print(''+names[maxAttackIndex]+' '+str(maxAttack)+'\n')
   print(''+names[minAttackIntex]+' '+str(minAttack)+'\n')
   print('Avarage Attack:'+ str(avgAttack)+'\n')


def minmaxbyType(attacks,types):  # main data exploration function, takes the attack and types lists
   Attack = [eval(i) for i in attacks]
   allTypes = list(set(types))   # gets a list of all the unique itens in the types list to get list of all types 

   for type in allTypes:  #loops through all types 
      attackHolder =[]
      for x in range(len(types)):  #loops through and gets the attacks asosated with that type 
         if types[x] == type:
            attackHolder.append(Attack[x])


      maxAttack = max(attackHolder)   # the max min and averge are calculated and displayed 
      minAttack = min(attackHolder)
      avgAttack = sum(attackHolder)/ len(attackHolder)

      print(str(type) +'    Attack stat')
      print(str(maxAttack)+'\n')
      print(str(minAttack)+'\n')
      print('Avarage Attack:'+ str(avgAttack)+'\n')

def verification(fileLink):   # verifiying the other functions using pandas, takes in the name of the desired file
       try: 
        df = pd.read_csv('c:\\Users\\ninja\\Documents\\mat510\\Unitt 1\\'+ fileLink +'.csv', delimiter=",") 
        broad = df['attack'].describe() # over all break down 
        print('Across all Pokemon')
        print(broad)

        spesific = df.groupby('type1')['attack'].describe() #brake down by type 
        print('breakdown by type') 
        print(spesific) 

        print('histogram of capture rate buckets')

        bins = np.array([0, 50, 100, 150, 200, 250, 270]) # creating a colloum for the bucket each capture rate belongs to
        df["bucket"] = pd.cut(df['capture_rate'], bins)
        bucket = df.groupby('bucket')['bucket'].count()
        print(bucket)

       except:
        print('Target file not found')


def main():
    fileCheck = True #used to loop the program 
    running = True

    while fileCheck == True: # loops until a file can be found 
        try: 
            File = input("Enter File containing data:")
            name,type,attack, CRate = readMyFile(File)
            fileCheck = False
        except:
            print('The file of that name can not be found or opened. Try Again')


    while running == True:                   # main loop of application lets user choose how to process the data 
        userChoice = input("Enter the procees you would like to run (raw data, normalize, bucket CRate, max min attack, max min by type, verify, exit):")

        match userChoice:
            case "raw data":
                showRawData(name, type, attack, CRate)

            case "normalize":
                transformData(name, attack)

            case "bucket CRate":
                Bucetisation(CRate)

            case "max min attack":
                minmax(name, attack)

            case "max min by type":
                minmaxbyType(attack, type)

            case "verify":
                verification(File)

            case "exit":
                running = False

            case _:     # to catch any miss spelling or input errors 
                print("Command Not recognised.")


if __name__=="__main__": # used encase the srip is being used as an addition so the loops dont effect the "Main" program
   main()