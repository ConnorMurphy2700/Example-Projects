# -*- coding: utf-8 -*-
"""
Created on Mon Mar 27 15:14:20 2023

@author: ninja
"""

# Importing the libraries 

import matplotlib.pyplot as plt 
import pandas as pd 
from sklearn.metrics import confusion_matrix, zero_one_loss, roc_curve, auc
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
import seaborn as sns # visualisation library
from sklearn.metrics import accuracy_score, classification_report, precision_recall_curve
from sklearn.multiclass import OneVsRestClassifier
import numpy as np

def print_score(features, target, clf, text):
  # use the given model to predict on the given features
  pred = clf.predict(features)

  # produce a classification report using sklearn's methods
  clf_report = pd.DataFrame(classification_report(target, pred, output_dict=True))

  # display everything in a fomratted way
  print(text, " Result:\n================================================")
  print(f"Accuracy Score: {accuracy_score(target, pred) * 100:.2f}%")
  print("_______________________________________________")
  
  print(f"CLASSIFICATION REPORT:\n{clf_report}")
  print("_______________________________________________")
  
  cm = confusion_matrix(target, pred)
  plt.figure()
  sns.heatmap(cm, annot=True)
  
  # can also write the cm as text
  #print(f"Confusion Matrix: \n {cm}\n")



features_names = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal', 'num']

data_dir = "C:/Users/ninja/Documents/cmp310/assessment/"
raw_data_filename = data_dir + "reprocessed.hungarian.data"
raw_data = pd.read_csv(raw_data_filename, header=None, delimiter="\s+", names=features_names) 

#Exploratory Data Analysis
print (raw_data.head())
print (raw_data.shape)
print (raw_data.info())
print (raw_data.describe())

#print (raw_data.isnull())
#print (raw_data.isnull())
#no nulls

#pwp = pd.plotting.scatter_matrix(raw_data, figsize=(50, 50), marker='0', edgecolor="k",
#hist_kwds = {'bins': 20, 'color':'blue'}, s=10, alpha=.8) # histogram and colours

cols = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal']
X = raw_data.loc[:, cols].values
y = raw_data.loc[:,'num'].values

d = preprocessing.normalize(X)
xnorm = pd.DataFrame(d, columns=cols)
#print(xnorm)


X_train, X_test, y_train, y_test = train_test_split(xnorm,y, train_size=0.8, test_size=0.2)
print ("X_train, y_train:", X_train.shape, y_train.shape)
print ("X_test, y_test:", X_test.shape, y_test.shape)

from sklearn.ensemble import RandomForestClassifier

# create Classifier object 
classif= OneVsRestClassifier((RandomForestClassifier(n_estimators = 20, random_state = 0, bootstrap = True, max_features="log2", oob_score= True)))

# fit the Classifier with x and y data 
classif.fit(X_train, y_train) 
#lin_reg_2.predict(np.array([6.5]).reshape(1, 1))


y_pred = classif.predict(X_test) # crisp predictions (0 or 1)
y_probs = classif.predict_proba(X_test) # probability predictions between [0, 1]
#y_score = classif.decision_function(X_test)

fpr = {}
tpr = {}
thresh ={}

n_class = 5

for i in range(n_class):    
    fpr[i], tpr[i], thresh[i] = roc_curve(y_test, y_probs[:,i], pos_label=i)

    
# plotting    
plt.plot(fpr[0], tpr[0], linestyle='--',color='orange', label='Class 0 vs Rest')
plt.plot(fpr[1], tpr[1], linestyle='--',color='green', label='Class 1 vs Rest')
plt.plot(fpr[2], tpr[2], linestyle='--',color='blue', label='Class 2 vs Rest')
plt.plot(fpr[3], tpr[3], linestyle='--',color='red', label='Class 3 vs Rest')
plt.plot(fpr[4], tpr[4], linestyle='--',color='black', label='Class 4 vs Rest')
plt.title('Multiclass ROC curve')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive rate')
plt.legend(loc='best')
plt.savefig('Multiclass ROC',dpi=300);
plt.plot 

y_score = []
for n in range(len(y_test)):
    label = y_test[n]
    y_score.append(sum(y_probs[n,:])) #sum probabilities of all attack categories excluding normal
y_score = np.array(y_score)
precision, recall, thresholds_precision_recall = precision_recall_curve(y_pred, y_score, pos_label=1)
auc_pr = auc(recall, precision)

print_score(X_test, y_test, classif, 'test')
print_score(X_train, y_train, classif, 'train')


print ("Computing performance metrics")
error = zero_one_loss(y_test, y_pred)

# By definition, entry i,j in a confusion matrix is the number of observations actually in group i, but predicted to be in group j
print ("Error: ", error)


plt.figure()
plt.plot(recall, precision,   label='AUC = %0.6f' % (auc_pr))
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.title('Precision Recall curve (for detecting defects of any kind)')
plt.legend(loc="lower right", prop={'size': 'small'})
plt.savefig('Precision Recall curve for RF.png')
plt.savefig('Precision Recall curve for RF.pdf')
plt.show()



testa = np.array([40, 1, 2, 140, 289, 0, 0, 172, 0, 0, -9, -9, -9])#0
testA = preprocessing.normalize([testa])
testb = np.array([48, 0, 4, 138, 214, 0, 0, 108, 1, 1.5, 2, -9, -9])#3
testB = preprocessing.normalize([testb])
testc = np.array([54, 0, 3, 130, 294, 0, 1, 100, 1, 0, 2, -9, -9])#4
testC = preprocessing.normalize([testc])
testd = np.array([49, 0, 3, 160, 180, 0, 0, 156, 0, 1, 2, -9, -9])#1
testD = preprocessing.normalize([testd])
teste = np.array([52, 1, 4, 120, 185, 0, 0, 155, 0, 0, -9, -9, -9])#2
testE = preprocessing.normalize([teste])

Test1= classif.predict(testA)
Test2 = classif.predict(testB)
Test3 = classif.predict(testC)
Test4 = classif.predict(testD)
Test5 = classif.predict(testE)

print ("the first test should value 0. clasified as ", Test1)
print ("the second test should value 3. clasified as ", Test2)
print ("the third test should value 4. clasified as ", Test3)
print ("the forth test should value 1. clasified as ", Test4)
print ("the fifth test should value 2. clasified as ", Test5)


#code developed form code example from practicals through out the moduel
#writen by Dr Salma ElSayed and Dr Sanaz Kavianpour