<?php
session_start();
$_SESSION['state'] = 1;
header("Location:MainPage.php")
?>
