<?php
?>
<form action="login.php" method="post">

    username
    <input type="text" name="uname" /> <br>
    Password:
    <input type="text" name="pass" /> <br>
    <input type="submit" name="btnSendForm" value="Execute" />
</form>
<?php
?>
