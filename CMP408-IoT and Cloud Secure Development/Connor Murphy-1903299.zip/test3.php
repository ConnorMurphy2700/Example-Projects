<?php
// page for testing if user space app worked in a php enviroment it did
shell_exec("python3 USpaceApp.py 0");
?>
