<?php
session_start();
$_SESSION['state'] = 0;
header("Location:MainPage.php")
?>
