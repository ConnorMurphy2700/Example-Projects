<!doctype html>

<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Login Page</title>
	<meta name="description" content="Home Page">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="index.css">
</head>

<body>
<div class="container">
        <div class="col-lg-12">
            <div class="page-header">
                <h1 class="text-center">CMP306: Web Services Development</h1>
            </div>
        </div>
</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" href="https://mayar.abertay.ac.uk/~2001499/cmp306/block1/view/index.php">Block 1</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="#">Block 2</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="#">Block 3</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="#">Block 4</a>
      </li>
    </ul>
  </div>
</nav>

<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

session_start();
$database = "sql1903299";
require('connect.php');

$username = test_input($_POST['username']);
$password = test_input($_POST['password']);

$lsqry = $conn->prepare("SELECT email,UserPass, FROM user
WHERE email = ?");
mysqli_stmt_bind_param($lsqry, "s", $username);
mysqli_stmt_execute($lsqry);
mysqli_stmt_bind_result($lsqry, $user, $Pword,);


while (mysqli_stmt_fetch($lsqry)) {
  if (password_verify($password, $Pword) && ($user =='admin')) {
    $_SESSION['uid'] = $user;
    $cookie_name = 'uid';
    $cookie_value = $_SESSION['uid'];
    setcookie($cookie_name,$cookie_value, time() + (86400), "/");
    header('Location: ../view/admin.php');
  }
  elseif (password_verify($password, $Pword)&& ($user !='admin')) {
    $_SESSION['uid'] = $user;
    $cookie_name = 'uid';
    $cookie_value = $_SESSION['uid'];
    setcookie($cookie_name,$cookie_value, time() + (86400), "/");
    header('Location: ../view/index.php');
  }
  elseif ($user == "")  {
    echo "<p>Username: $username is not registered</p>";
    echo "<p>No matching User account</p>";
    header('Refresh: 2; URL = ../view/login.php');
  }
  else{
    echo "<p>Incorrect Credentials entered $username</p>";
    echo "<p>Redirecting to user login </p>";
    header('Refresh: 2; URL = ../view/login.php');
  }
}
mysqli_close($conn);



	//Sanitisation
	function test_input($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
?>
</body>
</html>