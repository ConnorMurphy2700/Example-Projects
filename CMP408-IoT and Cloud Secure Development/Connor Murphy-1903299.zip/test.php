<?php
//page for gettin php configuration info
phpinfo();
?>
