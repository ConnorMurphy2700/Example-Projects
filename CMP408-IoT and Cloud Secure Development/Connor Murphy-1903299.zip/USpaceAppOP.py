#first version of user space app that used hard ware 
import RPi.GPIO as GPIO
from datetime import datetime
from datetime import date
import os
import sys

onoff =sys.argv[1]
MicPin = 3
RelayPin =4

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

GPIO.setup(MicPin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(RelayPin, GPIO.OUT, initial=GPIO.LOW)

if onoff ==1:
    os.system("./piiotest writepin 2 1")

if onoff ==0:
    os.system("./piiotest writepin 2 0")

while True:
    GPIO.output(RelayPin, GPIO.input(MicPin))
    heard = GPIO.input(RelayPin)
    if heard ==1:
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        today =date.today()
        d1 =today.strftime("%d/%m/%Y")
        print ('sound heard')
        print('Current time =', current_time)
        print('date:', d1)