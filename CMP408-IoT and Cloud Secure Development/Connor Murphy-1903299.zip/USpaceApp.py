
#main user space app used in project
import RPi.GPIO as GPIO
from datetime import datetime
from datetime import date
import os
import sys
import time
import mysql.connector

onoff =sys.argv[1]
led = 2
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(led, GPIO.OUT, initial=GPIO.LOW)

mydb = mysql.connector.connect(
    host = "cmp408-1903299.cyel0uzvtwfq.us-east-1.rds.amazonaws.com",
    user = "admin",
    password = "Hansolo01",
    database = "cmp408"    
    )

mycursor = mydb.cursor()


if int(onoff) ==1:
    os.system("./piiotest writepin 2 1")
    GPIO.output(led,GPIO.HIGH)
    print("led on")
    
if int(onoff) ==0:
    os.system("./piiotest writepin 2 0")
    GPIO.output(led, GPIO.LOW)
    print("led off")

while(int(onoff) == 1):
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    today =date.today()
    d1 =today.strftime("%d/%m/%Y")
    print ('sound heard')
    sql = "INSERT INTO sound (i_time, i_date) VALUES (%s, %s)"
    val = (current_time, d1)
    mycursor.execute(sql, val)
    mydb.commit()
    time.sleep(10)