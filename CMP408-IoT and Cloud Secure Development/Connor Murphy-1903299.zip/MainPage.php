<?php
session_start();
ini_set('display_errors');
ini_set('display_startup_errors');
error_reporting(E_ALL);

if($_SESSION['logged'] != 1){header("Location:LoginPage.php");}
$uapp ="python3 USpaceApp.py ";

$cmd = $uapp . $_SESSION['state'];
echo "command given ". $cmd;
shell_exec('/urs/bin/python3 /var/www/html/USpaceApp.py '. $_SESSION['state']);


if($_SESSION['state'] == 1){echo '<p>Device is on</p>';}
else{echo '<p>Device is off</p>';}

$servername = "cmp408-1903299.cyel0uzvtwfq.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "Hansolo01";
$dbname = "cmp408";


// Create connection
$conn =  mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Failed to connect: " . mysqli_connection_error());
}

$sql = "SELECT * FROM sound ORDER BY id DESC LIMIT 10";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    echo "Sound occured:" . $row["i_time"]. " " . $row["i_date"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();



echo '<a href="Turnon.php" class="button">Turn on</a>';
echo '<a href="Turnoff.php" class="button">Turn off</a>';
?>
