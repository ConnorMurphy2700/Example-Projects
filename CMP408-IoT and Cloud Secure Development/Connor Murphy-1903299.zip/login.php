<?php
//simple hard coded login page used due to time see loginrec for example of how a proper login system would have been implamented with more time
session_start();
if($_POST["pass"] == "password"){
	$_SESSION['logged'] = 1;
    header("Location:MainPage.php");
	}else{
	header("Location:LoginPage.php");
	}
?>
