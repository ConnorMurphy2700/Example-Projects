<?php

	include("connection.php");
	$conn =  getDatabaseConnection();
		


	function UpdateState($txt) {
		// $txt must contain the data for all fields.
		global $conn ;
		$item = json_decode($txt) ;
		$stmt = $conn->prepare("update electricimp2 SET devicestate = ?, dttm = ? where ID = ?");
		$stmt->bind_param("ssi", $state, $date, $id);
		$id = 1;
		$date = date('Y-m-d H:i:s') ;
		$state = $txt;
		$result = $stmt->execute();
		if (!$result) {$result = 0 ;}
		return $result ;
	}

	function getLED()
	{
		global $conn ;
		$sql = "SELECT * FROM electricimp2";
		$result = mysqli_query($conn, $sql);
		//  convert to JSON
		$rows = array();
		while($r = mysqli_fetch_assoc($result)) {
    		$rows[] = $r;
		}
		return json_encode($rows);
	}


	function getCurrenttemp()
	{
		global $conn ;
		$sql = "SELECT state FROM electricimp1 ORDER BY id DESC LIMIT 1;";
		$result = mysqli_query($conn, $sql);
		//  convert to JSON
		$rows = array();
		while($r = mysqli_fetch_assoc($result)) {
    		$rows[] = $r;
		}
		return json_encode($rows);
	}

	function getTemp()
	{
		global $conn ;
		$sql = "SELECT * FROM electricimp1 ORDER BY id DESC LIMIT 1";
		$result = mysqli_query($conn, $sql);
		//  convert to JSON
		$rows = array();
		while($r = mysqli_fetch_assoc($result)) {
    		$rows[] = $r;
		}
		return json_encode($rows);
	}


	function getgraph()
	{
		global $conn ;
		$sql = "SELECT * FROM electricimp1 ORDER BY id DESC LIMIT 144";
		$result = mysqli_query($conn, $sql);
		//  convert to JSON
		$rows = array();
		while($r = mysqli_fetch_assoc($result)) {
    		$rows[] = $r;
		}
		return json_encode($rows);
	}

	


	function createMessage($txt) {
		global $conn ;
		//$item = json_decode($txt) ;
		$stmt = $conn->prepare("insert into electricimp1 (deviceid, state) values (?, ?)");
		$stmt->bind_param("ss", $diviceID, $devicestate);
		$diviceID = "UyRD8DfjnI3S" ;
		$devicestate = $txt; 
		$result = $stmt->execute();
		if (!$result) {$result = 0 ;}
		return $result ;
	}

?>