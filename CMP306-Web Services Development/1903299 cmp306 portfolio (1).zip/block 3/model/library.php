<?php

	function jsonRpcFormatCheck($request) {
	//  function to check that the JSON-RPC parameters are there and correct
		$jsonrpc = $request -> jsonrpc ;
		$method = $request -> method ;
		$id = $request -> id ;
		if ( ($jsonrpc != "2.0" ) or ($method == NULL) or ($id == NULL)) {
			$return = 0 ;
		}
		else {
			$return = 1 ;
		}
		return $return ;
	} ;
	
	function checkMethodParams($method, $params) {
		switch ($method) {
    		case "UpdateState":
        		if ($params -> txt != null) {
        			$return -32602;
        		}
        		else {
        			$return = 1 ;
        		}
      			break;
            case "UpdateState":
                if ($params -> txt != null) {
                    $return -32602;
                }
                else {
                    $return = 1 ;
                }
                break;
            case "UpdateState":
                if ($params -> txt != null) {
                    $return -32602;
                }
                else {
                    $return = 1 ;
                }
                break;
            case "UpdateState":
                if ($params -> txt != null) {
                    $return -32602;
                }
                else {
                    $return = 1 ;
                }
                break;
			case "createMessage":
				if ($params -> txt != null) {
					$return -32602;
				}
				else {
					$return = 1 ;
				}
				break;
			default :
    		// method not found
        		$return = -32601;
        	break ;
        }
        return $return ;
} 
	
?>