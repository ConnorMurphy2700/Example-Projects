<?php
require_once 'database.php';
$stmt = $conn->prepare('SELECT * FROM electricimp1 ORDER BY id DESC LIMIT 144;');
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_OBJ);
echo json_encode($results);
?>