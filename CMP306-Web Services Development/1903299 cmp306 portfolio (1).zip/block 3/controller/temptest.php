<?php
//  item11.php - create a new item using JSON-RPC
error_reporting(E_ALL);

//  set up the data to be inserted
$item = new stdClass() ;
$item -> name = "Cmurphy";
$item -> diviceID = "UyRD8DfjnI3S";
$item -> body = "not yet implamented" ;

//  set up the request
$request = new stdClass();
$request -> jsonrpc = "2.0" ;
$request -> method = "Temp" ;
$request -> params = $item ;
$request -> id = "510572" ;
$txt = json_encode($request) ;
echo $txt.'<br/><br/>' ;

//  set up for the curl
$url = "https://mayar.abertay.ac.uk/~1903299/cmp306/coursework/Block3/model/index.php";
$ch = curl_init($url) ;
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
$headers = array (
	'Content-Type: application/json', 
	'Content-Length: ' . strlen($txt) ) ;
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers) ;
curl_setopt($ch, CURLOPT_POSTFIELDS, $txt);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch) ;


//  display the result of the call
echo $response ;	
echo '<a href="../view/index.php" class="btn btn-primary">Back to main page</a>';
?>
