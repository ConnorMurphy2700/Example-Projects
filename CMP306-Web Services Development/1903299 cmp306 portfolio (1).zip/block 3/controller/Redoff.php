<?php
//  item11.php - create a new item using JSON-RPC
error_reporting(E_ALL);

$curl2 = curl_init("https://agent.electricimp.com/UyRD8DfjnI3S?pin=5&state=0") ;
curl_setopt($curl2, CURLOPT_CUSTOMREQUEST, "GET");                                                                                                                                     
curl_setopt($curl2, CURLOPT_RETURNTRANSFER, true);                                                                                                                                                                                                                           
$resp = curl_exec($curl2) ;
curl_close($curl2) ;


//  display the result of the call
sleep(3);
header("Location: ../view/index.php");
?>
