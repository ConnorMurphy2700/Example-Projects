<?php
include_once("../model/api.php") ;
// get the new data
$message = file_get_contents('php://input') ;
$res = UpdateState($message) ;
echo "Added Record - ".$res ;
?>