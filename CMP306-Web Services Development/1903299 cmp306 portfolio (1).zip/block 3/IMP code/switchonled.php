<a href="https://agent.electricimp.com/UyRD8DfjnI3S?pin=5&state=1">Switch on</a><br/>
<a href="https://agent.electricimp.com/UyRD8DfjnI3S?pin=5&state=0">Switch off</a><br/>
<a href="https://agent.electricimp.com/UyRD8DfjnI3S?pin=7&state=1">Switch Green on</a><br/>
<a href="https://agent.electricimp.com/UyRD8DfjnI3S?pin=7&state=0">Switch Green off</a>