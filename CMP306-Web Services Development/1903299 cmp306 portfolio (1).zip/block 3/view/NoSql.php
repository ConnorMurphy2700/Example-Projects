<?php
  header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header('Cache-Control: post-check=0, pre-check=0', FALSE);
	header('Pragma: no-cache');
?>

<!doctype html>
<html lang="en">
    <head>
    <!-- Required meta tags -->
    	<meta charset="utf-8">
    	<meta name="viewport" content="width=device-width, initial-scale=1">

    	<!-- Bootstrap CSS -->
   	 	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
		<!-- local CSS -->
		<link rel="stylesheet" href="tools.css?v=2.0" />
		
    	<title>CMP306 - Web Services Development</title>
	</head> 
        
	<body>

	    <!-- overall container for page -->
	    <div class="container">
	    
	    	<!-- header row -->
    		<div id="header" class="card text-center">
    			<img src="../image/title01.jpg" />
    			<div class="card-img-overlay">
            		<h1 class="card-title" style="color:white;">CMP306 Web Services Development - 2022-23</h1>
            		<h2 class="card-title" style="color:white;">Connor Murphy -- 1903299</h2>
            		<h3 style="color:white;">Block 3</h3>
                </div>
    		</div><!-- Header  row -->

		 <nav class="navbar navbar-expand-lg navbar-light bg-light">
		    <div class="container-fluid">
  		
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
    	
    	      <div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="Register.php">NoSQL Solution</a>
					</li>
						</ul>
               </div>
         </nav>

        <p>The use of smart devices has increased and so too does the amount of data being sent back to the provider for processing. This necessitates the use of a NoSQL database to hold this huge amount of data. A practical example of this is HIVE IoT devices which are grouped by house (House -> devices). However, this system usually relies on there being one user for each house.</p>
        <p>If hive would like to branch out as a business decision the most profitable direction to take would be to have one house have multiple users and let a user have mutable houses with all the devices held within. My solution to this problem would be to remodel hives' NoSQL database. </p> 
        <p>Whereas the current HIVE might look something like this:</p>
        <img src="../image/report1.jpg" />
        <p>The system I am suggesting would be to allow multiple users to be recorded for each house. So, the s data dump would look something like this:  </p>
        <img src="../image/report2.jpg" />
        <p>And for the user section of the data dump:</p>
        <img src="../image/report3.jpg" />
        <p>With this set up any user registered to a particular house will be able to use any devices registered to that house. I added an admin user to make it simple to see which user in the house is in charge of the houses and the users within the house. Also, in this system, the admin user would be able to add and remove users from the house they oversee. Keeping the house data dump similar and expanding the users registered to the house it keeps the database simple and cleaner. As for allowing the user to be a part of multiple houses by using the unnormalized nature of a NoSQL database you can have data be repeated as much as you want. So, Hive could easily allow users to register at multiple houses and have control over all the devices in that house. And from the database's point of view, you would only need to add the list of house IDs to the user’s account. This way when a user logs in the application just has to follow the hierarchical structure of the user's home device by using the stored keys in the preceding part of the data.</p>
        <p>The keys could even be indexed to speed up searching by the database management system. A well-made SQL database would not allow the repetition of data in this system as well as the shear amount of data needed</p>
 
           <!-- Bootstrap Option 1: Bootstrap Bundle with Popper -->
       <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	</body>
</html>