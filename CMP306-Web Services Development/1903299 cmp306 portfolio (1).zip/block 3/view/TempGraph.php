<!doctype html>
<html lang="en">
    <head>
    <!-- Required meta tags -->
    	<meta charset="utf-8">
    	<meta name="viewport" content="width=device-width, initial-scale=1">

    	<!-- Bootstrap CSS -->
   	 	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
		<!-- local CSS -->
		<link rel="stylesheet" href="tools.css?v=2.0" />
		
    	<title>CMP306 - Web Services Development</title>
	</head> 
        
	<body>
    <p>hello</p>
<?php
					$currenttemp = getCurrenttemp();
                    echo $currenttemp;
					$extTemp;
					$intTemp;
					
				
					for($i=34;$i <39; $i++){
                            $extTemp .=$currenttemp[$i];
					}
					for($i=78;$i <83; $i++){
						$intTemp .=$currenttemp[$i];
				    }
				   //get graph data
				   $graphTemp = getgraph();
				   $graphData = json_decode($graphTemp);

				   //add data to external array
				   $extXValues= array();
				   for($i=0;$i <24; $i++){
					   $tempStr = $graphData[$i]-> state;
					   $graphExtTemp = ""; 
				   
				   for($x=14;$x <18; $x++){
					$graphExtTemp = $tempStr[$x];
				   }
                     
                   echo $currenttemp;
                   array_push($extXValues,$graphExtTemp);
				}

				//add data to interna array
				$intXValues= array();
				for($i=0;$i <24; $i++){
					$tempStr = $graphData[$i]-> state;
					$graphIntTemp = ""; 
				
				for($x=14;$x <18; $x++){
				 $graphIntTemp = $tempStr[$x];
				}

				array_push($intXValues,$graphIntTemp);
			 }

              echo '<div class = "container_fluid">';
              echo '<div class = "row">';
			  echo '<div class = "col-sm-6">';
			  echo '<p>The External Temperature is :'.$extTemp.'<p>';
			  echo '<h3>Extranal Temperature in the Past 24 Hours</h3>';
			  echo '<canvas id = "myChart" style = "width:100%;max-width:700px"></canvas>';
			?>
<script>
                        var yValues = <?php echo json_encode(array_reverse($extXValues)); ?>;
                        var xValues = [1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];

                        new Chart("myChart", {
                          type: "line",
                          data: {
                              labels: xValues,
                              datasets: [{
                                fill: false,
                                lineTension: 0,
                                backgroundColor: "rgba(0,0,255,1.0)",
                                borderColor: "rgba(0,0,255,0.1)",
                                data: yValues
                              }]
                          },
                          options: {
                              legend: {display: false},
                              scales: {
                                yAxes: [{ticks: {min: 25, max:35}}],
                              }
                          }
                        });
                  </script>


            <div class="col-sm-6">
                  <!-------------internal---------------->
                  <h3> Internal Temperature in the Past 24 Hours </h3>
                  <canvas id="myChart2" style="width:100%;max-width:700px"></canvas>
                  <script>
                  var yValues = <?php echo json_encode(array_reverse($intXValues)); ?>;
                  var xValues = [1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];

                  new Chart("myChart2", {
                    type: "line",
                    data: {
                        labels: xValues,
                        datasets: [{
                          fill: false,
                          lineTension: 0,
                          backgroundColor: "rgba(0,0,255,1.0)",
                          borderColor: "rgba(0,0,255,0.1)",
                          data: yValues
                        }]
                    },
                    options: {
                        legend: {display: false},
                        scales: {
                          yAxes: [{ticks: {min: 25, max:35}}],
                        }
                    }
                  });
                  </script>

</body>
</html>