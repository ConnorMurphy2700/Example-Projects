<?php
  header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header('Cache-Control: post-check=0, pre-check=0', FALSE);
	header('Pragma: no-cache');
  header("Refresh:5");
?>

<!doctype html>
<html lang="en">
    <head>
    <!-- Required meta tags -->
    	<meta charset="utf-8">
    	<meta name="viewport" content="width=device-width, initial-scale=1">

    	<!-- Bootstrap CSS -->
   	 	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
		<!-- local CSS -->
		<link rel="stylesheet" href="tools.css?v=2.0" />
		
    	<title>CMP306 - Web Services Development</title>
	</head> 
        
	<body>

	    <!-- overall container for page -->
	    <div class="container">
	    
	    	<!-- header row -->
    		<div id="header" class="card text-center">
    			<img src="../image/title01.jpg" />
    			<div class="card-img-overlay">
            		<h1 class="card-title" style="color:white;">CMP306 Web Services Development - 2022-23</h1>
            		<h2 class="card-title" style="color:white;">Connor Murphy -- 1903299</h2>
            		<h3 style="color:white;">Block 3</h3>
                </div>
    		</div><!-- Header  row -->

		 <nav class="navbar navbar-expand-lg navbar-light bg-light">
		    <div class="container-fluid">
  		
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
    	
    	      <div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="NoSql.php">NoSQL Solution</a>
					</li>
						</ul>
               </div>
         </nav>


         <div class="row">
         <?php
            include("../model/api.php") ;
					  $itemtxt = getLED() ;
					  $item = json_decode($itemtxt) ;
					  for ($i=0 ; $i<sizeof($item) ; $i++) {
						echo '<div class="col-lg-4 col-md-4 col-sm-4">' ;
						echo '<div class="card">' ;
						echo '<div class="card-header">' ;
						echo 'LED current status' ;
						echo '</div>' ;
						echo '<div class="card-block">' ;
						echo '<p>'.$item[$i] -> dttm.'</p>'; 
                        echo '<p>'.$item[$i] -> devicestate.'</p>'; 
						echo '</div>' ;
						echo '</div>' ;
						echo '</div>' ;
					}


					  $itemtxt = getTemp() ;
					  $item = json_decode($itemtxt) ;
					  for ($i=0 ; $i<sizeof($item) ; $i++) {
						echo '<div class="col-lg-4 col-md-4 col-sm-4">' ;
						echo '<div class="card">' ;
						echo '<div class="card-header">' ;
						echo 'temperature current status' ;
						echo '</div>' ;
						echo '<div class="card-block">' ;
						echo '<p>'.$item[$i] -> dttm.'</p>'; 
            echo '<p>'.$item[$i] -> state.'</p>'; 
						echo '</div>' ;
						echo '</div>' ;
						echo '</div>' ;
					}
				?>
				<div class="col-lg-4 col-md-4 col-sm-4">
              <div class="card">
               <div class="card-header">
                <h1>temp table</h1>
               </div>
			   <a href="TempGraph.php">24 Hour Temperature Graph</a>
              </div>  
                </div>  
			</div><!-- row -->




                <!-- red on  -->
             <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="card">
               <div class="card-header">
                <h1>red</h1>
               </div>
               <h3>Red on</h3>
                <form action="../controller/Redon.php" method="post">
                <input type="submit">
                </form> 
                <h3>Red off</h3>
                <form action="../controller/Redoff.php" method="post">
                <input type="submit">
                </form>
              </div>  
			</div><!-- row -->
			<!-- green on  -->
			<div class="col-lg-4 col-md-4 col-sm-4">
              <div class="card">
               <div class="card-header">
                <h1>Green</h1>
               </div>
               <h3>Green on</h3>
                <form action="../controller/Greenon.php" method="post">
                <input type="submit">
                </form> 
                <h3>Green off</h3>
                <form action="../controller/Greenoff.php" method="post">
                <input type="submit">
                </form>
              </div>  
                </div>  
			</div><!-- row -->
  </div><!-- container -->





        
    <!-- Bootstrap Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	</body>
</html>