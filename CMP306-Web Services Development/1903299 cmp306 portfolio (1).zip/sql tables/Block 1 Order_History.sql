-- phpMyAdmin SQL Dump
-- version 5.2.0-1.el8.remi
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 13, 2022 at 11:30 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sql1903299`
--

-- --------------------------------------------------------

--
-- Table structure for table `Order_History`
--

CREATE TABLE `Order_History` (
  `Order_ID` int(11) NOT NULL,
  `taction` varchar(8) NOT NULL,
  `total` float NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Order_History`
--

INSERT INTO `Order_History` (`Order_ID`, `taction`, `total`, `status`) VALUES
(1, 'gl234517', 10.99, 1),
(2, 'gl10022', 30, 0),
(3, 'gl111111', 15, 1),
(4, 'gl343434', 25, 1),
(5, 'gl579368', 8.16, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Order_History`
--
ALTER TABLE `Order_History`
  ADD PRIMARY KEY (`Order_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Order_History`
--
ALTER TABLE `Order_History`
  MODIFY `Order_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
