-- phpMyAdmin SQL Dump
-- version 5.2.0-1.el8.remi
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 13, 2022 at 11:30 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sql1903299`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `firstname` varchar(15) NOT NULL,
  `surname` varchar(25) NOT NULL,
  `email` varchar(80) NOT NULL,
  `mphone` varchar(15) NOT NULL,
  `UserPass` varchar(150) NOT NULL,
  `admin` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `firstname`, `surname`, `email`, `mphone`, `UserPass`, `admin`) VALUES
(1, 'connor', 'Murphy', 'admin', '13500343267', '$2y$10$iy7Jj1WxYmOSG0d.TVFfIOLkm.SFzXiIulAKlvJqQuJI50FuMqi5u', '1'),
(2, 'John', 'Smith', 'someone@gmail.com', '4479432348', '$2y$10$OVuNP33vwLrPWR2L068HHOWQ14oyDaftFZNKz.dc/jD1a2m6tz6BW', '0'),
(7, 'test', 'test', 'admin@gmail.com', '1234', '$2y$10$.Nki75ozZ5DQeNv/wxLQ3.b6iBHrxqy/7GUzHRXS2EOyVUQc.hC2.', '0'),
(8, 'callum', 'doe', 'doe@gmail.com', '12345', '$2y$10$.uznPx1FC3y8UWaXpbNgi.BdNo/uNqMavSX.JV6K1dSj/884jedOi', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
