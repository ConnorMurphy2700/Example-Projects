-- phpMyAdmin SQL Dump
-- version 5.2.0-1.el8.remi
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 13, 2022 at 11:30 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sql1903299`
--

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `ID` int(11) NOT NULL,
  `headline` varchar(200) NOT NULL,
  `date` varchar(15) NOT NULL,
  `main` varchar(400) NOT NULL,
  `author` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`ID`, `headline`, `date`, `main`, `author`) VALUES
(1, 'Cafe One is the number one stop for good food', '2022-10-20', 'If you are looking for good food in Inverness, then look no further than Cafe 1. Based in the heart of the Highland capital on Castle Street, the restaurant stands out from the crowd. Excellent service is what the dining establishment is known for, due to the nurturing and care of its staff.', 'Rachel Smart'),
(2, 'Details revealed for Inverness Big Bang Bonfire at the Bught', '2022-10-23', 'Following the success of last years Covid beating firework display, the Inverness Events and Festivals Working Group is pleased to announce that the Bught Park will once again be the stage for the big traditional bonfire and firework display. The event will take place on Saturday November 5 with gates opening at 5pm and the firework display ending just before 7pm.', 'Connor Murphy'),
(3, 'Essential surfacing improvements planned for A82 near Craig Dunain in Inverness', '2022-10-25', 'DRIVERS going through Inverness are being warned of overnight road closures and speed restrictions to allow essential works in the Craig Dunain area. BEAR Scotland will be carrying out essential road surface improvements on the A82 at Craig Dunain, with works set to get underway from Wednesday, October 26.Taking place over eight nights, the works will start at 7.30pm', 'Federica Stefani'),
(4, 'Man jailed for possession of more than 11.000 Pounds of cocaine and heroin.', '2022-09-19', 'A DRUG addict who was caught by police with several thousand pounds worth of Class A narcotics in Inverness city center has been jailed for a year. Inverness Sheriff Court heard that officers received information that Dean Barrow, of Union Street, Inverness, was in possession of illegal substances. ', 'Connor Murphy'),
(5, 'New tour dates announced by comedy farmer Jim Smith.', '2022-10-01', 'Fans of farming and laughs are in for a treat as everyones favorite comedy farmer Jim Smith has announced new tour dates.\r\nFollowing on from the huge success of his last Back To The Teuchter tour, Perthshire farmer and comedian Jim Smith is set to don his checked shirt again as he returns with his brand new show. He will perform at Aberdeen\'s Music Hall on Friday, October 6, 2023.', 'Kyle Ritchie '),
(6, 'Weekend plan for the Take One Action festival at Eden Court in Inverness', '2022-10-15', 'The UKs film festival Take One Action focuses on global change heads to Inverness for a weekend format for the first time (October 28-30).\r\nThe theme of this 15th year is the land beneath our feet and it includes films to come and see at Eden Court and others to watch digitally. As ever, it is crossing borders and emphasizing the connections between places', 'Margaret Hale');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
