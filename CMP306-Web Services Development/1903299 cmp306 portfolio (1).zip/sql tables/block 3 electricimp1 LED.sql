-- phpMyAdmin SQL Dump
-- version 5.2.0-1.el8.remi
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 13, 2022 at 11:28 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sql1903299`
--

-- --------------------------------------------------------

--
-- Table structure for table `electricimp1`
--

CREATE TABLE `electricimp1` (
  `ID` int(114) NOT NULL,
  `deviceid` varchar(16) NOT NULL,
  `dttm` datetime NOT NULL DEFAULT current_timestamp(),
  `state` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `electricimp1`
--

INSERT INTO `electricimp1` (`ID`, `deviceid`, `dttm`, `state`) VALUES
(2, 'UyRD8DfjnI3S', '2022-11-22 15:48:17', 'not yet implamented'),
(3, 'UyRD8DfjnI3S', '2022-11-29 11:34:10', '[ { \"value\": \"-89.3\", \"pin\": \"8\" }, { \"value\": \"-273.1\", \"pin\": \"9\" } ]'),
(4, 'UyRD8DfjnI3S', '2022-11-29 11:34:30', '[ { \"value\": \"-74.6\", \"pin\": \"8\" }, { \"value\": \"-79.5\", \"pin\": \"9\" } ]'),
(5, 'UyRD8DfjnI3S', '2022-11-29 11:34:50', '[ { \"value\": \"-273.1\", \"pin\": \"8\" }, { \"value\": \"-273.1\", \"pin\": \"9\" } ]'),
(6, 'UyRD8DfjnI3S', '2022-11-29 11:35:10', '[ { \"value\": \"-273.1\", \"pin\": \"8\" }, { \"value\": \"-273.1\", \"pin\": \"9\" } ]'),
(7, 'UyRD8DfjnI3S', '2022-11-29 11:35:30', '[ { \"value\": \"-273.1\", \"pin\": \"8\" }, { \"value\": \"-273.1\", \"pin\": \"9\" } ]'),
(8, 'UyRD8DfjnI3S', '2022-11-29 11:35:50', '[ { \"value\": \"-273.1\", \"pin\": \"8\" }, { \"value\": \"-273.1\", \"pin\": \"9\" } ]'),
(9, 'UyRD8DfjnI3S', '2022-11-29 11:36:10', '[ { \"value\": \"-76.8\", \"pin\": \"8\" }, { \"value\": \"-273.1\", \"pin\": \"9\" } ]'),
(10, 'UyRD8DfjnI3S', '2022-11-29 11:36:30', '[ { \"value\": \"-74.6\", \"pin\": \"8\" }, { \"value\": \"-273.1\", \"pin\": \"9\" } ]'),
(11, 'UyRD8DfjnI3S', '2022-11-29 11:36:50', '[ { \"value\": \"-273.1\", \"pin\": \"8\" }, { \"value\": \"-273.1\", \"pin\": \"9\" } ]'),
(12, 'UyRD8DfjnI3S', '2022-11-29 11:37:10', '[ { \"value\": \"-79.5\", \"pin\": \"8\" }, { \"value\": \"-273.1\", \"pin\": \"9\" } ]'),
(13, 'UyRD8DfjnI3S', '2022-11-29 11:37:30', '[ { \"value\": \"-83.2\", \"pin\": \"8\" }, { \"value\": \"-273.1\", \"pin\": \"9\" } ]'),
(14, 'UyRD8DfjnI3S', '2022-11-29 11:37:50', '[ { \"value\": \"-273.1\", \"pin\": \"8\" }, { \"value\": \"-273.1\", \"pin\": \"9\" } ]'),
(15, 'UyRD8DfjnI3S', '2022-11-29 14:55:22', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(16, 'UyRD8DfjnI3S', '2022-11-29 15:10:51', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(17, 'UyRD8DfjnI3S', '2022-11-29 15:12:17', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(18, 'UyRD8DfjnI3S', '2022-11-29 15:12:22', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(19, 'UyRD8DfjnI3S', '2022-11-29 15:12:28', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(20, 'UyRD8DfjnI3S', '2022-11-29 15:12:39', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(21, 'UyRD8DfjnI3S', '2022-11-29 15:12:50', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(22, 'UyRD8DfjnI3S', '2022-11-29 15:13:29', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(23, 'UyRD8DfjnI3S', '2022-11-29 15:13:40', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(24, 'UyRD8DfjnI3S', '2022-11-29 15:13:51', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(25, 'UyRD8DfjnI3S', '2022-11-29 15:13:51', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(26, 'UyRD8DfjnI3S', '2022-11-29 15:14:02', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(27, 'UyRD8DfjnI3S', '2022-11-29 15:14:08', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(28, 'UyRD8DfjnI3S', '2022-11-29 15:14:19', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(29, 'UyRD8DfjnI3S', '2022-11-29 15:14:30', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(30, 'UyRD8DfjnI3S', '2022-11-29 15:14:41', '[ { \"sensor\": \"Inside\", \"value\": \"-69.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(31, 'UyRD8DfjnI3S', '2022-11-29 15:14:52', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(32, 'UyRD8DfjnI3S', '2022-11-29 15:14:58', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(33, 'UyRD8DfjnI3S', '2022-11-29 15:15:02', '[ { \"sensor\": \"Inside\", \"value\": \"-72.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(34, 'UyRD8DfjnI3S', '2022-11-29 15:19:05', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(35, 'UyRD8DfjnI3S', '2022-11-29 15:24:04', '[ { \"sensor\": \"Inside\", \"value\": \"-45.5\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(36, 'UyRD8DfjnI3S', '2022-11-29 15:24:22', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(37, 'UyRD8DfjnI3S', '2022-12-06 10:19:38', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(38, 'UyRD8DfjnI3S', '2022-12-06 12:45:55', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(39, 'UyRD8DfjnI3S', '2022-12-06 12:54:56', '[ { \"sensor\": \"Inside\", \"value\": \"-76.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(40, 'UyRD8DfjnI3S', '2022-12-06 13:04:57', '[ { \"sensor\": \"Inside\", \"value\": \"-76.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(41, 'UyRD8DfjnI3S', '2022-12-06 13:13:59', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(42, 'UyRD8DfjnI3S', '2022-12-06 13:24:59', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(43, 'UyRD8DfjnI3S', '2022-12-06 13:29:10', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(44, 'UyRD8DfjnI3S', '2022-12-06 13:39:11', '[ { \"sensor\": \"Inside\", \"value\": \"-83.2\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(45, 'UyRD8DfjnI3S', '2022-12-06 13:49:11', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(46, 'UyRD8DfjnI3S', '2022-12-06 13:59:11', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(47, 'UyRD8DfjnI3S', '2022-12-06 14:09:11', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-66.4\" } ]'),
(48, 'UyRD8DfjnI3S', '2022-12-06 14:19:11', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(49, 'UyRD8DfjnI3S', '2022-12-06 14:29:11', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(50, 'UyRD8DfjnI3S', '2022-12-06 14:39:11', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(51, 'UyRD8DfjnI3S', '2022-12-06 14:49:11', '[ { \"sensor\": \"Inside\", \"value\": \"-89.3\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(52, 'UyRD8DfjnI3S', '2022-12-06 14:59:12', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(53, 'UyRD8DfjnI3S', '2022-12-06 15:09:12', '[ { \"sensor\": \"Inside\", \"value\": \"-76.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(54, 'UyRD8DfjnI3S', '2022-12-06 15:19:12', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(55, 'UyRD8DfjnI3S', '2022-12-06 15:29:12', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(56, 'UyRD8DfjnI3S', '2022-12-06 15:39:12', '[ { \"sensor\": \"Inside\", \"value\": \"-72.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(57, 'UyRD8DfjnI3S', '2022-12-06 15:49:12', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(58, 'UyRD8DfjnI3S', '2022-12-06 15:59:13', '[ { \"sensor\": \"Inside\", \"value\": \"-67.5\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(59, 'UyRD8DfjnI3S', '2022-12-06 16:09:13', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(60, 'UyRD8DfjnI3S', '2022-12-06 16:19:12', '[ { \"sensor\": \"Inside\", \"value\": \"-67.5\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(61, 'UyRD8DfjnI3S', '2022-12-06 16:29:13', '[ { \"sensor\": \"Inside\", \"value\": \"-89.3\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(62, 'UyRD8DfjnI3S', '2022-12-06 16:39:12', '[ { \"sensor\": \"Inside\", \"value\": \"-76.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(63, 'UyRD8DfjnI3S', '2022-12-06 16:49:13', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(64, 'UyRD8DfjnI3S', '2022-12-06 16:59:13', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(65, 'UyRD8DfjnI3S', '2022-12-06 17:09:13', '[ { \"sensor\": \"Inside\", \"value\": \"-62.3\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(66, 'UyRD8DfjnI3S', '2022-12-06 17:19:13', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(67, 'UyRD8DfjnI3S', '2022-12-06 17:29:13', '[ { \"sensor\": \"Inside\", \"value\": \"-89.3\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(68, 'UyRD8DfjnI3S', '2022-12-06 17:39:13', '[ { \"sensor\": \"Inside\", \"value\": \"-76.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(69, 'UyRD8DfjnI3S', '2022-12-06 17:49:13', '[ { \"sensor\": \"Inside\", \"value\": \"-89.3\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(70, 'UyRD8DfjnI3S', '2022-12-06 17:59:13', '[ { \"sensor\": \"Inside\", \"value\": \"-89.3\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(71, 'UyRD8DfjnI3S', '2022-12-06 18:09:13', '[ { \"sensor\": \"Inside\", \"value\": \"-89.3\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(72, 'UyRD8DfjnI3S', '2022-12-06 18:19:14', '[ { \"sensor\": \"Inside\", \"value\": \"-63.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(73, 'UyRD8DfjnI3S', '2022-12-06 18:29:14', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(74, 'UyRD8DfjnI3S', '2022-12-06 18:39:14', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(75, 'UyRD8DfjnI3S', '2022-12-06 18:49:14', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(76, 'UyRD8DfjnI3S', '2022-12-06 18:59:14', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(77, 'UyRD8DfjnI3S', '2022-12-06 19:09:14', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(78, 'UyRD8DfjnI3S', '2022-12-06 19:19:14', '[ { \"sensor\": \"Inside\", \"value\": \"-69.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(79, 'UyRD8DfjnI3S', '2022-12-06 19:29:14', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(80, 'UyRD8DfjnI3S', '2022-12-06 19:39:15', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(81, 'UyRD8DfjnI3S', '2022-12-06 19:49:15', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(82, 'UyRD8DfjnI3S', '2022-12-06 19:59:15', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(83, 'UyRD8DfjnI3S', '2022-12-06 20:09:15', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(84, 'UyRD8DfjnI3S', '2022-12-06 20:19:15', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(85, 'UyRD8DfjnI3S', '2022-12-06 20:29:16', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(86, 'UyRD8DfjnI3S', '2022-12-06 20:39:15', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(87, 'UyRD8DfjnI3S', '2022-12-06 20:49:16', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-67.5\" } ]'),
(88, 'UyRD8DfjnI3S', '2022-12-06 20:59:16', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(89, 'UyRD8DfjnI3S', '2022-12-06 21:09:16', '[ { \"sensor\": \"Inside\", \"value\": \"-89.3\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(90, 'UyRD8DfjnI3S', '2022-12-06 21:19:16', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(91, 'UyRD8DfjnI3S', '2022-12-06 21:29:16', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(92, 'UyRD8DfjnI3S', '2022-12-06 21:39:16', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(93, 'UyRD8DfjnI3S', '2022-12-06 21:49:16', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-62.3\" } ]'),
(94, 'UyRD8DfjnI3S', '2022-12-06 21:59:16', '[ { \"sensor\": \"Inside\", \"value\": \"-76.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(95, 'UyRD8DfjnI3S', '2022-12-06 22:09:16', '[ { \"sensor\": \"Inside\", \"value\": \"-67.5\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(96, 'UyRD8DfjnI3S', '2022-12-06 22:19:16', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(97, 'UyRD8DfjnI3S', '2022-12-06 22:29:16', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(98, 'UyRD8DfjnI3S', '2022-12-06 22:39:16', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(99, 'UyRD8DfjnI3S', '2022-12-06 22:49:17', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(100, 'UyRD8DfjnI3S', '2022-12-06 22:59:17', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(101, 'UyRD8DfjnI3S', '2022-12-06 23:09:17', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(102, 'UyRD8DfjnI3S', '2022-12-06 23:19:17', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(103, 'UyRD8DfjnI3S', '2022-12-06 23:29:17', '[ { \"sensor\": \"Inside\", \"value\": \"-273.1\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(104, 'UyRD8DfjnI3S', '2022-12-06 23:39:17', '[ { \"sensor\": \"Inside\", \"value\": \"-72.8\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(105, 'UyRD8DfjnI3S', '2022-12-06 23:49:17', '[ { \"sensor\": \"Inside\", \"value\": \"-68.6\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]'),
(106, 'UyRD8DfjnI3S', '2022-12-06 23:59:17', '[ { \"sensor\": \"Inside\", \"value\": \"-83.2\" }, { \"sensor\": \"Outside\", \"value\": \"-273.1\" } ]');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `electricimp1`
--
ALTER TABLE `electricimp1`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `electricimp1`
--
ALTER TABLE `electricimp1`
  MODIFY `ID` int(114) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
