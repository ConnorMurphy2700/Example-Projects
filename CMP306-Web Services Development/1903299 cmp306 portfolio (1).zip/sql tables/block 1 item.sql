-- phpMyAdmin SQL Dump
-- version 5.2.0-1.el8.remi
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 13, 2022 at 11:29 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sql1903299`
--

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `image` varchar(36) NOT NULL,
  `description` varchar(512) NOT NULL,
  `price` float NOT NULL,
  `stock` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `name`, `image`, `description`, `price`, `stock`) VALUES
(1, 'Irwin Jack plus universal 500mm Fine Panel saw, 8 TPI', 'item1.jpg', 'With eight teeth per inch this steel c75 500mm c75 steel blade panel saw from Irwin is ideal for general purpose use gives a fine finish cut and is used with a push and pull cut direction. The triple ground teeth make short work of the material you need to cut down to size. It has a comfortable handle to give you absolute control and comfort whilst working. With a 45 and 90 angle guide built-in, you can easily cut a specific angle with complete accuracy.', 8.16, 64),
(2, 'Dekton Professional 40pc Socket Driver Set', 'item2.jpg', 'Includes 140mm spinner handle  170mm ratchet handle  3 extension bar adaptor 1 4 drive to drive 3 8) and 3 8 disc.\n', 12.99, 39),
(3, 'Stanley 21 Piece Multi-bit screwdriver Set', 'item3.jpg', 'Comes with Bit assortment Slotted 1x 4mm 1x 5mm 1x 6mm Phillips 1x PH1 1x PH 2 1x PH3 Torx 1x T6 1x T8 1x T10 1x T15 1x T20 Square 1x SQ1 1x SQ2 1x SQ3 Socket 1x 6mm 1x 7mm 1x 8mm 1x 9mm 1x 10mm 1x 11mm', 13.66, 70),
(5, 'Stanley 4mm Knife blade', 'item5.jpg', 'This is simple to use and safe to store. Made from durable carbide  the knife is comfortable to use.', 7.51, 80),
(6, 'Stanley 8\" Auto wire stripping pliers', 'item6.jpg', 'It allows easy grip and simple application and features with v groove edge\nCrimping capability and color-coded for crimps on common insulated and non-insulated terminals 1.5 to 6mm\nSelf-adjusting stripper strips electrical wire from 0.2mm to 6mm', 23, 12),
(15, 'Bosch 701W Corded Hammer drill UniversalImpact 700', 'item4.jpg', 'The Bosch UniversalImpact 700W corded hammer drill can be used for multiple jobs from screw driving, drilling, or hammer drilling.', 32, 35);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
