-- phpMyAdmin SQL Dump
-- version 5.2.0-1.el8.remi
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 13, 2022 at 11:29 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sql1903299`
--

-- --------------------------------------------------------

--
-- Table structure for table `electricimp2`
--

CREATE TABLE `electricimp2` (
  `ID` int(11) NOT NULL,
  `userid` varchar(30) NOT NULL,
  `deviceid` varchar(16) NOT NULL,
  `dttm` datetime NOT NULL DEFAULT current_timestamp(),
  `devicestate` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `electricimp2`
--

INSERT INTO `electricimp2` (`ID`, `userid`, `deviceid`, `dttm`, `devicestate`) VALUES
(1, 'Cmurphy', 'UyRD8DfjnI3S', '2022-12-07 00:02:21', '[ { \"Status\": \"On\", \"LED\": \"Red\" }, { \"Status\": \"Off\", \"LED\": \"Green\" } ]');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `electricimp2`
--
ALTER TABLE `electricimp2`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `electricimp2`
--
ALTER TABLE `electricimp2`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
