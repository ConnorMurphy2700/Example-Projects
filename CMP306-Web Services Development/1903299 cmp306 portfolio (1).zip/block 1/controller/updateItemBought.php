<?php
//  Item14.php - update a new Item using  JSON-RPC
error_reporting(E_ALL);
include("cleaner.php");
//  set up the data to be inserted
$Item = new stdClass();
$Item -> id = clean($_POST["id"]);


//  set up the request
$request = new stdClass();
$request -> jsonrpc = "2.0" ;
$request -> method = "updateItemBought" ;
$request -> params = $Item;
$request -> id = "510572" ;
$txt = json_encode($request) ;
echo $txt.'<br/><br/>' ;

//  set up for the curl
// $url = "localhost/mayar.abertay.ac.uk/cmp306/jsonrpc/index.php" ;
$url = "https://mayar.abertay.ac.uk/~1903299/cmp306/coursework/Block1/model/index.php";
$ch = curl_init($url) ;
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
$headers = array (
	'Content-Type: application/json', 
	'Content-Length: ' . strlen($txt) ) ;
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers) ;
curl_setopt($ch, CURLOPT_POSTFIELDS, $txt);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch) ;

header("Location: ../view/index.php");
?>