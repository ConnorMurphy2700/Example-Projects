<?php
	//Parameters
	$host = "lochnagar.abertay.ac.uk";
	$username = "sql1903299";
	$pass = "2Gfjtqa6Kp4h";
	$dbase = "sql1903299";
	
	$conn = new mysqli($host, $username, $pass, $dbase);
	
	if ($conn->connect_error) {
		die("Connection failure: try again" . $conn->connect_error);
	}
?>
