<?php
    header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header('Cache-Control: post-check=0, pre-check=0', FALSE);
	header('Pragma: no-cache');
	session_start();
?>
<!doctype html>
<html lang="en">
    <head>
    <style>
    p.a {
      visibility: hidden;
    }

    </style>

    <!-- Required meta tags -->
    	<meta charset="utf-8">
    	<meta name="viewport" content="width=device-width, initial-scale=1">

    	<!-- Bootstrap CSS -->
   	 	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
		<!-- local CSS -->
		<link rel="stylesheet" href="tools.css?v=2.0" />
		
    	<title>CMP306 - Web Services Development</title>
	</head> 
        
	<body>

	    <!-- overall container for page -->
	    <div class="container">
	    
	    	<!-- header row -->
    		<div id="header" class="card text-center">
    			<img src="../image/title01.jpg" />
    			<div class="card-img-overlay">
            		<h1 class="card-title">CMP306 Web Services Development - 2022-23</h1>
            		<h2 class="card-title">Connor Murphy -- 1903299</h2>
            		<h3>This site if part of a student assessment - All images are copyright B&Q (diy.co.uk)</h3>
                </div>
    		</div><!-- Header  row -->

		 <nav class="navbar navbar-expand-lg navbar-light bg-light">
		    <div class="container-fluid">
  		
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
    	
    	      <div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="Register.php">Register</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="Login.php">Log In</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="../controller/logout.php">Log out</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="Admin.php">Admin</a>
					</li>
                    <li class="nav-item">
						<a class="nav-link active" aria-current="page" href="payment_gateway_report.php">Payment Gateway Report</a>
					</li>
					<li class="nav-item">
					<?php
						
                        session_start();
						if (isset($_SESSION['uid'])) {
							echo '<p>'.$_SESSION['uid'].' is logged in</p>' ;
						}
						else {
							echo '<p>No one is logged in</p>' ;
						}
					?>
					</li>
				</ul>
               </div>
         </nav>
    		
    		<br/><!-- simple but effective way to get some space -->

            <div class="row">
            <p>Payment gateways are a technology that ecommerce sites use to collect and accept credit/debit card information and payments. Some gateways take the card information and sends it straight off their chosen bank for processing others handle payments directly on their own site. As previously stated generally the payment gateways the average person would see, and use are just for collecting their information on their chosen payment method. Most big tech companies have their own payment gateways such as amazon or apple. Many small businesses use these as third-party payment gateways paying a fee to use them. Some examples of payment gateways include Stripe, Amazon Pay, 2Checkout, Apple Pay, Square, Authorize.net and the one I will be looking at PayPal.</p>   
            <p>The PayPal payment gateway is highly developer friendly with very detailed implementation guides and a secure testing environment. PayPal’s payment gate way is called payflow and the implementation guide includes detailed explanations. Some of the explanations are on how to create a gateway and how to apply to PayPal to create said gateway. It also incudes a detailed breakdown of all the required information such as user and credit card info. There are also written examples of code in java of variable, functions as well as what some of the expected results would look and function like. It will always help the developer if they have a clear understanding of what any kind of web service requires as inputted variables and a safe testing area to work in.</p>
            <p>Speaking of which payflow offers a service of safe testing. PayPal owns secure servers that solely manages testing developers gateways for errors and security risks. The system is designed so that there is no need of any real credit of debit card information to be submitted. It is a completely money less system so the developer only needs to worry about the functionality of his code and not sending money in to the either. In fact, PayPal offer a wider range of fake cards designed to mimic card form a certain bank or group. This includes cards from American Express all the way to Visa debit and credit. By using these fake cards, a web developer can test if their website or web application accepts cards form different banks and if the collection of card information would be valid. Is summery PayPal’s various tools and guides allowing developers to take the guess work out of using their API and allow developers to experiment and test in a secure environment. Unlike some APIs that don’t dive the user any Guide at all.</p>
			</div><!-- row -->
            
        </div><!-- container -->
        
    <!-- Bootstrap Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	</body>
</html>
   