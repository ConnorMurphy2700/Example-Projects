<?php
    header('Expires: Sun, 01 Jan 2014 00:00:00 GMT');
	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header('Cache-Control: post-check=0, pre-check=0', FALSE);
	header('Pragma: no-cache');
?>
<!doctype html>
<html lang="en">
    <head>
    <!-- Required meta tags -->
    	<meta charset="utf-8">
    	<meta name="viewport" content="width=device-width, initial-scale=1">

    	<!-- Bootstrap CSS -->
   	 	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
		<!-- local CSS -->
		<link rel="stylesheet" href="tools.css?v=2.0" />
		
    	<title>CMP306 - Web Services Development</title>
	</head> 
        
	<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
		    <div class="container-fluid">
  		
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
    	
    	      <div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="Register.php">Register</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="Login.php">Log In</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="../controller/logout.php">Log out</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="Admin.php">Admin</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="payment_gateway_report.php">Payment Gateway Report</a>
					</li>
					<li class="nav-item">
					<?php
						session_start();
						if ($_SESSION['uid'] != 'Admin') {
							header('Location: index.php');
						}


						if (isset($_SESSION['uid'])) {
							echo '<p>Admin is logged in</p>' ;

						}
						else {
							echo '<p>No one is logged in</p>' ;
						}
					?>
					</li>

				</ul>
               </div>
         </nav>
        </div>



	    <!-- overall container for page -->
	    <div class="container">
   			<div class="row">
                <!-- Display items -->
                <?php
                	include("../model/api-item.php") ;
					$newArray = array();
					$itemtxt = getAllItems() ;
					$item = json_decode($itemtxt) ;
					for ($i=0 ; $i<sizeof($item) ; $i++) {
						$newArray[] = $item[$i] -> id;
						echo '<div class="col-lg-4 col-md-4 col-sm-4">' ;
						echo '<div class="card">' ;
						echo $item[$i] -> name ;
						echo '<div class="card-block">' ;
						echo '<p> product id'.$item[$i] -> id.'</p>' ; 
						echo '<p>Price &pound;'.$item[$i] -> price.'</p>' ; 
						echo '<p>Stock'.$item[$i] -> stock.'</p>' ;
						echo '</div>' ;
						echo '</div>' ;
						echo '</div>' ;
					}
				?>
			</div><!-- row -->	
    		<br/><!-- simple but effective way to get some space -->

            <div class="row">
                <!-- create a new product -->
             <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="card">
               <div class="card-header">
                <h1>Create new Item</h1>
               </div>
               <form action="../controller/CreateItem.php" method="post">
                Name: <input type="text" name="name"><br>
                Image: <input type="text" name="image"><br>
                Description: <input type="text" name="description"><br>
                Price: <input type="float" name="price"><br>
                Stock: <input type="int" name="stock"><br>
                <input type="submit">   
				</form>     
              </div>  
                </div>  
              <!-- delete a product -->
              <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="card">
               <div class="card-header">
                <h1>Delete product</h1>
               </div>
               <form action="../controller/DeleteItem.php" method="post">
                Product id: <input type="int" name="name"><br>
                <input type="submit"> 
				</form>       
              </div> 
			</div><!-- row -->

            <!-- update a product -->
            <div class="col-lg-4 col-md-4 col-sm-4">
              <div class="card">
               <div class="card-header">
                <h1>Update stock</h1>
               </div>
               <form action="../controller/UpdateItem.php" method="post">
                Product id:<input type="int" name="id"><br>
                The ammout of new stock: <input type="int" name="stock"><br>
				<input type="submit">
			   </form>        
              </div> 
			</div><!-- row -->
            <div>
			      <?php
				  
				    $itemtxt = getAllTransactions() ;
					$item = json_decode($itemtxt) ;
				    echo '<div class="col-lg-4 col-md-4 col-sm-4">' ;
					echo '<div class="card">' ;
					echo '<div class="card-header">' ;	
					echo '<h1>Transactions</h1>';
					echo '</div>' ;
					echo '<div class="card-block">' ;
					echo '<table>';	
					echo '<tr>';
					echo '<th>Order ID</th>';
                    echo '<th>Transaction ID</th>';
					echo '<th>Order Total</th>';
					echo '<th>Status Success = 1 Faliure = 0</th>';
                    echo '</tr>';
					//vardump($item);
					for ($i=0 ; $i<sizeof($item) ; $i++) {
                        echo '<tr>';
						echo '<td>'.$item[$i] -> Order_ID.'</td>';
						echo '<td>'.$item[$i] -> taction .'</td>' ; 
                        echo '<td>'.$item[$i] -> total .'</td>' ; 
						echo '<td>'.$item[$i] -> status .'</td>' ; 
                        echo '<tr>';
					}
					echo '</table>';	
					echo '</div>' ;
					echo '</div>' ;
					echo '</div>' ;
				?>
	
            </div>


        </div><!-- container -->
        
    <!-- Bootstrap Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	</body>
</html>