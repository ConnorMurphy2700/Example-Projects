<?php
session_start();
switch ($_GET["SignIn"]) {
    case 1:        
        $_SESSION["uid"] = 'Admin';
       header('Location:index.php');
        break;
    case 0:
       $_SESSION["uid"] = 'Greg';
        header('Location:index.php');
        break;

}
?>