<?php
session_start();
$a = $_GET["ItemID"];
echo 'item id '.$a.'';
switch ($_GET["BasketChoice"]) {
    case 1:        
        $_SESSION["basket"] = $_GET["ItemID"];
        //echo $_SESSION["basket"];
        $_SESSION["basket_cost"] = $_GET["ItemCost"];
        echo'item total '.$_SESSION["basket_cost"].'';
        $_SESSION["basket_item"] = $_GET["ItemName"];
        echo'item name '.$_SESSION["basket_item"].'' ;
        header('Location:product.php?ProdID='.$a.'');
        break;
    case 0:
        unset($_SESSION["basket"]);
        unset($_SESSION["basket_cost"]);
        unset($_SESSION["basket_item"]);
        header('Location:product.php?ProdID='.$a.'');
        break;

}




?>