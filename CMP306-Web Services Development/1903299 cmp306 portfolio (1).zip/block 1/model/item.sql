-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 02, 2020 at 09:44 AM
-- Server version: 5.7.26
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `sqlg510572`
--

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `image` varchar(36) NOT NULL,
  `description` varchar(512) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `name`, `image`, `description`, `price`) VALUES
(1, 'Irwin Jack plus universal 500mm Fine Panel saw', 'item1.jpg', 'With eight teeth per inch this steel c75 500mm c75 steel blade panel saw from Irwin is ideal for general purpose use gives a fine finish cut and is used with a push and pull cut direction. The triple ground teeth make short work of the material you need to cut down to size. It has a comfortable handle to give you absolute control and comfort whilst working. With a 45 and 90 angle guide built-in you can easily cut a specific angle with complete accuracy.', 8.16),
(2, 'Dekton Professional 40pc Socket Driver Set', 'item2.jpg', 'Includes 140mm spinner handle 170mm ratchet handle 3 extension bar adaptor 1 4" drive to 3 8" drive  and 3 8" disc.', 12.99),
(3, 'Stanley 21 Piece Multi-bit screwdriver Set', 'item3.jpg', 'Comes with Bit assortment  Slotted 1x 4mm  1x 5mm  1x 6mm Phillips  1x PH1 1x PH 2 1x PH3 Torx 1x T6 1x T8 1x T10 1x T15 1x T20 Square 1x SQ1 1x SQ2 1x SQ3 Socket 1x 6mm 1x 7mm 1x 8mm 1x 9mm 1x 10mm 1x 11mm', 13.66),
(4, 'electric screwdriver', 'item4.jpg', '26 piece premium performance 4.8V cordless electric screwdriver and drill tools bit set  complete with forward and reverse functions plus charger cable.', 16.75),
(5, 'Stanley 4mm Knife blade', 'item5.jpg', 'This is simple to use and safe to store. Made from durable carbide the knife is comfortable to use.', 7.51),
(6, 'Stanley 8" Auto wire stripping pliers', 'item6.jpg', 'It allows easy grip and simple application and features with v groove edge Crimping capability and color-coded for crimps on common insulated and non-insulated terminals 1.5 to 6mm Self adjusting stripper strips electrical wire from 0.2mm to 6mm', 23);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`);