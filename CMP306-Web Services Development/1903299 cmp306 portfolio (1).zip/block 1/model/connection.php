<?php
function getDatabaseConnection() {
		//  Database connections 
		$servername = "lochnagar.abertay.ac.uk";
		$username = "sql1903299";
		$password = "2Gfjtqa6Kp4h";
		$database = "sql1903299";
		$conn = mysqli_connect($servername,$username,$password,$database);
		// Check connection
		if (mysqli_connect_errno()) {
  			echo "Failed to connect to MySQL: " . mysqli_connect_error();
  		exit();
		}
		return $conn ;
		}
?>