<?php

	include("connection.php");
	$conn =  getDatabaseConnection();
		

	//  function to create an item
	function createItem($txt) {
		global $conn ;
		$item = json_decode($txt) ;
		$stmt = $conn->prepare("insert into item (name, image, description, price, stock) values (?, ?, ?, ?, ?)");
		$stmt->bind_param("sssss", $name, $image, $description, $price, $stock);
		$name = $item -> name ;  
		$image = $item -> image ;
		$description = $item -> description ; 
		$price = $item -> price ;
		$stock = $item -> stock ;
		$result = $stmt->execute();
		if (!$result) {$result = 0 ;}
		return $result ;
	}

	function createTransaction($txt) {
		global $conn ;
		$stmt = $conn->prepare("insert into Order_History (taction, total, status) values (?, ?, ?)");
		$stmt->bind_param("ssi", $taction, $total, $status);
		$taction = $txt -> taction ;  
		$total = $txt -> total ;
		$status = $txt -> status ; 
		$result = $stmt->execute();
		if (!$result) {$result = 0 ;}
		return $result ;
	}

	//  function to get all the items
	function getAllItems()
	{
		global $conn ;
		$sql = "SELECT * FROM item LIMIT 6";
		$result = mysqli_query($conn, $sql);
		//  convert to JSON
		$rows = array();
		while($r = mysqli_fetch_assoc($result)) {
    		$rows[] = $r;
		}
		return json_encode($rows);
	}
	
	//  function to get a single item
	function getItemById($id)
	{
		global $conn ;
		$stmt = mysqli_stmt_init($conn);
		$sql = "SELECT * FROM item WHERE id= ? LIMIT 1" ;
		mysqli_stmt_prepare($stmt, $sql);
		mysqli_stmt_bind_param($stmt, 's', $id);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		$row = mysqli_fetch_assoc($result) ;  //there is only 1 row
		return json_encode($row);
	}

	function getAllTransactions()// get transaction data 
	{
		global $conn ;
		$sql = "SELECT * FROM Order_History";
		$result = mysqli_query($conn, $sql);
		//  convert to JSON
		$rows = array();
		while($r = mysqli_fetch_assoc($result)) {
    		$rows[] = $r;
		}
		return json_encode($rows);
	}
	
	//  function to update an item
	function UpdateItem($txt) {
		// $txt must contain the data for all fields.
		global $conn ;
		$item = json_decode($txt) ;
		$stmt = $conn->prepare("update item SET stock = stock + ? where id=? ");
		$stmt->bind_param("ss", $stock, $id);
		$id = $item -> id ;
		$stock = $item -> stock ;
		$result = $stmt->execute();
		if (!$result) {$result = 0 ;}
		return $result ;
	}
		//  function to update an item
		function updateItemBought($txt) {
			// $txt must contain the data for all fields.
			global $conn ;
			$stmt = $conn->prepare("update item SET stock= stock - 1 where id=? ");
			$stmt->bind_param("s", $id);
			$id = $txt;
			$result = $stmt->execute();
			if (!$result) {$result = 0 ;}
			return $result ;
		}
	
	//  function to delete a single item
	function deleteItemById($id)
	{
		global $conn ;
		$sql = "DELETE from item where id = ?" ;
		$stmt = mysqli_stmt_init($conn);
		mysqli_stmt_prepare($stmt, $sql);
		mysqli_stmt_bind_param($stmt, 's', $id);
		$result = mysqli_stmt_execute($stmt);
		if (!$result) {$result = 0 ;}
		return $result ;
	}

	function createUser($txt) {
		global $conn ;
		$item = json_decode($txt);
		$fname = $item -> forename;
		$sname = $item -> surname;
		$email = $item -> email;
		$mphone = $item -> mphone;
		$pwd = $item -> pwd;
		$pwdhsh = password_hash($pwd, PASSWORD_DEFAULT);
		$admin = 0;


		$stmt = mysqli_stmt_init($conn);
		$sql = "INSERT INTO user (firstname, surname, email, mphone, password, admin) VALUES (?, ?, ?, ?, ?, ?)";
		mysqli_stmt_prepare($stmt, $sql);
		mysqli_stmt_bind_param($stmt, 'sssssi', $fname, $sname, $email, $mphone, $pwdhsh,$admin);
		$result = mysqli_stmt_execute($stmt);
		return $result ;
	}

	function getUserById($id)
	{
		global $conn ;
		$stmt = mysqli_stmt_init($conn);
		$sql = "SELECT * FROM user WHERE id= ? LIMIT 1" ;
		mysqli_stmt_prepare($stmt, $sql);
		mysqli_stmt_bind_param($stmt, 's', $id);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		$row = mysqli_fetch_assoc($result) ;  //there is only 1 row
		return json_encode($row);
	}
	
?>

