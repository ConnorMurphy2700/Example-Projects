<!DOCTYPE html> 
<html>
    <head>  
        <meta charset="utf-8">
	    <title>CMP306 Web Services Development - 2022-23</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	
	   	<!-- The site uses Bootstrap v5 -->
		   <link rel="stylesheet" href="index.css" />
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous"></link>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
		
    </head>

    <body>
  	    <!-- overall container for page -->
        <div class="container">

        <!-- header row -->
        <div id="header" class="card text-center">
            <img src="../image/title01.jpg" />
            <div class="card-img-overlay">
                <h1 class="card-title">CMP306Web Services Development - 2022-23</h1>
                <h2 class="card-title">Connor Murphy 1903299</h2>
            </div>
        </div><!-- Header  row -->
		
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
		    <div class="container-fluid">
  		
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
    	
    	      <div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="Data_as_a_service.php">Data as a Service</a>
					</li>
				</ul>
            </div>
        </nav>

        <h1> Weather</h1>

        <br/><!--simple way to get some space -->     

		<?php 
  	    	//  connect to the live URL
             $api = "7452be188b05e544e3bd9fd41d410cb9" ;
  		      $url = "https://api.openweathermap.org/data/2.5/weather?q=Inverness&appid=".$api."&mode=xml" ;
  		    //  Or for testing use the local data
  		    //$url = "../model/london-weather.xml" ;
  		    
  		    //$xmltxt = file_get_contents($url) ; 
		   // $xml = simplexml_load_string($xmltxt)  ;
		    
		    //  use the function to cache the data
			 include("../model/getweatherxml.php") ;
			 $xml = getweatherXML() ;
			
		    //var_dump($xml);
            echo '<div class="row">' ;
		
		    echo '<div class="col-sm-4">' ;
		    echo '<div class="card">' ;
		    echo '<div class="card-header">'.$xml ->  city["name"].'</div>' ;
		    echo '<div class="card-body">' ;
		    echo 'Update :'.$xml -> lastupdate["value"]."<br/>" ;
		    echo 'Sunrise :'.$xml -> city -> sun["rise"]."<br/>" ;
		    echo 'Sunset :'.$xml -> city -> sun["set"]."<br/>" ;
		    echo '<br/>' ;
		    echo 'Current Weather: <br/>' ;
		    $temperature = $xml -> temperature["value"] - 273 ;
		    echo 'temperature : '.$temperature.' '.$xml ->temperature["unit"]."<br/>" ;
			
		    $wind = $xml -> wind ;
		    $speed = round($wind -> speed["value"] * 3.6) ;
            echo 'wind : '.$wind -> speed["name"].' '.$speed.'kph '.$wind -> direction["code"].'<br/>' ;
			echo 'the sky looks like : '.$xml -> weather["value"].'<br/>' ;
			if ($xml -> precipitation["mode"] = "no") {
                echo 'there is no rain in Inverness';
            } else {
                 echo 'precipitation : '.$xml -> precipitation["value"].' cm of '.$xml -> precipitation["mode"].' at a rate of '.$xml -> precipitation["unit"].'<br/>' ;

            }
		   	echo '</div>' ;
		    echo '<div class="card-footer">Data &#169;openweathermap.org</div>' ;
		    echo '</div>' ;
		    echo '</div>' ;

            echo '</div>' ;
	    ?>
         <h1>local News</h1>
          <?php
           include("location.php") ;
		   $url2 = $location ;
		   //  set up the CURL
		   $curl = curl_init($url2) ;
			 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");                                                                                                                                     
		     curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);                                                                                                                                                                                                                           
			 $resp = curl_exec($curl) ;
	         var_dump($resp);// works 
			 //  Output the results
			 if (!$resp) {die('Error : "'.curl_error($curl).'" - Code: '.curl_errno($curl)); }
	
			 
			 $news = simplexml_load_string($resp) ;
			 var_dump($news); // output bool fasle

			 $story = $news -> story;
             var_dump($story); // output NULL

             $n=6;
			 for ($i=0; $i<$n; $i++) {
				 echo $resp[$i]->title." " ;
				 echo $news[$i]->date." " ;
				 echo $news[$i]->main." " ;
				 echo $news[$i]->author ;
				 echo "<br/>" ;
			 }
			 curl_close($curl) ;
            echo '<img src="../image/RSS.png">';
			echo '<a href="rss.php">link to local news database </a>';
          ?>
         <h1>Local Sports News</h1>

		 <?php 
			//https://feeds.bbci.co.uk/sport/34032412-5e2a-324d-bb3e-d0d4b16df2d4/rss.xml
				$url = "http://newsrss.bbc.co.uk/rss/sportonline_uk_edition/football/teams/i/inverness_ct/rss.xml" ;
				$xml = new DOMDocument() ;
				$xml->load($url) ;
				// var_dump($xml) ;
				$xsl = new DOMDocument() ;
				$xsl->load("../model/rss.xsl") ;
				//var_dump($xsl) ;
				$proc = new XSLTProcessor() ;
				$proc -> importStyleSheet($xsl) ;
				$result = $proc -> transformtoXML($xml) ;
				// echo $result ;
				// echo "<br/><br/>" ;
				
				echo '<div class="row">' ;

				echo $result ;
				echo '<div class="row">' ;
	     ?>

         <h1>Bus TimeTable</h1>
         <div id="app"></div>
         <script src="main.js" type="module"></script>





	    </div>

    </body>
</html>