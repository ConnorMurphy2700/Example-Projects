
    <?php
        
        include("location.php") ;
        //$url2 = $location ;
        //  set up the CURL
        $curl = curl_init("https://mayar.abertay.ac.uk/~1903299/cmp306/coursework/Block2/model/employees") ;
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");                                                                                                                                     
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);                                                                                                                                                                                                                           
        $resp = curl_exec($curl) ;
        header('Content-Type: text/xml');
        print ($resp);// works 
        //  Output the results
        if (!$resp) {die('Error : "'.curl_error($curl).'" - Code: '.curl_errno($curl)); }
    ?>
