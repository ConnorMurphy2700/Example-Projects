<?php
//  File for the URL
 $location = "https://mayar.abertay.ac.uk/~1903299/cmp306/coursework/Block2/model/employees" ; 
//$location = "localhost/mayar.abertay.ac.uk/cmp306/ws/employees" ;
?>