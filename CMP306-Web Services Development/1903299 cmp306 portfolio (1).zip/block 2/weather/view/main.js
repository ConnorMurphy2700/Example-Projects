import $ from 'jquery';

// To make live requests get your app_id and app_key by signing up at https://developer.transportapi.com/signup
// and filling them here
const appId = '7addeffb';
const appKey = 'a430f48b58301292b75a1eec09b59ded';

const url = (appId === '7addeffb' || appKey === 'a430f48b58301292b75a1eec09b59ded')? 'response.json'
  : 'https://transportapi.com/v3/uk/bus/stop/670085865A/timetable.json?app_id=7addeffb&app_key=a430f48b58301292b75a1eec09b59ded';

$.getJSON(url, data => {
  const departures = data.departures;
  const rows = Object.keys(departures)
    .filter(line => departures[line].length > 0)
    .map(line => {
      const service = departures[line][0];
      return `
        <tr>
          <td>${service.aimed_departure_time}</td>
          <td>${service.line_name}</td>
          <td>${service.direction}</td>
        </tr>
      `;
    })
    .join('\n');
  const html = `
    <table>
      <tr>
        <th>Time</th>
        <th>Line</th>
        <th>Destination</th>
      </tr>
      ${rows}
    </table>
  `;
  $('#app').html(html);
});