<!DOCTYPE html> 
<html>
    <head>  
        <meta charset="utf-8">
	    <title>CMP306 Web Services Development - 2022-23</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	
	   	<!-- The site uses Bootstrap v5 -->
		   <link rel="stylesheet" href="index.css" />
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
		
    </head>

    <body>
  	    <!-- overall container for page -->
        <div class="container">

        <!-- header row -->
        <div id="header" class="card text-center">
            <img src="../image/title01.jpg" />
            <div class="card-img-overlay">
                <h1 class="card-title">CMP306Web Services Development - 2022-23</h1>
                <h2 class="card-title">Connor Murphy 1903299</h2>
            </div>
        </div><!-- Header  row -->

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
		    <div class="container-fluid">
  		
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
    	
    	      <div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="Data_as_a_service.php">Data as a Service</a>
					</li>
				</ul>
            </div>
        </nav>

        <p>In our modern world data is no longer just information it is a commodity, a highly valuable one at that. Data as a commodity is a highly multi-faceted topic. Here, I will discuss it in terms of API sending data over the web. This form of data sharing is called <b>Data as a service</b> and there are a handful of ways a supplier can charge for the service they provide.</p>
        <ul>
           <li>Pay as you go: Similar to pay as you go for mobile phones the method involves paying a small fee every time the API is called. I.E., 20p for every call.</li>
           <li>Fixed Pricing: the same as any other kind of fixed pricing. To use the service for a specified amount of time or for a specified amount of API calls the developer pay so much. I.E., £20 per month.</li>
           <li>Combination Pricing: A hybrid of the previously mentioned two methods. So, starting with a fixed rate for an amount of API calls per month. Say 2000. If the developers web service ever makes over 2000 API calls the provider starts charging for every call say 50p. I.E., £15 for 2000 calls a month and then 50p for every call thereafter.</li>
           <li>Partner Pricing: Where the API provider and the Web developer work closely together to provide data to an end customer. Both parties share a portion of any profit generated form the website. Such as a tabloid site or a booking website. I.E., producer 40% web developer 60%</li>
        </ul>
        <p>All these payment options work with the same checking technique. The API Producer will be responsible for writing some code that checks the API call is first from a valid developer (using their unique API key that the provider has given them) and then checks as needed for the type of payment plan the provider decides on. For the pay as you go, I would personally count how many call the API gets from a specific developer and once the threshold is reached charge the account of the user. I would not charge the developer for every single call as that would look like fraud to the bank. For a fixed price system (my choice), I would put a check in that would see if a specific developer had paid their payment and block that developer until the payment has been made. Finally for the combination pricing I would a gain use the check I used for the fixed pricing as well as the call counter form the pay as you go system and charge the developer any extra payment at the end of each month.</p>
        <p>For this particular web service, I would use the fixed pricing method for an independent news story database.</p>

    </body>
</html>