<!DOCTYPE html> 
<html>
    <head>  
        <meta charset="utf-8">
	    <title>CMP306 Web Services Development - 2022-23</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	
	   	<!-- The site uses Bootstrap v5 -->
		   <link rel="stylesheet" href="index.css" />
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
		
    </head>

    <body>
      

<?php
	// Connect to database
	include("connection.php");
	$conn =  getDatabaseConnection();
	
	// library contains all the methods required from the Web Service
	include("library.php") ;
 
	$request_method=$_SERVER["REQUEST_METHOD"];
	// $call = $_SERVER["PHP_SELF"];
	// $request = $_SERVER['REQUEST_URI'];
	
	switch($request_method)
	{
		case 'GET':
			// Retrive Employees
			if(isset($_GET['id']))
			{
				$id=$_GET["id"];
				$resp = getEmployee($id);
				header('Content-Type: text/xml');
				echo $resp ;
			}
			else
			{
				$resp = getAllEmployees();
				header('Content-Type: text/xml');
				echo $resp ;
			}
			break;
			case 'POST':
				// Insert Employee
				$xml = file_get_contents('php://input') ;
				$resp = insertEmployee($xml);
				echo $resp ;
				break;
			case 'PUT':
				// Update Employee
				$id=$_GET["id"];
				$xml = file_get_contents('php://input') ;
				$resp = updateEmployee($id, $xml);
				echo $resp ;
				break;	
			case 'DELETE':
				// Delete Employee
				$id=$_GET["id"];
				$resp = deleteEmployee($id);
				echo $resp ;
				break;
		
		
		default:
			// Invalid Request Method
			header("HTTP/1.0 405 Method Not Allowed");
			break;
	}

?>

</body>
</html>