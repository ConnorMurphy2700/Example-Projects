<!DOCTYPE html> 
<html>
    <head>  
        <meta charset="utf-8">
	    <title>CMP306 Web Services Development - 2022-23</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
	
	   	<!-- The site uses Bootstrap v5 -->
		   <link rel="stylesheet" href="index.css" />
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
		
    </head>

    <body>
  	   
<?php

	// Library of methods to support the Web Service	
	
	//  function to convert a single record from database to XML
	function convertToXML($query) {
		$txt ='<story>' ;
		$txt = $txt.'<ID>'.$query["ID"].'</ID>' ;
		$txt = $txt.'<headline>'.$query["headline"].'</headline>' ;
		$txt = $txt.'<date>'.$query["date"].'</date>' ;
		$txt = $txt.'<main>'.$query["main"].'</main>' ;
		$txt = $txt.'<author>'.$query["author"].'</author>' ;
		$txt = $txt.'</story>' ;
		return $txt ;
	}	

	// function to get all (max 12) employees
	function getAllEmployees()
	{
		echo "running get all";
		global $conn;
		$query="select * from news limit 6";
		$result=mysqli_query($conn, $query);
		$txt = '<storyies>';
		while($row=mysqli_fetch_array($result))
		{
			$txt = $txt.convertToXML($row) ;
			//echo $txt;
			//echo $row;
		}
		$txt = $txt.'</storyies>' ;
		echo 'IN get function ';

        echo $txt;
		return $txt ;
	}

	function insertEmployee($xml)
	{
		global $conn;
		$data = simplexml_load_string($xml);
		$headline=$data -> headline;
		$date=$data -> date;
		$main=$data -> main;
		$author=$data -> author;
		$query="INSERT INTO news SET headline='".$headline."', date='".$date."', main='".$main."', author='".$author."'";
		$response = mysqli_query($conn, $query) ;
		$last_id = mysqli_insert_id($conn) ;
		if($response)
		{
			$resp = $last_id ;
		}
		else
		{
			$resp = 0 ;
		}
		return $resp ;
	}

	function updateEmployee($id, $xml)
	{
		global $conn;
		$data = simplexml_load_string($xml);
		$headline=$data -> headline;
		$date=$data -> date;
		$main=$data -> main;
		$author=$data -> author;
		$query="UPDATE news SET headline='".$headline."', date='".$date."', main='".$main."', author='".$author."'WHERE id=".$id;
		$response = mysqli_query($conn, $query) ;
		if($response)
		{
			$resp = 1 ;
		}
		else
		{
			$resp = 0 ;
		}
		return $resp ;
	}

	function deleteEmployee($id)
	{
		global $conn;
		$query="DELETE FROM news WHERE id=".$id;
		$response = mysqli_query($conn, $query) ;
		if($response)
		{
			$resp = 1 ;
		}
		else
		{
			$resp = 0 ;
		}
		return $resp ;
	}
	
	
?>

</body>
</html>