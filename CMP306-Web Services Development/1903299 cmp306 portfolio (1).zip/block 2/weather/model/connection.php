<?php
	function getDatabaseConnection() {
		//  Database connections 
		$servername = "lochnagar.abertay.ac.uk";
		$username = "sql1903299";
		$password = "2Gfjtqa6Kp4h";
		$dbname = "sql1903299";
		$conn = mysqli_connect($servername, $username, $password, $dbname) ;
		return $conn ;
		}
?>