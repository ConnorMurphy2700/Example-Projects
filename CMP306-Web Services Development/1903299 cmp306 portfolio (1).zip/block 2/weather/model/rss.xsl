<?xml version="1.0" encoding="utf-8"?> 
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" >
<xsl:output method="xml" version="1.0" omit-xml-declaration="yes" indent="yes" media-type="text/html"/>
    
<xsl:template match="/">
	<xsl:apply-templates select="//item[position() &lt;= 6]" />
</xsl:template>

<xsl:template match="item">
      
	    <xsl:element name="div"> <xsl:attribute name="class"><xsl:text>col-lg-4 col-md-4 col-sm-4</xsl:text></xsl:attribute>  
	    <xsl:element name="div"> <xsl:attribute name="class"><xsl:text>card</xsl:text></xsl:attribute>
		<xsl:element name="div"> <xsl:attribute name="class"><xsl:text>card-header</xsl:text></xsl:attribute>
		<xsl:element name="h1"><xsl:value-of select="title" /></xsl:element>
		</xsl:element>
		<xsl:element name="p">
			<xsl:value-of select="description" />
			<xsl:element name="br" />
			<xsl:element name="a">
				<xsl:attribute name="href"><xsl:value-of select="link" /></xsl:attribute>
				<xsl:attribute name="target"><xsl:text>_blank</xsl:text></xsl:attribute>
				<xsl:text>Click Here for More Info</xsl:text>
			</xsl:element>
			<xsl:element name="br" />
			<span class="bold"><xsl:value-of select="pubDate" /></span>	
			<span class="bold"><xsl:value-of select="author" /></span>	
			<xsl:element name="br" />
			<xsl:element name="div"> <xsl:attribute name="class"><xsl:text>card-footer</xsl:text></xsl:attribute>
			<xsl:text>Data bbc.co.uk/news.org</xsl:text>
			</xsl:element>
		</xsl:element>
		</xsl:element>
		</xsl:element>
</xsl:template>

</xsl:stylesheet>
