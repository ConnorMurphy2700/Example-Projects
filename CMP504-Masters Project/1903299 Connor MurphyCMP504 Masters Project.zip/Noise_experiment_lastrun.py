﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2024.1.5),
    on August 06, 2025, at 13:17
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2024.1.5'
expName = 'Noise_experiment'  # from the Builder filename that created this script
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1280, 720]
_loggingLevel = logging.getLevel('warning')
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # override logging level
    _loggingLevel = logging.getLevel(
        prefs.piloting['pilotLoggingLevel']
    )

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='C:\\Users\\ninja\\Documents\\Masters project\\eperiment\\Noise_experiment_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # this outputs to the screen, not a file
    logging.console.setLevel(_loggingLevel)
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log', level=_loggingLevel)
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowStencil=True,
            monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height', 
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0,0,0]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.mouseVisible = True
    win.hideMessage()
    # show a visual indicator if we're in piloting mode
    if PILOTING and prefs.piloting['showPilotingIndicator']:
        win.showPilotingIndicator()
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    
    # Setup iohub keyboard
    ioConfig['Keyboard'] = dict(use_keymap='psychopy')
    
    ioSession = '1'
    if 'session' in expInfo:
        ioSession = str(expInfo['session'])
    ioServer = io.launchHubServer(window=win, **ioConfig)
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='iohub'
        )
    # create speaker 'white'
    deviceManager.addDevice(
        deviceName='white',
        deviceClass='psychopy.hardware.speaker.SpeakerDevice',
        index=-1
    )
    # create speaker 'pink'
    deviceManager.addDevice(
        deviceName='pink',
        deviceClass='psychopy.hardware.speaker.SpeakerDevice',
        index=-1
    )
    # create speaker 'pink_2'
    deviceManager.addDevice(
        deviceName='pink_2',
        deviceClass='psychopy.hardware.speaker.SpeakerDevice',
        index=-1
    )
    # create speaker 'white_2'
    deviceManager.addDevice(
        deviceName='white_2',
        deviceClass='psychopy.hardware.speaker.SpeakerDevice',
        index=-1
    )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # pause any playback components
    for comp in playbackComponents:
        comp.pause()
    # prevent components from auto-drawing
    win.stashAutoDraw()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='ioHub',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # flip the screen
        win.flip()
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    for comp in playbackComponents:
        comp.play()
    # restore auto-drawn components
    win.retrieveAutoDraw()
    # reset any timers
    for timer in timers:
        timer.reset()


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ioHub'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    expShelf = data.shelf.Shelf(scope='experiment', expPath=_thisDir)
    # create uniform conditions for counterbalance
    counterbalanceConditions = []
    for n in range(2):
        counterbalanceConditions.append({
            'group': n,
            'probability': 1/2,
            'cap': 10
        })
    
    # create counterbalance object for counterbalance 
    counterbalance = data.Counterbalancer(
        shelf=expShelf,
        entry='counterbalance',
        conditions=counterbalanceConditions,
        nReps=2
    )
    
    # --- Initialize components for Routine "explanation" ---
    Continue_button = visual.ButtonStim(win, 
        text='Click here to continue if you accept the above terms ', font='Arial',
        pos=(0.35, -0.40),
        letterHeight=0.025,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Continue_button',
        depth=-1
    )
    Continue_button.buttonClock = core.Clock()
    Exit_button = visual.ButtonStim(win, 
        text='Click here to Exit', font='Arial',
        pos=(-0.30, -0.40),
        letterHeight=0.025,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Exit_button',
        depth=-2
    )
    Exit_button.buttonClock = core.Clock()
    text = visual.TextStim(win=win, name='text',
        text='',
        font='Arial',
        pos=(-0.30, 0.05), height=0.017, wrapWidth=0.6, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    textPart2 = visual.TextStim(win=win, name='textPart2',
        text='',
        font='Arial',
        pos=(0.30, 0.05), height=0.017, wrapWidth=0.6, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    
    # --- Initialize components for Routine "Instruction" ---
    Instruction_text = visual.TextStim(win=win, name='Instruction_text',
        text='Before starting, we ask that this experiment be completed on a PC or laptop. As this experiment was specifically designed with the mechanics of a physical keyboard in mind. So if you are on a phone or tablet, please exit and reopen the link on a machine with a physical keyboard.  \n\nYour task is to watch a cooking video and then write down what you recall. This task will be repeated twice, first with a simple recipe and then a longer, more complex recipe.  \n\n\nFor each recipe, you will first watch the video, which consists of a non-narrated tutorial. There will be written instructions as well as physical demonstrations. We ask that you focus on the video and try to remember as many details as possible. The video will only be shown once, and the next part of the task will start automatically.\n\nThe second part of each task consists of writing up all of the details of the recipe you can remember. However, there are a few stipulations. First, please refrain from using the mouse or touchpad to navigate. Please use the arrow keys, as this experiment depends on keyboard interaction. Secondly, when making revisions, please use only the backspace key and not the delete key.\n\nOnce you have completed the first task with the simpler recipe, you will complete the same task with the more complex recipe.\n\nThings to keep note of when filling out the survey section hold down your presses on the options and the submit buttons. Also, the text boxes are in beta for this program, as such, when you fill up the text box, a scroll option will appear, but the text outside of the box will not disappear. This is fine, your full text will be recorded. So just scroll till you can see what you are actively working on. ',
        font='Arial',
        pos=(0, 0.1), height=0.02, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    continue_2 = visual.ButtonStim(win, 
        text='continue', font='Arial',
        pos=(0, -0.4),
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='continue_2',
        depth=-2
    )
    continue_2.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "Video_1" ---
    Simple_movie = visual.MovieStim(
        win, name='Simple_movie',
        filename='C:/Users/ninja/Documents/Masters project/eperiment/Pancakes.mp4', movieLib='ffpyplayer',
        loop=False, volume=0.5, noAudio=False,
        pos=(0, 0), size=(0.8, 0.6), units=win.units,
        ori=0.0, anchor='center',opacity=None, contrast=1.0,
        depth=0
    )
    
    # --- Initialize components for Routine "simple_task" ---
    Simple_textbox = visual.TextBox2(
         win, text='Ingredients\n\nmethod', placeholder='Please write out the recipe here in as much detail as posible. in the format Ingredients: and Method:', font='Arial',
         pos=(0, -0.05),     letterHeight=0.02,
         size=(0.9, 0.65), borderWidth=2.0,
         color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb',
         opacity=None,
         bold=False, italic=False,
         lineSpacing=1.0, speechPoint=None,
         padding=0.0, alignment='top-left',
         anchor='center', overflow='scroll',
         fillColor=[1.0000, 1.0000, 1.0000], borderColor=None,
         flipHoriz=False, flipVert=False, languageStyle='LTR',
         editable=True,
         name='Simple_textbox',
         depth=-1, autoLog=False,
    )
    Countdown = visual.TextStim(win=win, name='Countdown',
        text='Please write all of the details of the recipie you can remember.\nWhen you are sure you have finished the task click continue  ',
        font='Arial',
        pos=(0.3, 0.35), height=0.025, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    white = sound.Sound(
        'A', 
        secs=-1, 
        stereo=True, 
        hamming=True, 
        speaker='white',    name='white'
    )
    white.setVolume(0.45)
    pink = sound.Sound(
        'A', 
        secs=-1, 
        stereo=True, 
        hamming=True, 
        speaker='pink',    name='pink'
    )
    pink.setVolume(0.0)
    SimpleContinue = visual.ButtonStim(win, 
        text='Continue', font='Arial',
        pos=(-0.35, 0.35),
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='SimpleContinue',
        depth=-5
    )
    SimpleContinue.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "Video_2" ---
    Complex_Movie = visual.MovieStim(
        win, name='Complex_Movie',
        filename='C:/Users/ninja/Documents/Masters project/eperiment/Khachapuri.mp4', movieLib='ffpyplayer',
        loop=False, volume=1.0, noAudio=False,
        pos=(0, 0), size=(0.8, 0.6), units=win.units,
        ori=0.0, anchor='center',opacity=None, contrast=1.0,
        depth=0
    )
    
    # --- Initialize components for Routine "Complex_task" ---
    Countdown_2 = visual.TextStim(win=win, name='Countdown_2',
        text='Please write all of the details of the recipie you can remember.\nWhen you are sure you have finished the task click continue  ',
        font='Arial',
        pos=(0.3, 0.35), height=0.025, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    Complex_textbox = visual.TextBox2(
         win, text='Ingredients\n\nmethod', placeholder=None, font='Arial',
         pos=(0, -0.05),     letterHeight=0.02,
         size=(0.9, 0.65), borderWidth=2.0,
         color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb',
         opacity=None,
         bold=False, italic=False,
         lineSpacing=1.0, speechPoint=None,
         padding=0.0, alignment='top-left',
         anchor='center', overflow='scroll',
         fillColor=[1.0000, 1.0000, 1.0000], borderColor=None,
         flipHoriz=False, flipVert=False, languageStyle='LTR',
         editable=True,
         name='Complex_textbox',
         depth=-2, autoLog=False,
    )
    pink_2 = sound.Sound(
        'A', 
        secs=-1, 
        stereo=True, 
        hamming=True, 
        speaker='pink_2',    name='pink_2'
    )
    pink_2.setVolume(0.0)
    white_2 = sound.Sound(
        'A', 
        secs=-1, 
        stereo=True, 
        hamming=True, 
        speaker='white_2',    name='white_2'
    )
    white_2.setVolume(0.45)
    ComplexContinue = visual.ButtonStim(win, 
        text='Continue', font='Arial',
        pos=(-0.35, 0.35),
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='ComplexContinue',
        depth=-5
    )
    ComplexContinue.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "Demo_collect" ---
    Age_slider = visual.Slider(win=win, name='Age_slider',
        startValue=None, size=(0.9, 0.02), pos=(0, 0.3), units=win.units,
        labels=['18-25', '26-35', '36-45', '46-55', '56-65+'],ticks=None, granularity=1,
        style='radio', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.04,
        flip=False, ori=0.0, depth=0, readOnly=False)
    Gender_slider = visual.Slider(win=win, name='Gender_slider',
        startValue=None, size=(0.9, 0.02), pos=(0, 0.2), units=win.units,
        labels=['Male', 'Female', 'other'],ticks=None, granularity=1,
        style='radio', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.04,
        flip=False, ori=0.0, depth=-1, readOnly=False)
    Language_textbox = visual.TextBox2(
         win, text=None, placeholder='What is your first language', font='Arial',
         pos=(0, 0.1),     letterHeight=0.02,
         size=(0.9, 0.03), borderWidth=2.0,
         color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb',
         opacity=None,
         bold=False, italic=False,
         lineSpacing=1.0, speechPoint=None,
         padding=0.0, alignment='top-left',
         anchor='center', overflow='visible',
         fillColor=[1.0000, 1.0000, 1.0000], borderColor=None,
         flipHoriz=False, flipVert=False, languageStyle='LTR',
         editable=True,
         name='Language_textbox',
         depth=-2, autoLog=False,
    )
    Typing_slider = visual.Slider(win=win, name='Typing_slider',
        startValue=None, size=(0.9, 0.02), pos=(0, 0.0), units=win.units,
        labels=['touch typing (with both hands and all fingers)', 'hunt and press (must look at keyboard for key then press)', 'Hybrid (A mixture of both methods)'],ticks=None, granularity=1,
        style='radio', styleTweaks=(), opacity=None,
        labelColor='LightGray', markerColor='Red', lineColor='White', colorSpace='rgb',
        font='Arial', labelHeight=0.02,
        flip=False, ori=0.0, depth=-3, readOnly=False)
    Input_warning = visual.TextStim(win=win, name='Input_warning',
        text=None,
        font='Arial',
        pos=(0, -0.1), height=0.025, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-5.0);
    Input_button = visual.ButtonStim(win, 
        text='Click to Continue', font='Arial',
        pos=(0, -0.3),
        letterHeight=0.025,
        size=(0.35, 0.15), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Input_button',
        depth=-6
    )
    Input_button.buttonClock = core.Clock()
    
    # --- Initialize components for Routine "survay_1" ---
    win.allowStencil = True
    SUS_form = visual.Form(win=win, name='SUS_form',
        items='SUS_survey_form_v1.csv',
        textHeight=0.025,
        font='Arial',
        randomize=False,
        style='dark',
        fillColor=None, borderColor=None, itemColor='white', 
        responseColor='white', markerColor='red', colorSpace='rgb', 
        size=(0.9, 0.7),
        pos=(0, 0),
        itemPadding=0.05,
        depth=0
    )
    Submit_button = visual.ButtonStim(win, 
        text='submit ', font='Arvo',
        pos=(0, -0.45),
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Submit_button',
        depth=-2
    )
    Submit_button.buttonClock = core.Clock()
    WarningText = visual.TextStim(win=win, name='WarningText',
        text=None,
        font='Arial',
        pos=(0., 0.45), height=0.035, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "survay_2" ---
    win.allowStencil = True
    UEQ_form = visual.Form(win=win, name='UEQ_form',
        items='UEQ_survey_form_v1.csv',
        textHeight=0.025,
        font='Arial',
        randomize=False,
        style='dark',
        fillColor=None, borderColor=None, itemColor='white', 
        responseColor='white', markerColor='red', colorSpace='rgb', 
        size=(0.9, 0.7),
        pos=(0, 0),
        itemPadding=0.05,
        depth=0
    )
    Submit_button2 = visual.ButtonStim(win, 
        text='submit ', font='Arvo',
        pos=(0, -0.45),
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='Submit_button2',
        depth=-2
    )
    Submit_button2.buttonClock = core.Clock()
    WarningText2 = visual.TextStim(win=win, name='WarningText2',
        text=None,
        font='Arial',
        pos=(0., 0.45), height=0.035, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "Debrief" ---
    debreif_text = visual.TextStim(win=win, name='debreif_text',
        text='Title: Adaptive user interface modifying ambient noise to support office work\n\nThank you for taking part in this research project; your contribution is very valuable.\n\nTo finish, please click the exit button. If you would like further details about the experiment and its factors, please continue reading.\n\nDebrief:\nAs you may have noticed, the background noise changed when you were struggling; this was the colour of the noise changing from white to pink. Both coloured noises have been shown to improve task accuracy in many aspects, with pink usually showing slightly higher results. The most important aspect of this experiment is memory recall and improved focus. The coloured noises may achieve this by resonating with neurons in the brain and inducing a flow state. The noise was changed in real time was by monitoring your keyboard dynamics, i.e. essentially how you interacted with the keyboard. It has been found that the pauses you take between button presses and the number of times you press backspace both increase as mental stress increases. As your mental stress grew, so did your pauses and backspaces, causing a change in background noise that hopefully supported your focus and memory recall. We hope that the data you provided will help us to test whether this method can indeed improve task efficiency and the overall experience of performing office-related tasks.\n\nData:\nYour data will be stored, shared and processed as outlined in the Participant Information Sheet and Consent form for this project.\n\nContact:\nIf you have any further questions, you may contact the researcher or my supervisor at the details below.\n\nHead Researcher: Connor Murphy 1903299@uad.ac.uk\nLead Supervisor: Vera Kampe v.kempe@abertay.ac.uk\n\nThank you once again for taking part in the research!',
        font='Arial',
        pos=(0, 0.1), height=0.02, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    button = visual.ButtonStim(win, 
        text='Finish', font='Arial',
        pos=(0, -0.4),
        letterHeight=0.05,
        size=(0.3, 0.1), borderWidth=0.0,
        fillColor='darkgrey', borderColor=None,
        color='white', colorSpace='rgb',
        opacity=None,
        bold=True, italic=False,
        padding=None,
        anchor='center',
        name='button',
        depth=-2
    )
    button.buttonClock = core.Clock()
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    # get group from shelf
    counterbalance.allocateGroup()
    thisExp.addData('counterbalance.group', counterbalance.group)
    for _key, _val in counterbalance.params.items():
        thisExp.addData(f'counterbalance.{_key}', _val)
    thisExp.addData('counterbalance.remaining', counterbalance.remaining)
    thisExp.nextEntry()
    # the Routine "counterbalance" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "explanation" ---
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from text_alignment
    text.alignHoriz = 'left'
    text.alignText = 'left'
    textPart2.alignHoriz = 'left'
    textPart2.alignText = 'left'
    # reset Continue_button to account for continued clicks & clear times on/off
    Continue_button.reset()
    # reset Exit_button to account for continued clicks & clear times on/off
    Exit_button.reset()
    # keep track of which components have finished
    explanationComponents = [Continue_button, Exit_button, text, textPart2]
    for thisComponent in explanationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "explanation" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # *Continue_button* updates
        
        # if Continue_button is starting this frame...
        if Continue_button.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Continue_button.frameNStart = frameN  # exact frame index
            Continue_button.tStart = t  # local t and not account for scr refresh
            Continue_button.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Continue_button, 'tStartRefresh')  # time at next scr refresh
            # update status
            Continue_button.status = STARTED
            Continue_button.setAutoDraw(True)
        
        # if Continue_button is active this frame...
        if Continue_button.status == STARTED:
            # update params
            pass
            # check whether Continue_button has been pressed
            if Continue_button.isClicked:
                if not Continue_button.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Continue_button.timesOn.append(Continue_button.buttonClock.getTime())
                    Continue_button.timesOff.append(Continue_button.buttonClock.getTime())
                elif len(Continue_button.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Continue_button.timesOff[-1] = Continue_button.buttonClock.getTime()
                if not Continue_button.wasClicked:
                    # end routine when Continue_button is clicked
                    continueRoutine = False
                if not Continue_button.wasClicked:
                    # run callback code when Continue_button is clicked
                    print("continue pressed")
                    continueRoutine = False
        # take note of whether Continue_button was clicked, so that next frame we know if clicks are new
        Continue_button.wasClicked = Continue_button.isClicked and Continue_button.status == STARTED
        # *Exit_button* updates
        
        # if Exit_button is starting this frame...
        if Exit_button.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Exit_button.frameNStart = frameN  # exact frame index
            Exit_button.tStart = t  # local t and not account for scr refresh
            Exit_button.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Exit_button, 'tStartRefresh')  # time at next scr refresh
            # update status
            Exit_button.status = STARTED
            Exit_button.setAutoDraw(True)
        
        # if Exit_button is active this frame...
        if Exit_button.status == STARTED:
            # update params
            pass
            # check whether Exit_button has been pressed
            if Exit_button.isClicked:
                if not Exit_button.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Exit_button.timesOn.append(Exit_button.buttonClock.getTime())
                    Exit_button.timesOff.append(Exit_button.buttonClock.getTime())
                elif len(Exit_button.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Exit_button.timesOff[-1] = Exit_button.buttonClock.getTime()
                if not Exit_button.wasClicked:
                    # end routine when Exit_button is clicked
                    continueRoutine = False
                if not Exit_button.wasClicked:
                    # run callback code when Exit_button is clicked
                    core.quit()
        # take note of whether Exit_button was clicked, so that next frame we know if clicks are new
        Exit_button.wasClicked = Exit_button.isClicked and Exit_button.status == STARTED
        
        # *text* updates
        
        # if text is starting this frame...
        if text.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            # update status
            text.status = STARTED
            text.setAutoDraw(True)
        
        # if text is active this frame...
        if text.status == STARTED:
            # update params
            text.setText('Project title: Adaptive user interface modifying ambient noise to support office work\n\nResearcher: Connor Murphy – MSc student\nSupervisors: Prof Vera Kempe, Dr Andrea Szymkowiak\n\nWhat is the research about?\nThis project explores an adaptive user interface to support office-based tasks. Adaptive user interfaces are systems that automatically adapt to a user’s preferences or predefined optimisation criteria. You may already have used an adaptive user interface in the past and not noticed. In this study, we explore whether certain types of background noise can support users who struggle with a task.\n\nDo I have to take part?\nIt is up to you and you alone whether you wish to take part. If you do decide to take part, you will be free to withdraw at any time without providing a reason and without penalty.\n\nWhat will I be asked to do?\nYou will be asked to watch multiple recipe tutorials and then to write up that recipe in as much detail as you can remember, one after the other. You will be given a time limit for the write-ups. The spelling and grammar of your write-ups are not important, only its accuracy, so please focus on writing down of the details you remember. After this, you will be asked to fill out three questionnaires, two about the writing experience and one about basic demographic data. This experiment should take approximately 30 minutes to complete.\n\nHow will you handle my data?\nYour data will be stored in anonymised form at the point of collection and will only be accessible to the researcher and the supervisors. Anonymisation means that nobody, including the researchers, can identify you within the data. Your data will be stored in secure servers at Abertay University. Your responses are treated in the strictest confidence - it will be impossible to identify individuals within a dataset when the research is disseminated (e.g., in publications/presentations/datasets). Please note that your data can no longer be retrieved once the data is anonymised. Abertay University acts as Data Controller (DataProtectionOfficer@abertay.ac.uk).', log=False)
        
        # *textPart2* updates
        
        # if textPart2 is starting this frame...
        if textPart2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            textPart2.frameNStart = frameN  # exact frame index
            textPart2.tStart = t  # local t and not account for scr refresh
            textPart2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(textPart2, 'tStartRefresh')  # time at next scr refresh
            # update status
            textPart2.status = STARTED
            textPart2.setAutoDraw(True)
        
        # if textPart2 is active this frame...
        if textPart2.status == STARTED:
            # update params
            textPart2.setText('Retention of research data:\nResearchers are obliged to retain research data for up to 10 years post-publication; however, your anonymised research data may be retained indefinitely (e.g., so that researchers engage in open research, and other researchers can access their data to confirm the conclusions of published work). Consistent with our data retention policy, researchers retain consent forms for as long as we continue to hold information about a data subject and for 10 years for published research (including Research Degree thesis).\n\nConsent statement:\nAbertay University attaches high priority to the ethical conduct of research. Please consider the following before indicating your consent on this form. Indicating your consent confirms that you are willing to participate in the research; however, indicating consent does not commit you to anything you do not wish to do and you are free to withdraw your participation at any time. You are indicating consent under the following assumptions:\n\n· I understand the contents of the participant information sheet and consent form.\n\n· I have been given the opportunity to ask questions about the research and have had them answered satisfactorily.\n\n· I understand that my participation is entirely voluntary and that I can withdraw from the research (parts of the project or the entire project) at any time without penalty and without having to provide an explanation.\n\n· I understand who has access to my data and how it will be handled at all stages of the research project.\n\n· I consent to take part in this study conducted by Connor Murphy, who intends to use my data for further research examining the impact of background noise on office tasks.\n\n· I consent for Connor Murphy to collect and process my sensitive data relating to age and sex.\n\nYou can find our procedure for complaints (regarding research projects) and our privacy notice and legal basis for processing research data at: https://www.abertay.ac.uk/legal/privacy-notice-for-research-participants/', log=False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in explanationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "explanation" ---
    for thisComponent in explanationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.nextEntry()
    # the Routine "explanation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Instruction" ---
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from text_alignment_2
    Instruction_text.alignHoriz = 'left'
    Instruction_text.alignText = 'left'
    
    # reset continue_2 to account for continued clicks & clear times on/off
    continue_2.reset()
    # keep track of which components have finished
    InstructionComponents = [Instruction_text, continue_2]
    for thisComponent in InstructionComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Instruction" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Instruction_text* updates
        
        # if Instruction_text is starting this frame...
        if Instruction_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Instruction_text.frameNStart = frameN  # exact frame index
            Instruction_text.tStart = t  # local t and not account for scr refresh
            Instruction_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Instruction_text, 'tStartRefresh')  # time at next scr refresh
            # update status
            Instruction_text.status = STARTED
            Instruction_text.setAutoDraw(True)
        
        # if Instruction_text is active this frame...
        if Instruction_text.status == STARTED:
            # update params
            pass
        # *continue_2* updates
        
        # if continue_2 is starting this frame...
        if continue_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            continue_2.frameNStart = frameN  # exact frame index
            continue_2.tStart = t  # local t and not account for scr refresh
            continue_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(continue_2, 'tStartRefresh')  # time at next scr refresh
            # update status
            continue_2.status = STARTED
            continue_2.setAutoDraw(True)
        
        # if continue_2 is active this frame...
        if continue_2.status == STARTED:
            # update params
            pass
            # check whether continue_2 has been pressed
            if continue_2.isClicked:
                if not continue_2.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    continue_2.timesOn.append(continue_2.buttonClock.getTime())
                    continue_2.timesOff.append(continue_2.buttonClock.getTime())
                elif len(continue_2.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    continue_2.timesOff[-1] = continue_2.buttonClock.getTime()
                if not continue_2.wasClicked:
                    # end routine when continue_2 is clicked
                    continueRoutine = False
                if not continue_2.wasClicked:
                    # run callback code when continue_2 is clicked
                    pass
        # take note of whether continue_2 was clicked, so that next frame we know if clicks are new
        continue_2.wasClicked = continue_2.isClicked and continue_2.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in InstructionComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Instruction" ---
    for thisComponent in InstructionComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.nextEntry()
    # the Routine "Instruction" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Video_1" ---
    continueRoutine = True
    # update component parameters for each repeat
    # keep track of which components have finished
    Video_1Components = [Simple_movie]
    for thisComponent in Video_1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Video_1" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Simple_movie* updates
        
        # if Simple_movie is starting this frame...
        if Simple_movie.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Simple_movie.frameNStart = frameN  # exact frame index
            Simple_movie.tStart = t  # local t and not account for scr refresh
            Simple_movie.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Simple_movie, 'tStartRefresh')  # time at next scr refresh
            # update status
            Simple_movie.status = STARTED
            Simple_movie.setAutoDraw(True)
            Simple_movie.play()
        if Simple_movie.isFinished:  # force-end the Routine
            continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Video_1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Video_1" ---
    for thisComponent in Video_1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Simple_movie.stop()  # ensure movie has stopped at end of Routine
    thisExp.nextEntry()
    # the Routine "Video_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "simple_task" ---
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from data_reading
    pause_times = []
    last_key_time = None
    typing_clock = core.Clock()
    if counterbalance.group == '1':
        print(counterbalance.group)
    Simple_textbox.reset()
    white.setSound('C:/Users/ninja/Documents/Masters project/eperiment/White.wav', hamming=True)
    white.setVolume(0.45, log=False)
    white.seek(0)
    pink.setSound('C:/Users/ninja/Documents/Masters project/eperiment/Pink.wav', hamming=True)
    pink.setVolume(0.0, log=False)
    pink.seek(0)
    # reset SimpleContinue to account for continued clicks & clear times on/off
    SimpleContinue.reset()
    # keep track of which components have finished
    simple_taskComponents = [Simple_textbox, Countdown, white, pink, SimpleContinue]
    for thisComponent in simple_taskComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "simple_task" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from data_reading
        # Check for any new keypress
        keys = event.getKeys(timeStamped=typing_clock)
        
        for key, timestamp in keys:
            if last_key_time is not None:
                pause = timestamp - last_key_time
                if pause > 0.15 and pause < 1.5:
                    pause_times.append(pause)
            last_key_time = timestamp
        
        # *Simple_textbox* updates
        
        # if Simple_textbox is starting this frame...
        if Simple_textbox.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Simple_textbox.frameNStart = frameN  # exact frame index
            Simple_textbox.tStart = t  # local t and not account for scr refresh
            Simple_textbox.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Simple_textbox, 'tStartRefresh')  # time at next scr refresh
            # update status
            Simple_textbox.status = STARTED
            Simple_textbox.setAutoDraw(True)
        
        # if Simple_textbox is active this frame...
        if Simple_textbox.status == STARTED:
            # update params
            pass
        
        # *Countdown* updates
        
        # if Countdown is starting this frame...
        if Countdown.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Countdown.frameNStart = frameN  # exact frame index
            Countdown.tStart = t  # local t and not account for scr refresh
            Countdown.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Countdown, 'tStartRefresh')  # time at next scr refresh
            # update status
            Countdown.status = STARTED
            Countdown.setAutoDraw(True)
        
        # if Countdown is active this frame...
        if Countdown.status == STARTED:
            # update params
            pass
        
        # if white is starting this frame...
        if white.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            white.frameNStart = frameN  # exact frame index
            white.tStart = t  # local t and not account for scr refresh
            white.tStartRefresh = tThisFlipGlobal  # on global time
            # update status
            white.status = STARTED
            white.play(when=win)  # sync with win flip
        # update white status according to whether it's playing
        if white.isPlaying:
            white.status = STARTED
        elif white.isFinished:
            white.status = FINISHED
        
        # if pink is starting this frame...
        if pink.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pink.frameNStart = frameN  # exact frame index
            pink.tStart = t  # local t and not account for scr refresh
            pink.tStartRefresh = tThisFlipGlobal  # on global time
            # update status
            pink.status = STARTED
            pink.play(when=win)  # sync with win flip
        # update pink status according to whether it's playing
        if pink.isPlaying:
            pink.status = STARTED
        elif pink.isFinished:
            pink.status = FINISHED
        # *SimpleContinue* updates
        
        # if SimpleContinue is starting this frame...
        if SimpleContinue.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            SimpleContinue.frameNStart = frameN  # exact frame index
            SimpleContinue.tStart = t  # local t and not account for scr refresh
            SimpleContinue.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(SimpleContinue, 'tStartRefresh')  # time at next scr refresh
            # update status
            SimpleContinue.status = STARTED
            SimpleContinue.setAutoDraw(True)
        
        # if SimpleContinue is active this frame...
        if SimpleContinue.status == STARTED:
            # update params
            pass
            # check whether SimpleContinue has been pressed
            if SimpleContinue.isClicked:
                if not SimpleContinue.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    SimpleContinue.timesOn.append(SimpleContinue.buttonClock.getTime())
                    SimpleContinue.timesOff.append(SimpleContinue.buttonClock.getTime())
                elif len(SimpleContinue.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    SimpleContinue.timesOff[-1] = SimpleContinue.buttonClock.getTime()
                if not SimpleContinue.wasClicked:
                    # end routine when SimpleContinue is clicked
                    continueRoutine = False
                if not SimpleContinue.wasClicked:
                    # run callback code when SimpleContinue is clicked
                    pass
        # take note of whether SimpleContinue was clicked, so that next frame we know if clicks are new
        SimpleContinue.wasClicked = SimpleContinue.isClicked and SimpleContinue.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in simple_taskComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "simple_task" ---
    for thisComponent in simple_taskComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # Run 'End Routine' code from data_reading
    import numpy as np
    
    if len(pause_times) >= 2:
        p75 = np.percentile(pause_times, 75)
    else:
        p75 = None  # Not enough data
    
    expInfo['pause_p75'] = p75  
    thisExp.addData('pause_p75', p75)
    print(pause_times[1], pause_times[10])
    print(expInfo['pause_p75'])
    thisExp.addData('Simple_textbox.text',Simple_textbox.text)
    white.pause()  # ensure sound has stopped at end of Routine
    pink.pause()  # ensure sound has stopped at end of Routine
    thisExp.nextEntry()
    # the Routine "simple_task" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Video_2" ---
    continueRoutine = True
    # update component parameters for each repeat
    # keep track of which components have finished
    Video_2Components = [Complex_Movie]
    for thisComponent in Video_2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Video_2" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Complex_Movie* updates
        
        # if Complex_Movie is starting this frame...
        if Complex_Movie.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Complex_Movie.frameNStart = frameN  # exact frame index
            Complex_Movie.tStart = t  # local t and not account for scr refresh
            Complex_Movie.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Complex_Movie, 'tStartRefresh')  # time at next scr refresh
            # update status
            Complex_Movie.status = STARTED
            Complex_Movie.setAutoDraw(True)
            Complex_Movie.play()
        if Complex_Movie.isFinished:  # force-end the Routine
            continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Video_2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Video_2" ---
    for thisComponent in Video_2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Complex_Movie.stop()  # ensure movie has stopped at end of Routine
    thisExp.nextEntry()
    # the Routine "Video_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Complex_task" ---
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from keyboard_dynamics_noise_control_2
    pause_times = []
    recentBackspaces = []
    last_key = None
    last_key_time = 0.0
    valid_pauses = 0
    typing_clock = core.Clock()
    delCheck = False
    IKICheck = False
    del_event = []
    pause_event = []
    noise_to_pink =[]
    keyLog = []
    
    Complex_textbox.reset()
    pink_2.setSound('C:/Users/ninja/Documents/Masters project/eperiment/Pink.wav', hamming=True)
    pink_2.setVolume(0.0, log=False)
    pink_2.seek(0)
    white_2.setSound('C:/Users/ninja/Documents/Masters project/eperiment/White.wav', hamming=True)
    white_2.setVolume(0.45, log=False)
    white_2.seek(0)
    # reset ComplexContinue to account for continued clicks & clear times on/off
    ComplexContinue.reset()
    # keep track of which components have finished
    Complex_taskComponents = [Countdown_2, Complex_textbox, pink_2, white_2, ComplexContinue]
    for thisComponent in Complex_taskComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Complex_task" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from keyboard_dynamics_noise_control_2
        # Get new keypresses with timestamps
        keys = event.getKeys(timeStamped=typing_clock)
        
        for key, timestamp in keys:
            keyLog.append({'key': key, 'time': timestamp})
            if key == 'backspace':
                recentBackspaces.append(timestamp)
            else:
                pause_times.append((key,timestamp))   
             
        current_time = typing_clock.getTime()
        recentBackspaces = [t for t in recentBackspaces if current_time - t <= 10]
        pause_times = [(key,time) for key, time in pause_times if current_time - time <= 10]
        
        if len(recentBackspaces) >= 4:
            # Get the most recent backspaces
            recent_four = recentBackspaces[-4:]
            time_window = recent_four[-1] - recent_four[0]
        
            if time_window <= 5.0:
                #print("5 backspaces within 5 seconds!")
                delCheck = True
                del_event.append(typing_clock.getTime())
            else:
                #print("not enough back spases1")
                delCheck = False
        else:
            #print("not enough back spases2")
            delCheck = False
            
            
        for x in range(len(pause_times)):
            key, time = pause_times[x]
            
            if (key in [' ', '.']) or (last_key in [' ', '.']):
                print(". occoured")
                last_key = key
                last_key_time = time
                continue 
        
            pause = time - last_key_time
            last_key = key
            last_key_time = time
        
            if pause > expInfo['pause_p75']:
                valid_pauses += 1
                #print('valid pause+1')
            
        #print('total valid pauses' + str(valid_pauses))    
        if valid_pauses >= 5:
            #print('valid pause >= 5')
            pause_event.append(typing_clock.getTime())
            valid_pauses = 0
            IKICheck = True
        else:
            IKICheck = False      
            
        valid_pauses = 0    
        
        
        if counterbalance.group == '1':
            if delCheck == True and IKICheck == True:
                pink_2.setVolume(0.45)
                white_2.setVolume(0.0)
                noise_to_pink.append(typing_clock.getTime())
            else:
                pink_2.setVolume(0.0)
                white_2.setVolume(0.45)
        else:
            if delCheck == True and IKICheck == True:
                noise_to_pink.append(typing_clock.getTime())
        
            
        
        
        # *Countdown_2* updates
        
        # if Countdown_2 is starting this frame...
        if Countdown_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Countdown_2.frameNStart = frameN  # exact frame index
            Countdown_2.tStart = t  # local t and not account for scr refresh
            Countdown_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Countdown_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Countdown_2.started')
            # update status
            Countdown_2.status = STARTED
            Countdown_2.setAutoDraw(True)
        
        # if Countdown_2 is active this frame...
        if Countdown_2.status == STARTED:
            # update params
            pass
        
        # *Complex_textbox* updates
        
        # if Complex_textbox is starting this frame...
        if Complex_textbox.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Complex_textbox.frameNStart = frameN  # exact frame index
            Complex_textbox.tStart = t  # local t and not account for scr refresh
            Complex_textbox.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Complex_textbox, 'tStartRefresh')  # time at next scr refresh
            # update status
            Complex_textbox.status = STARTED
            Complex_textbox.setAutoDraw(True)
        
        # if Complex_textbox is active this frame...
        if Complex_textbox.status == STARTED:
            # update params
            pass
        
        # if pink_2 is starting this frame...
        if pink_2.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pink_2.frameNStart = frameN  # exact frame index
            pink_2.tStart = t  # local t and not account for scr refresh
            pink_2.tStartRefresh = tThisFlipGlobal  # on global time
            # update status
            pink_2.status = STARTED
            pink_2.play()  # start the sound (it finishes automatically)
        # update pink_2 status according to whether it's playing
        if pink_2.isPlaying:
            pink_2.status = STARTED
        elif pink_2.isFinished:
            pink_2.status = FINISHED
        
        # if white_2 is starting this frame...
        if white_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            white_2.frameNStart = frameN  # exact frame index
            white_2.tStart = t  # local t and not account for scr refresh
            white_2.tStartRefresh = tThisFlipGlobal  # on global time
            # update status
            white_2.status = STARTED
            white_2.play(when=win)  # sync with win flip
        # update white_2 status according to whether it's playing
        if white_2.isPlaying:
            white_2.status = STARTED
        elif white_2.isFinished:
            white_2.status = FINISHED
        # *ComplexContinue* updates
        
        # if ComplexContinue is starting this frame...
        if ComplexContinue.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            ComplexContinue.frameNStart = frameN  # exact frame index
            ComplexContinue.tStart = t  # local t and not account for scr refresh
            ComplexContinue.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ComplexContinue, 'tStartRefresh')  # time at next scr refresh
            # update status
            ComplexContinue.status = STARTED
            ComplexContinue.setAutoDraw(True)
        
        # if ComplexContinue is active this frame...
        if ComplexContinue.status == STARTED:
            # update params
            pass
            # check whether ComplexContinue has been pressed
            if ComplexContinue.isClicked:
                if not ComplexContinue.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    ComplexContinue.timesOn.append(ComplexContinue.buttonClock.getTime())
                    ComplexContinue.timesOff.append(ComplexContinue.buttonClock.getTime())
                elif len(ComplexContinue.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    ComplexContinue.timesOff[-1] = ComplexContinue.buttonClock.getTime()
                if not ComplexContinue.wasClicked:
                    # end routine when ComplexContinue is clicked
                    continueRoutine = False
                if not ComplexContinue.wasClicked:
                    # run callback code when ComplexContinue is clicked
                    pass
        # take note of whether ComplexContinue was clicked, so that next frame we know if clicks are new
        ComplexContinue.wasClicked = ComplexContinue.isClicked and ComplexContinue.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Complex_taskComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Complex_task" ---
    for thisComponent in Complex_taskComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # Run 'End Routine' code from keyboard_dynamics_noise_control_2
    import json
    
    participant_id = expInfo['participant']
    allKeys = ';'.join([f" - {k['key']} {k['time']:.3f} - " for k in keyLog])
    filename = f"KD_data_participant_{participant_id}.json"
    with open(filename, 'w') as f:
        json.dump({
            'deleteEvents': del_event,
            'pauseEvents': pause_event,
            'noiseToPink': noise_to_pink,
            'allKeys': keyLog
        }, f)
    thisExp.addData('task_end_time', typing_clock.getTime())
    thisExp.addData('Complex_textbox.text',Complex_textbox.text)
    white_2.pause()  # ensure sound has stopped at end of Routine
    thisExp.nextEntry()
    # the Routine "Complex_task" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Demo_collect" ---
    continueRoutine = True
    # update component parameters for each repeat
    Age_slider.reset()
    Gender_slider.reset()
    Language_textbox.reset()
    Typing_slider.reset()
    # reset Input_button to account for continued clicks & clear times on/off
    Input_button.reset()
    # keep track of which components have finished
    Demo_collectComponents = [Age_slider, Gender_slider, Language_textbox, Typing_slider, Input_warning, Input_button]
    for thisComponent in Demo_collectComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Demo_collect" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Age_slider* updates
        
        # if Age_slider is starting this frame...
        if Age_slider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Age_slider.frameNStart = frameN  # exact frame index
            Age_slider.tStart = t  # local t and not account for scr refresh
            Age_slider.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Age_slider, 'tStartRefresh')  # time at next scr refresh
            # update status
            Age_slider.status = STARTED
            Age_slider.setAutoDraw(True)
        
        # if Age_slider is active this frame...
        if Age_slider.status == STARTED:
            # update params
            pass
        
        # *Gender_slider* updates
        
        # if Gender_slider is starting this frame...
        if Gender_slider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Gender_slider.frameNStart = frameN  # exact frame index
            Gender_slider.tStart = t  # local t and not account for scr refresh
            Gender_slider.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Gender_slider, 'tStartRefresh')  # time at next scr refresh
            # update status
            Gender_slider.status = STARTED
            Gender_slider.setAutoDraw(True)
        
        # if Gender_slider is active this frame...
        if Gender_slider.status == STARTED:
            # update params
            pass
        
        # *Language_textbox* updates
        
        # if Language_textbox is starting this frame...
        if Language_textbox.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Language_textbox.frameNStart = frameN  # exact frame index
            Language_textbox.tStart = t  # local t and not account for scr refresh
            Language_textbox.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Language_textbox, 'tStartRefresh')  # time at next scr refresh
            # update status
            Language_textbox.status = STARTED
            Language_textbox.setAutoDraw(True)
        
        # if Language_textbox is active this frame...
        if Language_textbox.status == STARTED:
            # update params
            pass
        
        # *Typing_slider* updates
        
        # if Typing_slider is starting this frame...
        if Typing_slider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Typing_slider.frameNStart = frameN  # exact frame index
            Typing_slider.tStart = t  # local t and not account for scr refresh
            Typing_slider.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Typing_slider, 'tStartRefresh')  # time at next scr refresh
            # update status
            Typing_slider.status = STARTED
            Typing_slider.setAutoDraw(True)
        
        # if Typing_slider is active this frame...
        if Typing_slider.status == STARTED:
            # update params
            pass
        # Run 'Each Frame' code from input_check
        if Input_button.isClicked:
            text_filled = Language_textbox.text.strip() != ''
            sliders_filled = all([
                Typing_slider.getRating() is not None,
                Gender_slider.getRating() is not None,
                Age_slider.getRating() is not None
            ])
        
            # Enable the continue button
            if text_filled and sliders_filled:
                continueRoutine = False  # End the routine
            else:
                Input_warning.text = "Please complete all questions before continuing."
        
        # *Input_warning* updates
        
        # if Input_warning is starting this frame...
        if Input_warning.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Input_warning.frameNStart = frameN  # exact frame index
            Input_warning.tStart = t  # local t and not account for scr refresh
            Input_warning.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Input_warning, 'tStartRefresh')  # time at next scr refresh
            # update status
            Input_warning.status = STARTED
            Input_warning.setAutoDraw(True)
        
        # if Input_warning is active this frame...
        if Input_warning.status == STARTED:
            # update params
            pass
        # *Input_button* updates
        
        # if Input_button is starting this frame...
        if Input_button.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Input_button.frameNStart = frameN  # exact frame index
            Input_button.tStart = t  # local t and not account for scr refresh
            Input_button.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Input_button, 'tStartRefresh')  # time at next scr refresh
            # update status
            Input_button.status = STARTED
            Input_button.setAutoDraw(True)
        
        # if Input_button is active this frame...
        if Input_button.status == STARTED:
            # update params
            pass
            # check whether Input_button has been pressed
            if Input_button.isClicked:
                if not Input_button.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Input_button.timesOn.append(Input_button.buttonClock.getTime())
                    Input_button.timesOff.append(Input_button.buttonClock.getTime())
                elif len(Input_button.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Input_button.timesOff[-1] = Input_button.buttonClock.getTime()
                # run callback code when Input_button is clicked
                pass
        # take note of whether Input_button was clicked, so that next frame we know if clicks are new
        Input_button.wasClicked = Input_button.isClicked and Input_button.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Demo_collectComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Demo_collect" ---
    for thisComponent in Demo_collectComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('Age_slider.response', Age_slider.getRating())
    thisExp.addData('Gender_slider.response', Gender_slider.getRating())
    thisExp.addData('Language_textbox.text',Language_textbox.text)
    thisExp.addData('Typing_slider.response', Typing_slider.getRating())
    thisExp.nextEntry()
    # the Routine "Demo_collect" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "survay_1" ---
    continueRoutine = True
    # update component parameters for each repeat
    # reset Submit_button to account for continued clicks & clear times on/off
    Submit_button.reset()
    # keep track of which components have finished
    survay_1Components = [SUS_form, Submit_button, WarningText]
    for thisComponent in survay_1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "survay_1" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *SUS_form* updates
        
        # if SUS_form is starting this frame...
        if SUS_form.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            SUS_form.frameNStart = frameN  # exact frame index
            SUS_form.tStart = t  # local t and not account for scr refresh
            SUS_form.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(SUS_form, 'tStartRefresh')  # time at next scr refresh
            # update status
            SUS_form.status = STARTED
            SUS_form.setAutoDraw(True)
        
        # if SUS_form is active this frame...
        if SUS_form.status == STARTED:
            # update params
            pass
        # Run 'Each Frame' code from code
        # Check for click
        if Submit_button.isClicked:
            formData = SUS_form.getData()
            
            # Check if all items have a response
            completed = all([q['response'] not in [None, ''] for q in formData])
            
            if completed:
                continueRoutine = False  # End the routine
            else:
                WarningText.text = "Please complete all questions before continuing."
        # *Submit_button* updates
        
        # if Submit_button is starting this frame...
        if Submit_button.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Submit_button.frameNStart = frameN  # exact frame index
            Submit_button.tStart = t  # local t and not account for scr refresh
            Submit_button.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Submit_button, 'tStartRefresh')  # time at next scr refresh
            # update status
            Submit_button.status = STARTED
            Submit_button.setAutoDraw(True)
        
        # if Submit_button is active this frame...
        if Submit_button.status == STARTED:
            # update params
            pass
            # check whether Submit_button has been pressed
            if Submit_button.isClicked:
                if not Submit_button.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Submit_button.timesOn.append(Submit_button.buttonClock.getTime())
                    Submit_button.timesOff.append(Submit_button.buttonClock.getTime())
                elif len(Submit_button.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Submit_button.timesOff[-1] = Submit_button.buttonClock.getTime()
                # run callback code when Submit_button is clicked
                pass
        # take note of whether Submit_button was clicked, so that next frame we know if clicks are new
        Submit_button.wasClicked = Submit_button.isClicked and Submit_button.status == STARTED
        
        # *WarningText* updates
        
        # if WarningText is starting this frame...
        if WarningText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            WarningText.frameNStart = frameN  # exact frame index
            WarningText.tStart = t  # local t and not account for scr refresh
            WarningText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(WarningText, 'tStartRefresh')  # time at next scr refresh
            # update status
            WarningText.status = STARTED
            WarningText.setAutoDraw(True)
        
        # if WarningText is active this frame...
        if WarningText.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in survay_1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "survay_1" ---
    for thisComponent in survay_1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    SUS_form.addDataToExp(thisExp, 'rows')
    SUS_form.autodraw = False
    thisExp.nextEntry()
    # the Routine "survay_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "survay_2" ---
    continueRoutine = True
    # update component parameters for each repeat
    # reset Submit_button2 to account for continued clicks & clear times on/off
    Submit_button2.reset()
    # keep track of which components have finished
    survay_2Components = [UEQ_form, Submit_button2, WarningText2]
    for thisComponent in survay_2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "survay_2" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *UEQ_form* updates
        
        # if UEQ_form is starting this frame...
        if UEQ_form.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            UEQ_form.frameNStart = frameN  # exact frame index
            UEQ_form.tStart = t  # local t and not account for scr refresh
            UEQ_form.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(UEQ_form, 'tStartRefresh')  # time at next scr refresh
            # update status
            UEQ_form.status = STARTED
            UEQ_form.setAutoDraw(True)
        
        # if UEQ_form is active this frame...
        if UEQ_form.status == STARTED:
            # update params
            pass
        # Run 'Each Frame' code from Survau_Check
        # Check for click
        if Submit_button2.isClicked:
            formData = UEQ_form.getData()
            
            # Check if all items have a response
            completed = all([q['response'] not in [None, ''] for q in formData])
            
            if completed:
                continueRoutine = False  # End the routine
            else:
                WarningText2.text = "Please complete all questions before continuing."
        # *Submit_button2* updates
        
        # if Submit_button2 is starting this frame...
        if Submit_button2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Submit_button2.frameNStart = frameN  # exact frame index
            Submit_button2.tStart = t  # local t and not account for scr refresh
            Submit_button2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Submit_button2, 'tStartRefresh')  # time at next scr refresh
            # update status
            Submit_button2.status = STARTED
            Submit_button2.setAutoDraw(True)
        
        # if Submit_button2 is active this frame...
        if Submit_button2.status == STARTED:
            # update params
            pass
            # check whether Submit_button2 has been pressed
            if Submit_button2.isClicked:
                if not Submit_button2.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    Submit_button2.timesOn.append(Submit_button2.buttonClock.getTime())
                    Submit_button2.timesOff.append(Submit_button2.buttonClock.getTime())
                elif len(Submit_button2.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    Submit_button2.timesOff[-1] = Submit_button2.buttonClock.getTime()
                # run callback code when Submit_button2 is clicked
                pass
        # take note of whether Submit_button2 was clicked, so that next frame we know if clicks are new
        Submit_button2.wasClicked = Submit_button2.isClicked and Submit_button2.status == STARTED
        
        # *WarningText2* updates
        
        # if WarningText2 is starting this frame...
        if WarningText2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            WarningText2.frameNStart = frameN  # exact frame index
            WarningText2.tStart = t  # local t and not account for scr refresh
            WarningText2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(WarningText2, 'tStartRefresh')  # time at next scr refresh
            # update status
            WarningText2.status = STARTED
            WarningText2.setAutoDraw(True)
        
        # if WarningText2 is active this frame...
        if WarningText2.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in survay_2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "survay_2" ---
    for thisComponent in survay_2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    UEQ_form.addDataToExp(thisExp, 'rows')
    UEQ_form.autodraw = False
    thisExp.nextEntry()
    # the Routine "survay_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Debrief" ---
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from text_alignment_3
    debreif_text.alignHoriz = 'left'
    debreif_text.alignText = 'left'
    
    # reset button to account for continued clicks & clear times on/off
    button.reset()
    # keep track of which components have finished
    DebriefComponents = [debreif_text, button]
    for thisComponent in DebriefComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Debrief" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *debreif_text* updates
        
        # if debreif_text is starting this frame...
        if debreif_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            debreif_text.frameNStart = frameN  # exact frame index
            debreif_text.tStart = t  # local t and not account for scr refresh
            debreif_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(debreif_text, 'tStartRefresh')  # time at next scr refresh
            # update status
            debreif_text.status = STARTED
            debreif_text.setAutoDraw(True)
        
        # if debreif_text is active this frame...
        if debreif_text.status == STARTED:
            # update params
            pass
        # *button* updates
        
        # if button is starting this frame...
        if button.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            button.frameNStart = frameN  # exact frame index
            button.tStart = t  # local t and not account for scr refresh
            button.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(button, 'tStartRefresh')  # time at next scr refresh
            # update status
            button.status = STARTED
            button.setAutoDraw(True)
        
        # if button is active this frame...
        if button.status == STARTED:
            # update params
            pass
            # check whether button has been pressed
            if button.isClicked:
                if not button.wasClicked:
                    # if this is a new click, store time of first click and clicked until
                    button.timesOn.append(button.buttonClock.getTime())
                    button.timesOff.append(button.buttonClock.getTime())
                elif len(button.timesOff):
                    # if click is continuing from last frame, update time of clicked until
                    button.timesOff[-1] = button.buttonClock.getTime()
                if not button.wasClicked:
                    # end routine when button is clicked
                    continueRoutine = False
                if not button.wasClicked:
                    # run callback code when button is clicked
                    pass
        # take note of whether button was clicked, so that next frame we know if clicks are new
        button.wasClicked = button.isClicked and button.status == STARTED
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DebriefComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Debrief" ---
    for thisComponent in DebriefComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.nextEntry()
    # the Routine "Debrief" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # shut down eyetracker, if there is one
    if deviceManager.getDevice('eyetracker') is not None:
        deviceManager.removeDevice('eyetracker')
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    # shut down eyetracker, if there is one
    if deviceManager.getDevice('eyetracker') is not None:
        deviceManager.removeDevice('eyetracker')
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
