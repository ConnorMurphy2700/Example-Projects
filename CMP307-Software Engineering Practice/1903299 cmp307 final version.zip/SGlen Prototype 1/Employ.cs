﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SGlen_Prototype_1
{
    class Employ
    {
        SGlen_Prototype_1.mssql1903299Entities6 db = new SGlen_Prototype_1.mssql1903299Entities6();
        readonly SGlen_Prototype_1.Employee emp = new SGlen_Prototype_1.Employee();

        public bool Employ_Test(int id) // to see is Employee record exists 
        {
            try
            {
                var Log = (from a in db.Employees
                           where a.Employee_ID == id 
                           select a).First();

                if (Log != null)
                {
                    return true;
                }

            }

            catch (Exception x)
            {
                MessageBox.Show("User Not Found");
                return false;
            }
            return false;
        }

        public string GetHash(int Uname)
        {
            string test = (from x in db.Employees
                              where x.Employee_ID == Uname
                              select x.Pass).First();
            return test;
        }
    }
}
