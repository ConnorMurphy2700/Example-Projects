﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SGlen_Prototype_1
{
    class Search
    {
        SGlen_Prototype_1.mssql1903299Entities6 db = new SGlen_Prototype_1.mssql1903299Entities6();
        SGlen_Prototype_1.Asset asset = new SGlen_Prototype_1.Asset();
        readonly SGlen_Prototype_1.Location_Spes LSpes = new SGlen_Prototype_1.Location_Spes();
        readonly SGlen_Prototype_1.DLocation Loc = new SGlen_Prototype_1.DLocation();
        readonly SGlen_Prototype_1.Software sware = new SGlen_Prototype_1.Software();




        public bool Asset_Test(int id) // to see is asset record exists 
        {
            try
            {
                var Log = (from a in db.Assets
                           where a.Asset_ID == id
                           select a).First();

                if (Log != null)
                {
                    return true;
                }

            }

            catch (Exception x)
            {
                MessageBox.Show("Asset Not Found");
                return false;
            }
            return false;
        }

        public bool Location_Test(int id) // to see is Employee record exists 
        {
            try
            {
                var Log = (from a in db.DLocations
                           where a.Location_ID == id
                           select a).First();

                if (Log != null)
                {
                    return true;
                }

            }

            catch (Exception x)
            {
                MessageBox.Show("Location Not Found");
                return false;
            }
            return false;
        }

        public bool IP_Test(string id) // to see is location spes record exists 
        {
            try
            {
                var Log = (from a in db.Location_Spes
                           where a.IP_Address == id
                           select a).First();

                if (Log != null)
                {
                    return true;
                }

            }

            catch (Exception x)
            {
                MessageBox.Show("IP Not Found");
                return false;
            }
            return false;
        }



        public bool Software_Test(string id) // to see is software record exists 
        {
            try
            {
                var Log = (from a in db.Softwares
                           where a.OS == id
                           select a).First();

                if (Log != null)
                {
                    return true;
                }

            }

            catch (Exception x)
            {
               // MessageBox.Show("IP Not Found");
                return false;
            }
            return false;
        }

        public string Find_IP(int id) // to see is Employee record exists 
        {

                var Log = (from a in db.Assets
                           where a.Asset_ID == id
                           select a.IP_Address).First();

                if (Log != null)
                {
                    return Log;
                }

            return null;

        }

        public int Find_building(int id) // to see is Employee record exists 
        {

            int Log = (from a in db.Assets
                       where a.Asset_ID == id
                       select a.Location_ID).First();

            if (Log != 0)
            {
                return Log;
            }

            return 0;

        }

        public void  update_asset(string sware, string Changed) // to see is Employee record exists 
        {
            List<int> update = new List<int>();
             update = (from a in db.Assets
                       where a.OS == sware
                       select a.Asset_ID).ToList();

            foreach (var value in update)
            {
                asset = db.Assets.Find(value);
                asset.OS = Changed;
                db.SaveChanges();
            }
        }

    }
}
