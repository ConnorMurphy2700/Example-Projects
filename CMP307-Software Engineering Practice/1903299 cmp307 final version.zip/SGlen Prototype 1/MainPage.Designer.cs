﻿
namespace SGlen_Prototype_1
{
    partial class MainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Main_Assets = new System.Windows.Forms.DataGridView();
            this.assetIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diviceNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manufacturerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchaseDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hDDSerialNUMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.networkinterfaceNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.networkinterfaceTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.networkIPVersionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maintenanceNotesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.notesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.locationIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iPAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assetsBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet7 = new SGlen_Prototype_1.mssql1903299DataSet7();
            this.assetsBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet5 = new SGlen_Prototype_1.mssql1903299DataSet5();
            this.assetsBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet3 = new SGlen_Prototype_1.mssql1903299DataSet3();
            this.assetsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet2 = new SGlen_Prototype_1.mssql1903299DataSet2();
            this.assetsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.Find_Asset = new System.Windows.Forms.TextBox();
            this.SearchLocation = new System.Windows.Forms.Button();
            this.SearchId = new System.Windows.Forms.Button();
            this.AddAsset = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Update_Asset = new System.Windows.Forms.Button();
            this.Reset_Table = new System.Windows.Forms.Button();
            this.FindAsset = new System.Windows.Forms.Button();
            this.assetsTableAdapter = new SGlen_Prototype_1.mssql1903299DataSet2TableAdapters.AssetsTableAdapter();
            this.assetsTableAdapter1 = new SGlen_Prototype_1.mssql1903299DataSet3TableAdapters.AssetsTableAdapter();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Update_Location = new System.Windows.Forms.Button();
            this.Delete_Location = new System.Windows.Forms.Button();
            this.AddLocation = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Software_Relode = new System.Windows.Forms.Button();
            this.Software_Save = new System.Windows.Forms.Button();
            this.Software_manu = new System.Windows.Forms.TextBox();
            this.Software_OS = new System.Windows.Forms.TextBox();
            this.SoftwareGridView = new System.Windows.Forms.DataGridView();
            this.sWIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manufacturerDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.softwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet6 = new SGlen_Prototype_1.mssql1903299DataSet6();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.assetsTableAdapter2 = new SGlen_Prototype_1.mssql1903299DataSet5TableAdapters.AssetsTableAdapter();
            this.softwareTableAdapter = new SGlen_Prototype_1.mssql1903299DataSet6TableAdapters.SoftwareTableAdapter();
            this.assetsTableAdapter3 = new SGlen_Prototype_1.mssql1903299DataSet7TableAdapters.AssetsTableAdapter();
            this.mssql1903299DataSet10 = new SGlen_Prototype_1.mssql1903299DataSet10();
            this.assetsBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.assetsTableAdapter4 = new SGlen_Prototype_1.mssql1903299DataSet10TableAdapters.AssetsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.Main_Assets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SoftwareGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.softwareBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource5)).BeginInit();
            this.SuspendLayout();
            // 
            // Main_Assets
            // 
            this.Main_Assets.AllowUserToOrderColumns = true;
            this.Main_Assets.AutoGenerateColumns = false;
            this.Main_Assets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Main_Assets.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.assetIDDataGridViewTextBoxColumn,
            this.diviceNameDataGridViewTextBoxColumn,
            this.modelDataGridViewTextBoxColumn,
            this.manufacturerDataGridViewTextBoxColumn,
            this.mTypeDataGridViewTextBoxColumn,
            this.purchaseDateDataGridViewTextBoxColumn,
            this.hDDSerialNUMDataGridViewTextBoxColumn,
            this.OS,
            this.networkinterfaceNameDataGridViewTextBoxColumn,
            this.networkinterfaceTypeDataGridViewTextBoxColumn,
            this.networkIPVersionDataGridViewTextBoxColumn,
            this.maintenanceNotesDataGridViewTextBoxColumn,
            this.notesDataGridViewTextBoxColumn,
            this.locationIDDataGridViewTextBoxColumn,
            this.iPAddressDataGridViewTextBoxColumn});
            this.Main_Assets.DataSource = this.assetsBindingSource5;
            this.Main_Assets.Location = new System.Drawing.Point(6, 13);
            this.Main_Assets.Name = "Main_Assets";
            this.Main_Assets.RowHeadersWidth = 62;
            this.Main_Assets.RowTemplate.Height = 28;
            this.Main_Assets.Size = new System.Drawing.Size(1141, 239);
            this.Main_Assets.TabIndex = 0;
            // 
            // assetIDDataGridViewTextBoxColumn
            // 
            this.assetIDDataGridViewTextBoxColumn.DataPropertyName = "Asset_ID";
            this.assetIDDataGridViewTextBoxColumn.HeaderText = "Asset_ID";
            this.assetIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.assetIDDataGridViewTextBoxColumn.Name = "assetIDDataGridViewTextBoxColumn";
            this.assetIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.assetIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // diviceNameDataGridViewTextBoxColumn
            // 
            this.diviceNameDataGridViewTextBoxColumn.DataPropertyName = "Divice_Name";
            this.diviceNameDataGridViewTextBoxColumn.HeaderText = "Divice_Name";
            this.diviceNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.diviceNameDataGridViewTextBoxColumn.Name = "diviceNameDataGridViewTextBoxColumn";
            this.diviceNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // modelDataGridViewTextBoxColumn
            // 
            this.modelDataGridViewTextBoxColumn.DataPropertyName = "Model";
            this.modelDataGridViewTextBoxColumn.HeaderText = "Model";
            this.modelDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.modelDataGridViewTextBoxColumn.Name = "modelDataGridViewTextBoxColumn";
            this.modelDataGridViewTextBoxColumn.Width = 150;
            // 
            // manufacturerDataGridViewTextBoxColumn
            // 
            this.manufacturerDataGridViewTextBoxColumn.DataPropertyName = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn.HeaderText = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.manufacturerDataGridViewTextBoxColumn.Name = "manufacturerDataGridViewTextBoxColumn";
            this.manufacturerDataGridViewTextBoxColumn.Width = 150;
            // 
            // mTypeDataGridViewTextBoxColumn
            // 
            this.mTypeDataGridViewTextBoxColumn.DataPropertyName = "MType";
            this.mTypeDataGridViewTextBoxColumn.HeaderText = "MType";
            this.mTypeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.mTypeDataGridViewTextBoxColumn.Name = "mTypeDataGridViewTextBoxColumn";
            this.mTypeDataGridViewTextBoxColumn.Width = 150;
            // 
            // purchaseDateDataGridViewTextBoxColumn
            // 
            this.purchaseDateDataGridViewTextBoxColumn.DataPropertyName = "Purchase_Date";
            this.purchaseDateDataGridViewTextBoxColumn.HeaderText = "Purchase_Date";
            this.purchaseDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.purchaseDateDataGridViewTextBoxColumn.Name = "purchaseDateDataGridViewTextBoxColumn";
            this.purchaseDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // hDDSerialNUMDataGridViewTextBoxColumn
            // 
            this.hDDSerialNUMDataGridViewTextBoxColumn.DataPropertyName = "HDD_Serial_NUM";
            this.hDDSerialNUMDataGridViewTextBoxColumn.HeaderText = "HDD_Serial_NUM";
            this.hDDSerialNUMDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.hDDSerialNUMDataGridViewTextBoxColumn.Name = "hDDSerialNUMDataGridViewTextBoxColumn";
            this.hDDSerialNUMDataGridViewTextBoxColumn.Width = 150;
            // 
            // OS
            // 
            this.OS.DataPropertyName = "OS";
            this.OS.HeaderText = "OS";
            this.OS.MinimumWidth = 8;
            this.OS.Name = "OS";
            this.OS.Width = 150;
            // 
            // networkinterfaceNameDataGridViewTextBoxColumn
            // 
            this.networkinterfaceNameDataGridViewTextBoxColumn.DataPropertyName = "Network_interface_Name";
            this.networkinterfaceNameDataGridViewTextBoxColumn.HeaderText = "Network_interface_Name";
            this.networkinterfaceNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.networkinterfaceNameDataGridViewTextBoxColumn.Name = "networkinterfaceNameDataGridViewTextBoxColumn";
            this.networkinterfaceNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // networkinterfaceTypeDataGridViewTextBoxColumn
            // 
            this.networkinterfaceTypeDataGridViewTextBoxColumn.DataPropertyName = "Network_interfaceType";
            this.networkinterfaceTypeDataGridViewTextBoxColumn.HeaderText = "Network_interfaceType";
            this.networkinterfaceTypeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.networkinterfaceTypeDataGridViewTextBoxColumn.Name = "networkinterfaceTypeDataGridViewTextBoxColumn";
            this.networkinterfaceTypeDataGridViewTextBoxColumn.Width = 150;
            // 
            // networkIPVersionDataGridViewTextBoxColumn
            // 
            this.networkIPVersionDataGridViewTextBoxColumn.DataPropertyName = "Network_IP_Version";
            this.networkIPVersionDataGridViewTextBoxColumn.HeaderText = "Network_IP_Version";
            this.networkIPVersionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.networkIPVersionDataGridViewTextBoxColumn.Name = "networkIPVersionDataGridViewTextBoxColumn";
            this.networkIPVersionDataGridViewTextBoxColumn.Width = 150;
            // 
            // maintenanceNotesDataGridViewTextBoxColumn
            // 
            this.maintenanceNotesDataGridViewTextBoxColumn.DataPropertyName = "Maintenance_Notes";
            this.maintenanceNotesDataGridViewTextBoxColumn.HeaderText = "Maintenance_Notes";
            this.maintenanceNotesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.maintenanceNotesDataGridViewTextBoxColumn.Name = "maintenanceNotesDataGridViewTextBoxColumn";
            this.maintenanceNotesDataGridViewTextBoxColumn.Width = 150;
            // 
            // notesDataGridViewTextBoxColumn
            // 
            this.notesDataGridViewTextBoxColumn.DataPropertyName = "Notes";
            this.notesDataGridViewTextBoxColumn.HeaderText = "Notes";
            this.notesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.notesDataGridViewTextBoxColumn.Name = "notesDataGridViewTextBoxColumn";
            this.notesDataGridViewTextBoxColumn.Width = 150;
            // 
            // locationIDDataGridViewTextBoxColumn
            // 
            this.locationIDDataGridViewTextBoxColumn.DataPropertyName = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn.HeaderText = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.locationIDDataGridViewTextBoxColumn.Name = "locationIDDataGridViewTextBoxColumn";
            this.locationIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // iPAddressDataGridViewTextBoxColumn
            // 
            this.iPAddressDataGridViewTextBoxColumn.DataPropertyName = "IP_Address";
            this.iPAddressDataGridViewTextBoxColumn.HeaderText = "IP_Address";
            this.iPAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.iPAddressDataGridViewTextBoxColumn.Name = "iPAddressDataGridViewTextBoxColumn";
            this.iPAddressDataGridViewTextBoxColumn.Width = 150;
            // 
            // assetsBindingSource4
            // 
            this.assetsBindingSource4.DataMember = "Assets";
            this.assetsBindingSource4.DataSource = this.mssql1903299DataSet7;
            // 
            // mssql1903299DataSet7
            // 
            this.mssql1903299DataSet7.DataSetName = "mssql1903299DataSet7";
            this.mssql1903299DataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetsBindingSource3
            // 
            this.assetsBindingSource3.DataMember = "Assets";
            this.assetsBindingSource3.DataSource = this.mssql1903299DataSet5;
            // 
            // mssql1903299DataSet5
            // 
            this.mssql1903299DataSet5.DataSetName = "mssql1903299DataSet5";
            this.mssql1903299DataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetsBindingSource2
            // 
            this.assetsBindingSource2.DataMember = "Assets";
            this.assetsBindingSource2.DataSource = this.mssql1903299DataSet3;
            // 
            // mssql1903299DataSet3
            // 
            this.mssql1903299DataSet3.DataSetName = "mssql1903299DataSet3";
            this.mssql1903299DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetsBindingSource1
            // 
            this.assetsBindingSource1.DataMember = "Assets";
            this.assetsBindingSource1.DataSource = this.mssql1903299DataSet2BindingSource;
            // 
            // mssql1903299DataSet2BindingSource
            // 
            this.mssql1903299DataSet2BindingSource.DataSource = this.mssql1903299DataSet2;
            this.mssql1903299DataSet2BindingSource.Position = 0;
            // 
            // mssql1903299DataSet2
            // 
            this.mssql1903299DataSet2.DataSetName = "mssql1903299DataSet2";
            this.mssql1903299DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetsBindingSource
            // 
            this.assetsBindingSource.DataMember = "Assets";
            this.assetsBindingSource.DataSource = this.mssql1903299DataSet2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.Find_Asset);
            this.panel1.Controls.Add(this.SearchLocation);
            this.panel1.Controls.Add(this.SearchId);
            this.panel1.Controls.Add(this.AddAsset);
            this.panel1.Location = new System.Drawing.Point(415, 286);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(298, 189);
            this.panel1.TabIndex = 1;
            // 
            // Find_Asset
            // 
            this.Find_Asset.Location = new System.Drawing.Point(25, 135);
            this.Find_Asset.Multiline = true;
            this.Find_Asset.Name = "Find_Asset";
            this.Find_Asset.Size = new System.Drawing.Size(226, 46);
            this.Find_Asset.TabIndex = 6;
            this.Find_Asset.Text = "Enter the data you are trying to search by";
            this.Find_Asset.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SearchLocation
            // 
            this.SearchLocation.Location = new System.Drawing.Point(12, 94);
            this.SearchLocation.Name = "SearchLocation";
            this.SearchLocation.Size = new System.Drawing.Size(269, 35);
            this.SearchLocation.TabIndex = 2;
            this.SearchLocation.Text = "Search for Asset By Location";
            this.SearchLocation.UseVisualStyleBackColor = true;
            this.SearchLocation.Click += new System.EventHandler(this.SearchLocation_Click);
            // 
            // SearchId
            // 
            this.SearchId.Location = new System.Drawing.Point(36, 53);
            this.SearchId.Name = "SearchId";
            this.SearchId.Size = new System.Drawing.Size(203, 35);
            this.SearchId.TabIndex = 1;
            this.SearchId.Text = "Search for Asset By ID";
            this.SearchId.UseVisualStyleBackColor = true;
            this.SearchId.Click += new System.EventHandler(this.SearchId_Click);
            // 
            // AddAsset
            // 
            this.AddAsset.Location = new System.Drawing.Point(68, 12);
            this.AddAsset.Name = "AddAsset";
            this.AddAsset.Size = new System.Drawing.Size(146, 35);
            this.AddAsset.TabIndex = 0;
            this.AddAsset.Text = "Add New Asset";
            this.AddAsset.UseVisualStyleBackColor = true;
            this.AddAsset.Click += new System.EventHandler(this.AddAsset_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.Location = new System.Drawing.Point(777, 286);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 181);
            this.panel2.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Controls.Add(this.Update_Asset);
            this.panel3.Controls.Add(this.Reset_Table);
            this.panel3.Controls.Add(this.FindAsset);
            this.panel3.Location = new System.Drawing.Point(848, 286);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(298, 189);
            this.panel3.TabIndex = 2;
            // 
            // Update_Asset
            // 
            this.Update_Asset.Location = new System.Drawing.Point(74, 65);
            this.Update_Asset.Name = "Update_Asset";
            this.Update_Asset.Size = new System.Drawing.Size(176, 35);
            this.Update_Asset.TabIndex = 7;
            this.Update_Asset.Text = "Update Asset";
            this.Update_Asset.UseVisualStyleBackColor = true;
            this.Update_Asset.Click += new System.EventHandler(this.Update_Asset_Click);
            // 
            // Reset_Table
            // 
            this.Reset_Table.Location = new System.Drawing.Point(74, 106);
            this.Reset_Table.Name = "Reset_Table";
            this.Reset_Table.Size = new System.Drawing.Size(176, 35);
            this.Reset_Table.TabIndex = 6;
            this.Reset_Table.Text = "Reset Table";
            this.Reset_Table.UseVisualStyleBackColor = true;
            this.Reset_Table.Click += new System.EventHandler(this.Reset_Table_Click);
            // 
            // FindAsset
            // 
            this.FindAsset.Location = new System.Drawing.Point(74, 25);
            this.FindAsset.Name = "FindAsset";
            this.FindAsset.Size = new System.Drawing.Size(176, 35);
            this.FindAsset.TabIndex = 3;
            this.FindAsset.Text = "Find an Asset";
            this.FindAsset.UseVisualStyleBackColor = true;
            this.FindAsset.Click += new System.EventHandler(this.FindAsset_Click);
            // 
            // assetsTableAdapter
            // 
            this.assetsTableAdapter.ClearBeforeFill = true;
            // 
            // assetsTableAdapter1
            // 
            this.assetsTableAdapter1.ClearBeforeFill = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(1, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1160, 515);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DimGray;
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Controls.Add(this.panel4);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.Main_Assets);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1152, 482);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Assets";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel5.Location = new System.Drawing.Point(365, 286);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(10, 181);
            this.panel5.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel4.Controls.Add(this.Update_Location);
            this.panel4.Controls.Add(this.Delete_Location);
            this.panel4.Controls.Add(this.AddLocation);
            this.panel4.Location = new System.Drawing.Point(26, 286);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(298, 189);
            this.panel4.TabIndex = 8;
            // 
            // Update_Location
            // 
            this.Update_Location.Location = new System.Drawing.Point(60, 123);
            this.Update_Location.Name = "Update_Location";
            this.Update_Location.Size = new System.Drawing.Size(176, 35);
            this.Update_Location.TabIndex = 6;
            this.Update_Location.Text = "Update Branch";
            this.Update_Location.UseVisualStyleBackColor = true;
            this.Update_Location.Click += new System.EventHandler(this.Update_Location_Click);
            // 
            // Delete_Location
            // 
            this.Delete_Location.Location = new System.Drawing.Point(60, 73);
            this.Delete_Location.Name = "Delete_Location";
            this.Delete_Location.Size = new System.Drawing.Size(176, 35);
            this.Delete_Location.TabIndex = 5;
            this.Delete_Location.Text = "Delete Branch";
            this.Delete_Location.UseVisualStyleBackColor = true;
            this.Delete_Location.Click += new System.EventHandler(this.Delete_Location_Click);
            // 
            // AddLocation
            // 
            this.AddLocation.Location = new System.Drawing.Point(60, 21);
            this.AddLocation.Name = "AddLocation";
            this.AddLocation.Size = new System.Drawing.Size(176, 35);
            this.AddLocation.TabIndex = 4;
            this.AddLocation.Text = "Add New Branch ";
            this.AddLocation.UseVisualStyleBackColor = true;
            this.AddLocation.Click += new System.EventHandler(this.AddLocation_Click_1);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.DimGray;
            this.tabPage2.Controls.Add(this.Software_Relode);
            this.tabPage2.Controls.Add(this.Software_Save);
            this.tabPage2.Controls.Add(this.Software_manu);
            this.tabPage2.Controls.Add(this.Software_OS);
            this.tabPage2.Controls.Add(this.SoftwareGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1152, 482);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "SoftWare";
            // 
            // Software_Relode
            // 
            this.Software_Relode.Location = new System.Drawing.Point(984, 320);
            this.Software_Relode.Name = "Software_Relode";
            this.Software_Relode.Size = new System.Drawing.Size(137, 71);
            this.Software_Relode.TabIndex = 12;
            this.Software_Relode.Text = "Refresh table";
            this.Software_Relode.UseVisualStyleBackColor = true;
            this.Software_Relode.Click += new System.EventHandler(this.Software_Relode_Click);
            // 
            // Software_Save
            // 
            this.Software_Save.Location = new System.Drawing.Point(835, 320);
            this.Software_Save.Name = "Software_Save";
            this.Software_Save.Size = new System.Drawing.Size(137, 71);
            this.Software_Save.TabIndex = 11;
            this.Software_Save.Text = "Save";
            this.Software_Save.UseVisualStyleBackColor = true;
            this.Software_Save.Click += new System.EventHandler(this.Software_Save_Click);
            // 
            // Software_manu
            // 
            this.Software_manu.Location = new System.Drawing.Point(23, 368);
            this.Software_manu.Multiline = true;
            this.Software_manu.Name = "Software_manu";
            this.Software_manu.Size = new System.Drawing.Size(323, 46);
            this.Software_manu.TabIndex = 8;
            this.Software_manu.Text = "Enter the name of  the manufacture of the Operating System";
            this.Software_manu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Software_OS
            // 
            this.Software_OS.Location = new System.Drawing.Point(23, 300);
            this.Software_OS.Multiline = true;
            this.Software_OS.Name = "Software_OS";
            this.Software_OS.Size = new System.Drawing.Size(323, 46);
            this.Software_OS.TabIndex = 7;
            this.Software_OS.Text = "Enter the name of the new operating system as well as the version";
            this.Software_OS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SoftwareGridView
            // 
            this.SoftwareGridView.AutoGenerateColumns = false;
            this.SoftwareGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SoftwareGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sWIDDataGridViewTextBoxColumn,
            this.oSDataGridViewTextBoxColumn,
            this.manufacturerDataGridViewTextBoxColumn1});
            this.SoftwareGridView.DataSource = this.softwareBindingSource;
            this.SoftwareGridView.Location = new System.Drawing.Point(174, 17);
            this.SoftwareGridView.Name = "SoftwareGridView";
            this.SoftwareGridView.RowHeadersWidth = 62;
            this.SoftwareGridView.RowTemplate.Height = 28;
            this.SoftwareGridView.Size = new System.Drawing.Size(798, 239);
            this.SoftwareGridView.TabIndex = 0;
            this.SoftwareGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SoftwareGridView_CellContentClick_1);
            // 
            // sWIDDataGridViewTextBoxColumn
            // 
            this.sWIDDataGridViewTextBoxColumn.DataPropertyName = "SW_ID";
            this.sWIDDataGridViewTextBoxColumn.HeaderText = "SW_ID";
            this.sWIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.sWIDDataGridViewTextBoxColumn.Name = "sWIDDataGridViewTextBoxColumn";
            this.sWIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.sWIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // oSDataGridViewTextBoxColumn
            // 
            this.oSDataGridViewTextBoxColumn.DataPropertyName = "OS";
            this.oSDataGridViewTextBoxColumn.HeaderText = "OS";
            this.oSDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.oSDataGridViewTextBoxColumn.Name = "oSDataGridViewTextBoxColumn";
            this.oSDataGridViewTextBoxColumn.Width = 150;
            // 
            // manufacturerDataGridViewTextBoxColumn1
            // 
            this.manufacturerDataGridViewTextBoxColumn1.DataPropertyName = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn1.HeaderText = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.manufacturerDataGridViewTextBoxColumn1.Name = "manufacturerDataGridViewTextBoxColumn1";
            this.manufacturerDataGridViewTextBoxColumn1.Width = 150;
            // 
            // softwareBindingSource
            // 
            this.softwareBindingSource.DataMember = "Software";
            this.softwareBindingSource.DataSource = this.mssql1903299DataSet6;
            // 
            // mssql1903299DataSet6
            // 
            this.mssql1903299DataSet6.DataSetName = "mssql1903299DataSet6";
            this.mssql1903299DataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.DimGray;
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1152, 482);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Security";
            // 
            // assetsTableAdapter2
            // 
            this.assetsTableAdapter2.ClearBeforeFill = true;
            // 
            // softwareTableAdapter
            // 
            this.softwareTableAdapter.ClearBeforeFill = true;
            // 
            // assetsTableAdapter3
            // 
            this.assetsTableAdapter3.ClearBeforeFill = true;
            // 
            // mssql1903299DataSet10
            // 
            this.mssql1903299DataSet10.DataSetName = "mssql1903299DataSet10";
            this.mssql1903299DataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetsBindingSource5
            // 
            this.assetsBindingSource5.DataMember = "Assets";
            this.assetsBindingSource5.DataSource = this.mssql1903299DataSet10;
            // 
            // assetsTableAdapter4
            // 
            this.assetsTableAdapter4.ClearBeforeFill = true;
            // 
            // MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1164, 517);
            this.Controls.Add(this.tabControl1);
            this.Name = "MainPage";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.MainPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Main_Assets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SoftwareGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.softwareBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Main_Assets;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button SearchLocation;
        private System.Windows.Forms.Button SearchId;
        private System.Windows.Forms.Button AddAsset;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button FindAsset;
        private System.Windows.Forms.TextBox Find_Asset;
        private System.Windows.Forms.Button Reset_Table;
        private mssql1903299DataSet2 mssql1903299DataSet2;
        private System.Windows.Forms.BindingSource assetsBindingSource;
        private mssql1903299DataSet2TableAdapters.AssetsTableAdapter assetsTableAdapter;
        private System.Windows.Forms.BindingSource mssql1903299DataSet2BindingSource;
        private System.Windows.Forms.BindingSource assetsBindingSource1;
        private mssql1903299DataSet3 mssql1903299DataSet3;
        private System.Windows.Forms.BindingSource assetsBindingSource2;
        private mssql1903299DataSet3TableAdapters.AssetsTableAdapter assetsTableAdapter1;
        private System.Windows.Forms.Button Update_Asset;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private mssql1903299DataSet5 mssql1903299DataSet5;
        private System.Windows.Forms.BindingSource assetsBindingSource3;
        private mssql1903299DataSet5TableAdapters.AssetsTableAdapter assetsTableAdapter2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button Update_Location;
        private System.Windows.Forms.Button Delete_Location;
        private System.Windows.Forms.Button AddLocation;
        private System.Windows.Forms.DataGridView SoftwareGridView;
        private mssql1903299DataSet6 mssql1903299DataSet6;
        private System.Windows.Forms.BindingSource softwareBindingSource;
        private mssql1903299DataSet6TableAdapters.SoftwareTableAdapter softwareTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manufacturerDataGridViewTextBoxColumn1;
        private mssql1903299DataSet7 mssql1903299DataSet7;
        private System.Windows.Forms.BindingSource assetsBindingSource4;
        private mssql1903299DataSet7TableAdapters.AssetsTableAdapter assetsTableAdapter3;
        private System.Windows.Forms.TextBox Software_OS;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox Software_manu;
        private System.Windows.Forms.Button Software_Relode;
        private System.Windows.Forms.Button Software_Save;
        private System.Windows.Forms.DataGridViewTextBoxColumn assetIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diviceNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manufacturerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchaseDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hDDSerialNUMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn OS;
        private System.Windows.Forms.DataGridViewTextBoxColumn networkinterfaceNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn networkinterfaceTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn networkIPVersionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maintenanceNotesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn notesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iPAddressDataGridViewTextBoxColumn;
        private mssql1903299DataSet10 mssql1903299DataSet10;
        private System.Windows.Forms.BindingSource assetsBindingSource5;
        private mssql1903299DataSet10TableAdapters.AssetsTableAdapter assetsTableAdapter4;
    }
}