﻿
namespace SGlen_Prototype_1
{
    partial class Search_Asset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Search_Location = new System.Windows.Forms.DataGridView();
            this.locationIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.placeNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.postCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dLocationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet4 = new SGlen_Prototype_1.mssql1903299DataSet4();
            this.mssql1903299DataSet4BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dLocationTableAdapter = new SGlen_Prototype_1.mssql1903299DataSet4TableAdapters.DLocationTableAdapter();
            this.Search_Location_Spes = new System.Windows.Forms.DataGridView();
            this.IP_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Department = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Room_Num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Desk_Num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Server_Section = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iPAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.locationIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departmentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roomNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deskNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serverSectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.locationSpesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet2 = new SGlen_Prototype_1.mssql1903299DataSet2();
            this.location_SpesTableAdapter = new SGlen_Prototype_1.mssql1903299DataSet2TableAdapters.Location_SpesTableAdapter();
            this.assetsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.assetsTableAdapter = new SGlen_Prototype_1.mssql1903299DataSet2TableAdapters.AssetsTableAdapter();
            this.Search_Reset = new System.Windows.Forms.Button();
            this.Search_Back = new System.Windows.Forms.Button();
            this.Location_Update = new System.Windows.Forms.Button();
            this.loc_Room_Num = new System.Windows.Forms.TextBox();
            this.Loc_IP = new System.Windows.Forms.TextBox();
            this.Loc_Dep = new System.Windows.Forms.TextBox();
            this.Loc_Serv = new System.Windows.Forms.TextBox();
            this.Loc_Desk_Num = new System.Windows.Forms.TextBox();
            this.Location_Search = new System.Windows.Forms.Button();
            this.Loc_Building = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Search_Location)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet4BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Search_Location_Spes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.locationSpesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // Search_Location
            // 
            this.Search_Location.AllowUserToAddRows = false;
            this.Search_Location.AutoGenerateColumns = false;
            this.Search_Location.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Search_Location.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.locationIDDataGridViewTextBoxColumn,
            this.placeNameDataGridViewTextBoxColumn,
            this.dAddressDataGridViewTextBoxColumn,
            this.postCodeDataGridViewTextBoxColumn,
            this.phoneNumDataGridViewTextBoxColumn});
            this.Search_Location.DataSource = this.dLocationBindingSource;
            this.Search_Location.Location = new System.Drawing.Point(12, 12);
            this.Search_Location.Name = "Search_Location";
            this.Search_Location.RowHeadersWidth = 62;
            this.Search_Location.RowTemplate.Height = 28;
            this.Search_Location.Size = new System.Drawing.Size(367, 296);
            this.Search_Location.TabIndex = 0;
            // 
            // locationIDDataGridViewTextBoxColumn
            // 
            this.locationIDDataGridViewTextBoxColumn.DataPropertyName = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn.HeaderText = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.locationIDDataGridViewTextBoxColumn.Name = "locationIDDataGridViewTextBoxColumn";
            this.locationIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.locationIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // placeNameDataGridViewTextBoxColumn
            // 
            this.placeNameDataGridViewTextBoxColumn.DataPropertyName = "Place_Name";
            this.placeNameDataGridViewTextBoxColumn.HeaderText = "Place_Name";
            this.placeNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.placeNameDataGridViewTextBoxColumn.Name = "placeNameDataGridViewTextBoxColumn";
            this.placeNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // dAddressDataGridViewTextBoxColumn
            // 
            this.dAddressDataGridViewTextBoxColumn.DataPropertyName = "DAddress";
            this.dAddressDataGridViewTextBoxColumn.HeaderText = "DAddress";
            this.dAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dAddressDataGridViewTextBoxColumn.Name = "dAddressDataGridViewTextBoxColumn";
            this.dAddressDataGridViewTextBoxColumn.Width = 150;
            // 
            // postCodeDataGridViewTextBoxColumn
            // 
            this.postCodeDataGridViewTextBoxColumn.DataPropertyName = "Post_Code";
            this.postCodeDataGridViewTextBoxColumn.HeaderText = "Post_Code";
            this.postCodeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.postCodeDataGridViewTextBoxColumn.Name = "postCodeDataGridViewTextBoxColumn";
            this.postCodeDataGridViewTextBoxColumn.Width = 150;
            // 
            // phoneNumDataGridViewTextBoxColumn
            // 
            this.phoneNumDataGridViewTextBoxColumn.DataPropertyName = "Phone_Num";
            this.phoneNumDataGridViewTextBoxColumn.HeaderText = "Phone_Num";
            this.phoneNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.phoneNumDataGridViewTextBoxColumn.Name = "phoneNumDataGridViewTextBoxColumn";
            this.phoneNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // dLocationBindingSource
            // 
            this.dLocationBindingSource.DataMember = "DLocation";
            this.dLocationBindingSource.DataSource = this.mssql1903299DataSet4;
            // 
            // mssql1903299DataSet4
            // 
            this.mssql1903299DataSet4.DataSetName = "mssql1903299DataSet4";
            this.mssql1903299DataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mssql1903299DataSet4BindingSource
            // 
            this.mssql1903299DataSet4BindingSource.DataSource = this.mssql1903299DataSet4;
            this.mssql1903299DataSet4BindingSource.Position = 0;
            // 
            // dLocationTableAdapter
            // 
            this.dLocationTableAdapter.ClearBeforeFill = true;
            // 
            // Search_Location_Spes
            // 
            this.Search_Location_Spes.AllowUserToAddRows = false;
            this.Search_Location_Spes.AutoGenerateColumns = false;
            this.Search_Location_Spes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Search_Location_Spes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IP_Address,
            this.Department,
            this.Room_Num,
            this.Desk_Num,
            this.Server_Section,
            this.iPAddressDataGridViewTextBoxColumn,
            this.locationIDDataGridViewTextBoxColumn1,
            this.departmentDataGridViewTextBoxColumn,
            this.roomNumDataGridViewTextBoxColumn,
            this.deskNumDataGridViewTextBoxColumn,
            this.serverSectionDataGridViewTextBoxColumn});
            this.Search_Location_Spes.DataSource = this.locationSpesBindingSource;
            this.Search_Location_Spes.Location = new System.Drawing.Point(399, 12);
            this.Search_Location_Spes.Name = "Search_Location_Spes";
            this.Search_Location_Spes.RowHeadersWidth = 62;
            this.Search_Location_Spes.RowTemplate.Height = 28;
            this.Search_Location_Spes.Size = new System.Drawing.Size(704, 296);
            this.Search_Location_Spes.TabIndex = 1;
            this.Search_Location_Spes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Search_Location_Spes_CellContentClick);
            // 
            // IP_Address
            // 
            this.IP_Address.DataPropertyName = "IP_Address";
            this.IP_Address.HeaderText = "IP_Address";
            this.IP_Address.MinimumWidth = 8;
            this.IP_Address.Name = "IP_Address";
            this.IP_Address.Width = 150;
            // 
            // Department
            // 
            this.Department.DataPropertyName = "Department";
            this.Department.HeaderText = "Department";
            this.Department.MinimumWidth = 8;
            this.Department.Name = "Department";
            this.Department.Width = 150;
            // 
            // Room_Num
            // 
            this.Room_Num.DataPropertyName = "Room_Num";
            this.Room_Num.HeaderText = "Room_Num";
            this.Room_Num.MinimumWidth = 8;
            this.Room_Num.Name = "Room_Num";
            this.Room_Num.Width = 150;
            // 
            // Desk_Num
            // 
            this.Desk_Num.DataPropertyName = "Desk_Num";
            this.Desk_Num.HeaderText = "Desk_Num";
            this.Desk_Num.MinimumWidth = 8;
            this.Desk_Num.Name = "Desk_Num";
            this.Desk_Num.Width = 150;
            // 
            // Server_Section
            // 
            this.Server_Section.DataPropertyName = "Server_Section";
            this.Server_Section.HeaderText = "Server_Section";
            this.Server_Section.MinimumWidth = 8;
            this.Server_Section.Name = "Server_Section";
            this.Server_Section.Width = 150;
            // 
            // iPAddressDataGridViewTextBoxColumn
            // 
            this.iPAddressDataGridViewTextBoxColumn.DataPropertyName = "IP_Address";
            this.iPAddressDataGridViewTextBoxColumn.HeaderText = "IP_Address";
            this.iPAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.iPAddressDataGridViewTextBoxColumn.Name = "iPAddressDataGridViewTextBoxColumn";
            this.iPAddressDataGridViewTextBoxColumn.Width = 150;
            // 
            // locationIDDataGridViewTextBoxColumn1
            // 
            this.locationIDDataGridViewTextBoxColumn1.DataPropertyName = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn1.HeaderText = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.locationIDDataGridViewTextBoxColumn1.Name = "locationIDDataGridViewTextBoxColumn1";
            this.locationIDDataGridViewTextBoxColumn1.Width = 150;
            // 
            // departmentDataGridViewTextBoxColumn
            // 
            this.departmentDataGridViewTextBoxColumn.DataPropertyName = "Department";
            this.departmentDataGridViewTextBoxColumn.HeaderText = "Department";
            this.departmentDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.departmentDataGridViewTextBoxColumn.Name = "departmentDataGridViewTextBoxColumn";
            this.departmentDataGridViewTextBoxColumn.Width = 150;
            // 
            // roomNumDataGridViewTextBoxColumn
            // 
            this.roomNumDataGridViewTextBoxColumn.DataPropertyName = "Room_Num";
            this.roomNumDataGridViewTextBoxColumn.HeaderText = "Room_Num";
            this.roomNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.roomNumDataGridViewTextBoxColumn.Name = "roomNumDataGridViewTextBoxColumn";
            this.roomNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // deskNumDataGridViewTextBoxColumn
            // 
            this.deskNumDataGridViewTextBoxColumn.DataPropertyName = "Desk_Num";
            this.deskNumDataGridViewTextBoxColumn.HeaderText = "Desk_Num";
            this.deskNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.deskNumDataGridViewTextBoxColumn.Name = "deskNumDataGridViewTextBoxColumn";
            this.deskNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // serverSectionDataGridViewTextBoxColumn
            // 
            this.serverSectionDataGridViewTextBoxColumn.DataPropertyName = "Server_Section";
            this.serverSectionDataGridViewTextBoxColumn.HeaderText = "Server_Section";
            this.serverSectionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.serverSectionDataGridViewTextBoxColumn.Name = "serverSectionDataGridViewTextBoxColumn";
            this.serverSectionDataGridViewTextBoxColumn.Width = 150;
            // 
            // locationSpesBindingSource
            // 
            this.locationSpesBindingSource.DataMember = "Location_Spes";
            this.locationSpesBindingSource.DataSource = this.mssql1903299DataSet2;
            // 
            // mssql1903299DataSet2
            // 
            this.mssql1903299DataSet2.DataSetName = "mssql1903299DataSet2";
            this.mssql1903299DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // location_SpesTableAdapter
            // 
            this.location_SpesTableAdapter.ClearBeforeFill = true;
            // 
            // assetsBindingSource
            // 
            this.assetsBindingSource.DataMember = "Assets";
            this.assetsBindingSource.DataSource = this.mssql1903299DataSet2;
            // 
            // assetsTableAdapter
            // 
            this.assetsTableAdapter.ClearBeforeFill = true;
            // 
            // Search_Reset
            // 
            this.Search_Reset.Location = new System.Drawing.Point(1016, 427);
            this.Search_Reset.Name = "Search_Reset";
            this.Search_Reset.Size = new System.Drawing.Size(168, 68);
            this.Search_Reset.TabIndex = 3;
            this.Search_Reset.Text = "Reload Tables";
            this.Search_Reset.UseVisualStyleBackColor = true;
            this.Search_Reset.Click += new System.EventHandler(this.Search_Reset_Click);
            // 
            // Search_Back
            // 
            this.Search_Back.Location = new System.Drawing.Point(1016, 342);
            this.Search_Back.Name = "Search_Back";
            this.Search_Back.Size = new System.Drawing.Size(168, 68);
            this.Search_Back.TabIndex = 4;
            this.Search_Back.Text = "Back";
            this.Search_Back.UseVisualStyleBackColor = true;
            this.Search_Back.Click += new System.EventHandler(this.Search_Back_Click);
            // 
            // Location_Update
            // 
            this.Location_Update.Location = new System.Drawing.Point(832, 342);
            this.Location_Update.Name = "Location_Update";
            this.Location_Update.Size = new System.Drawing.Size(168, 68);
            this.Location_Update.TabIndex = 5;
            this.Location_Update.Text = "Update";
            this.Location_Update.UseVisualStyleBackColor = true;
            this.Location_Update.Click += new System.EventHandler(this.Location_Update_Click);
            // 
            // loc_Room_Num
            // 
            this.loc_Room_Num.Location = new System.Drawing.Point(23, 331);
            this.loc_Room_Num.Name = "loc_Room_Num";
            this.loc_Room_Num.Size = new System.Drawing.Size(356, 26);
            this.loc_Room_Num.TabIndex = 7;
            this.loc_Room_Num.Text = "Enter the new room number";
            this.loc_Room_Num.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Loc_IP
            // 
            this.Loc_IP.Location = new System.Drawing.Point(399, 331);
            this.Loc_IP.Name = "Loc_IP";
            this.Loc_IP.Size = new System.Drawing.Size(417, 26);
            this.Loc_IP.TabIndex = 8;
            this.Loc_IP.Text = "Enter the IP Address of the Asset you are serching for";
            this.Loc_IP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Loc_Dep
            // 
            this.Loc_Dep.Location = new System.Drawing.Point(23, 427);
            this.Loc_Dep.Name = "Loc_Dep";
            this.Loc_Dep.Size = new System.Drawing.Size(356, 26);
            this.Loc_Dep.TabIndex = 9;
            this.Loc_Dep.Text = "Enter the new department";
            this.Loc_Dep.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Loc_Serv
            // 
            this.Loc_Serv.Location = new System.Drawing.Point(23, 395);
            this.Loc_Serv.Name = "Loc_Serv";
            this.Loc_Serv.Size = new System.Drawing.Size(356, 26);
            this.Loc_Serv.TabIndex = 10;
            this.Loc_Serv.Text = "Enter the new server section";
            this.Loc_Serv.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Loc_Desk_Num
            // 
            this.Loc_Desk_Num.Location = new System.Drawing.Point(23, 363);
            this.Loc_Desk_Num.Name = "Loc_Desk_Num";
            this.Loc_Desk_Num.Size = new System.Drawing.Size(356, 26);
            this.Loc_Desk_Num.TabIndex = 11;
            this.Loc_Desk_Num.Text = "Enter the new desk number";
            this.Loc_Desk_Num.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Location_Search
            // 
            this.Location_Search.Location = new System.Drawing.Point(832, 427);
            this.Location_Search.Name = "Location_Search";
            this.Location_Search.Size = new System.Drawing.Size(168, 68);
            this.Location_Search.TabIndex = 12;
            this.Location_Search.Text = "search";
            this.Location_Search.UseVisualStyleBackColor = true;
            this.Location_Search.Click += new System.EventHandler(this.Location_Search_Click);
            // 
            // Loc_Building
            // 
            this.Loc_Building.Location = new System.Drawing.Point(399, 363);
            this.Loc_Building.Name = "Loc_Building";
            this.Loc_Building.Size = new System.Drawing.Size(417, 26);
            this.Loc_Building.TabIndex = 13;
            this.Loc_Building.Text = "Enter the building ID of the Building you are searching for";
            this.Loc_Building.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Search_Asset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1196, 521);
            this.Controls.Add(this.Loc_Building);
            this.Controls.Add(this.Location_Search);
            this.Controls.Add(this.Loc_Desk_Num);
            this.Controls.Add(this.Loc_Serv);
            this.Controls.Add(this.Loc_Dep);
            this.Controls.Add(this.Loc_IP);
            this.Controls.Add(this.loc_Room_Num);
            this.Controls.Add(this.Location_Update);
            this.Controls.Add(this.Search_Back);
            this.Controls.Add(this.Search_Reset);
            this.Controls.Add(this.Search_Location_Spes);
            this.Controls.Add(this.Search_Location);
            this.Name = "Search_Asset";
            this.Text = "Asset Search";
            this.Load += new System.EventHandler(this.Search_Asset_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Search_Location)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet4BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Search_Location_Spes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.locationSpesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Search_Location;
        private System.Windows.Forms.BindingSource mssql1903299DataSet4BindingSource;
        private mssql1903299DataSet4 mssql1903299DataSet4;
        private System.Windows.Forms.BindingSource dLocationBindingSource;
        private mssql1903299DataSet4TableAdapters.DLocationTableAdapter dLocationTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn placeNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn postCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView Search_Location_Spes;
        private mssql1903299DataSet2 mssql1903299DataSet2;
        private System.Windows.Forms.BindingSource locationSpesBindingSource;
        private mssql1903299DataSet2TableAdapters.Location_SpesTableAdapter location_SpesTableAdapter;
        private System.Windows.Forms.BindingSource assetsBindingSource;
        private mssql1903299DataSet2TableAdapters.AssetsTableAdapter assetsTableAdapter;
        private System.Windows.Forms.Button Search_Reset;
        private System.Windows.Forms.Button Search_Back;
        private System.Windows.Forms.DataGridViewTextBoxColumn IP_Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn Department;
        private System.Windows.Forms.DataGridViewTextBoxColumn Room_Num;
        private System.Windows.Forms.DataGridViewTextBoxColumn Desk_Num;
        private System.Windows.Forms.DataGridViewTextBoxColumn Server_Section;
        private System.Windows.Forms.Button Location_Update;
        private System.Windows.Forms.TextBox loc_Room_Num;
        private System.Windows.Forms.TextBox Loc_IP;
        private System.Windows.Forms.TextBox Loc_Dep;
        private System.Windows.Forms.TextBox Loc_Serv;
        private System.Windows.Forms.TextBox Loc_Desk_Num;
        private System.Windows.Forms.Button Location_Search;
        private System.Windows.Forms.TextBox Loc_Building;
        private System.Windows.Forms.DataGridViewTextBoxColumn iPAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn departmentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roomNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deskNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serverSectionDataGridViewTextBoxColumn;
    }
}