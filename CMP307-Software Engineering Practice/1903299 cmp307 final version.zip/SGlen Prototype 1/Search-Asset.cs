﻿using System;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;

namespace SGlen_Prototype_1
{
    public partial class Search_Asset : Form
    {
        public Search_Asset()
        {
            InitializeComponent();
        }

        readonly mssql1903299Entities6 db = new mssql1903299Entities6();
        Asset asset = new Asset();
        DLocation locate = new DLocation();
        Location_Spes locate_Spes = new Location_Spes();
        Search GB = new Search();
       string EmpId = "";

        private void Search_Asset_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mssql1903299DataSet2.Location_Spes' table. You can move, or remove it, as needed.
            this.location_SpesTableAdapter.Fill(this.mssql1903299DataSet2.Location_Spes);
            // TODO: This line of code loads data into the 'mssql1903299DataSet4.DLocation' table. You can move, or remove it, as needed.
            this.dLocationTableAdapter.Fill(this.mssql1903299DataSet4.DLocation);

            Loc_IP.Text = MainPage.IPADD;
            Loc_Building.Text = MainPage.LocID.ToString();


        }

        public void ClearData()
        {
            loc_Room_Num.Text = Loc_Desk_Num.Text = Loc_Serv.Text = Loc_Dep.Text = string.Empty;
            EmpId = "";
        }

        public void SetDataInGridView()
        {
            Search_Location.AutoGenerateColumns = false;
            Search_Location.DataSource = db.DLocations.ToList<DLocation>();
            Search_Location_Spes.AutoGenerateColumns = false;
            Search_Location_Spes.DataSource = db.Location_Spes.ToList<Location_Spes>();
        }

        private void Search_Back_Click(object sender, EventArgs e)
        {
            var m = new MainPage();// navigation back
            m.Show();
            this.Hide();
        }

        private void Search_Reset_Click(object sender, EventArgs e)
        {
            Search_Location.AutoGenerateColumns = false;
            Search_Location.DataSource = db.DLocations.ToList<DLocation>();
            Search_Location_Spes.AutoGenerateColumns = false;
            Search_Location_Spes.DataSource = db.Location_Spes.ToList<Location_Spes>();
        }

        private void Location_Update_Click(object sender, EventArgs e)
        {
            bool desk_check= true; // used to check if both desk and server sections are left untouched 
            bool serv_check = true;

            try { 
            if (string.IsNullOrEmpty(Loc_Desk_Num.Text) == true) //checks text boxes for new information
            {
                    Loc_Desk_Num.Text = "";
                    desk_check = false;
                }
            if (Loc_Desk_Num.Text == "Enter the new desk number")
            {
                Loc_Desk_Num.Text = "";
                desk_check = false;
            }

                if (string.IsNullOrEmpty(Loc_Serv.Text) == true) //checks text boxes for new information
                {
                    Loc_Serv.Text = "";
                    serv_check = false;
                }
                if (Loc_Serv.Text == "Enter the new server section")
                {
                    Loc_Serv.Text = "";
                    serv_check = false;
                }
            
            if (string.IsNullOrEmpty(loc_Room_Num.Text) == true) //checks text boxes for new information
            {
                MessageBox.Show("Please enter the new room number");
                loc_Room_Num.Text = "Enter the new room number";
                return;
            }
            if (loc_Room_Num.Text == "Enter the new room number")
            {
                MessageBox.Show("Please enter the new room number");
                loc_Room_Num.Text = "Enter the new room number";
                return;
            }
            if (string.IsNullOrEmpty(Loc_Dep.Text) == true) //checks text boxes for new information
            {
                MessageBox.Show("Please enter the new department");
                Loc_Dep.Text = "Enter the new department";
                return;
            }
            if (Loc_Dep.Text == "Enter the new department")
            {
                MessageBox.Show("Please enter the new department");
                Loc_Dep.Text = "Enter the new department";
                return;
            }


             if((desk_check=false) && (serv_check = false))
             {
                    MessageBox.Show("Please enter a Desk Number or a Server section");
                    return;
             }


            if ((string.IsNullOrEmpty(Loc_Serv.Text) == false) && (string.IsNullOrEmpty(Loc_Desk_Num.Text)==false))
            {
                 MessageBox.Show("Please only enter a Desk Number or a Server section");
                 return;
            }



            locate_Spes.Room_Num = Convert.ToInt32(loc_Room_Num.Text.Trim());
            locate_Spes.Server_Section = Loc_Serv.Text.Trim();
            locate_Spes.Desk_Num = Convert.ToInt32(Loc_Desk_Num.Text.Trim());
            locate_Spes.Department = Loc_Dep.Text.Trim();
            db.Entry(locate_Spes).State = EntityState.Modified;

            db.SaveChanges();
            ClearData();
            SetDataInGridView();
            MessageBox.Show("Record Save Successfully");

            Loc_Dep.Text = "Enter the new department";
            loc_Room_Num.Text = "Enter the new room number";
            Loc_Serv.Text = "Enter the new server section";
            Loc_Desk_Num.Text = "Enter the new desk number";


        }
            catch (Exception x)
            {
                MessageBox.Show("You have entered invalid data make sure to check for correct formatting.");

            }

        }

        private void Search_Location_Spes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Search_Location_Spes.CurrentCell.RowIndex != -1)
            {
                EmpId = (string)Search_Location_Spes.CurrentRow.Cells[0].Value;
                locate_Spes = db.Location_Spes.Where(x => x.IP_Address == EmpId).FirstOrDefault();
                loc_Room_Num.Text = locate_Spes.Room_Num.ToString();
                Loc_Serv.Text = locate_Spes.Server_Section;
                Loc_Desk_Num.Text = locate_Spes.Desk_Num.ToString();
                Loc_Dep.Text = locate_Spes.Department;
            }
        }

        private void Location_Search_Click(object sender, EventArgs e)
        {
            
            

            int search1 = Convert.ToInt32(Loc_Building.Text.Trim());
            string search2 = Loc_IP.Text.Trim();
            bool exists = GB.Location_Test(search1);// test to see if location exists
            bool exists2 = GB.IP_Test(search2);// test to see if location exists
            if (exists == false || exists == false)
            {
                 return;
            }

            Search_Location_Spes.AutoGenerateColumns = false;
            Search_Location_Spes.DataSource = (from p in db.Location_Spes
                                      where p.IP_Address == search2
                                      select p).ToList();

            Search_Location.AutoGenerateColumns = false;
            Search_Location.DataSource = (from p in db.DLocations
                                               where p.Location_ID == search1
                                               select p).ToList();
        }
    }
}
