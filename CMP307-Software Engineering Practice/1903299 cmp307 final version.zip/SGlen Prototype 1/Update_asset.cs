﻿using System;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;

namespace SGlen_Prototype_1
{
    public partial class Update_asset : Form
    {
        public Update_asset()
        {
            InitializeComponent();
        }

        int EmpId = 0;
        readonly mssql1903299Entities6 db = new mssql1903299Entities6();
        Asset asset = new Asset();
        Location_Spes loc = new Location_Spes();
        Search GB = new Search();

        public void ClearData()
        {
            Update_MNote.Text = Update_Notes.Text =  Update_PD.Text =  string.Empty;
            Update_Delete.Enabled = false;
            Update_Save.Text = "Save";
            EmpId = 0;
        }

        public void SetDataInGridView()
        {
            Update_Asset_View.AutoGenerateColumns = false;
            Update_Asset_View.DataSource = db.Assets.ToList<Asset>();
        }

        private void Update_asset_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mssql1903299DataSet11.Assets' table. You can move, or remove it, as needed.
            this.assetsTableAdapter4.Fill(this.mssql1903299DataSet11.Assets);
            // TODO: This line of code loads data into the 'mssql1903299DataSet9.Assets' table. You can move, or remove it, as needed.
            this.assetsTableAdapter3.Fill(this.mssql1903299DataSet9.Assets);
            // TODO: This line of code loads data into the 'mssql1903299DataSet8.Assets' table. You can move, or remove it, as needed.
            //this.assetsTableAdapter2.Fill(this.mssql1903299DataSet8.Assets);
            // TODO: This line of code loads data into the 'mssql1903299DataSet3.Assets' table. You can move, or remove it, as needed.
            //this.assetsTableAdapter1.Fill(this.mssql1903299DataSet3.Assets);

        }

        private void Update_Back_Click(object sender, EventArgs e)
        {
            var m = new MainPage();// navigation back
            m.Show();
            this.Hide();
        }

        private void Update_Reset_Click(object sender, EventArgs e)
        {
            Update_Asset_View.AutoGenerateColumns = false;
            Update_Asset_View.DataSource = db.Assets.ToList<Asset>();
        }

        private void Update_Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(Update_MNote.Text) == true) //checks text boxes for new information
            {
                Update_MNote.Text = "";
            }
            if (Update_MNote.Text == "Enter the Updated Manitanace notes")
            {
                Update_MNote.Text = "";
            }
            if (string.IsNullOrEmpty(Update_Notes.Text) == true) //checks text boxes for new information
            {
                Update_Notes.Text = "";
            }
            if (Update_Notes.Text == "Enter the Updated general notes")
            {
                Update_Notes.Text = "";
                return;
            }

            if (string.IsNullOrEmpty(Update_PD.Text) == true) //checks text boxes for new information
            {
                Update_PD.Text = "";
            }
            if (Update_PD.Text == "Enter the Updated Purchace Date")
            {
                Update_PD.Text = "";
            }
            asset.Maintenance_Notes = Update_MNote.Text.Trim();
            asset.Notes = Update_Notes.Text.Trim();
            asset.Purchase_Date = Update_PD.Text.Trim();
            db.Entry(asset).State = EntityState.Modified;
            db.SaveChanges();
            ClearData();
            SetDataInGridView();
            MessageBox.Show("Record Save Successfully");

            Update_MNote.Text = "Enter the Updated Manitanace notes";
            Update_Notes.Text = "Enter the Updated general notes";
            Update_PD.Text = "Enter the Updated Purchace Date";
        }
            catch (Exception x)
            {
                MessageBox.Show("You have entered invalid data make sure to check for correct formatting.");

            }
        }

        private void Update_Asset_View_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Update_Asset_View.CurrentCell.RowIndex != -1)
            {
                EmpId = Convert.ToInt32(Update_Asset_View.CurrentRow.Cells[0].Value);
                asset = db.Assets.Where(x => x.Asset_ID == EmpId).FirstOrDefault();
                Update_MNote.Text = asset.Maintenance_Notes;
                Update_Notes.Text = asset.Notes;
                Update_PD.Text = asset.Purchase_Date;
      
            }
            Update_Save.Text = "Update";
            Update_Delete.Enabled = true;
        }

        private void Update_Delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this record ?", "Delete ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                db.Assets.Remove(asset);
                string ip = GB.Find_IP(EmpId);
                loc = db.Location_Spes.Find(ip);
                db.Location_Spes.Remove(loc);
                db.SaveChanges();
                ClearData();
                SetDataInGridView();
                MessageBox.Show("Record Deleted Successfully");
            }
        }
    }
}
