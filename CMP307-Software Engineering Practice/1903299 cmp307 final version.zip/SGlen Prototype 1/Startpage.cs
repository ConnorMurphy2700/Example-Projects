﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SGlen_Prototype_1
{
    public partial class Startpage : Form
    {
        public Startpage()
        {
            InitializeComponent();
        }

        Employ GB = new Employ();

        private void Startpage_Load(object sender, EventArgs e)
        {

        }

        private void Submit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Employee_UserName.Text) == true)
            {
                MessageBox.Show("Please enter your Employee ID");
                Employee_UserName.Text = "Enter Your Employee ID";
                return;
            }
            if (Employee_UserName.Text == "Enter Your Employee ID")
            {
                MessageBox.Show("Please enter your Employee ID");
                Employee_UserName.Text = "Enter Your Employee ID";
                return;
            }
            if (string.IsNullOrEmpty(Empolyee_Pass.Text) == true)
            {
                MessageBox.Show("Please enter your password");
                Empolyee_Pass.Text = "sgwesdgsd";
                return;
            }
            if (Empolyee_Pass.Text == "sgwesdgsd")
            {
                MessageBox.Show("Please enter your  password");
                Empolyee_Pass.Text = "sgwesdgsd";
                return;
            }
            int Employ_Uname;
            Employ_Uname = Convert.ToInt32(Employee_UserName.Text);
            string Employ_Pass;
            Employ_Pass = Empolyee_Pass.Text;

            bool test = GB.Employ_Test(Employ_Uname);
            if(test == false) { return; }

            string include = GB.GetHash(Employ_Uname);

            if (BCrypt.Net.BCrypt.Verify(Employ_Pass, include))
            {
                DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("incorrect Login entered");
            }
            Empolyee_Pass.Text = "sgwesdgsd";
            Employee_UserName.Text = "Enter Your Employee ID";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                Empolyee_Pass.PasswordChar = '\0';
            }

            if (checkBox1.Checked == false)
            {
                Empolyee_Pass.PasswordChar = '*';
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
