﻿
namespace SGlen_Prototype_1
{
    partial class Startpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_Login = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Submit = new System.Windows.Forms.Button();
            this.Empolyee_Pass = new System.Windows.Forms.TextBox();
            this.Employee_UserName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.Exit = new System.Windows.Forms.Button();
            this.panel_Login.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Login
            // 
            this.panel_Login.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel_Login.Controls.Add(this.panel1);
            this.panel_Login.Controls.Add(this.label1);
            this.panel_Login.Location = new System.Drawing.Point(255, 48);
            this.panel_Login.Name = "panel_Login";
            this.panel_Login.Size = new System.Drawing.Size(268, 376);
            this.panel_Login.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.Controls.Add(this.Exit);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.Submit);
            this.panel1.Controls.Add(this.Empolyee_Pass);
            this.panel1.Controls.Add(this.Employee_UserName);
            this.panel1.Location = new System.Drawing.Point(19, 61);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(229, 276);
            this.panel1.TabIndex = 1;
            // 
            // Submit
            // 
            this.Submit.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Submit.Location = new System.Drawing.Point(51, 143);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(134, 55);
            this.Submit.TabIndex = 2;
            this.Submit.Text = "Submit";
            this.Submit.UseVisualStyleBackColor = false;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // Empolyee_Pass
            // 
            this.Empolyee_Pass.Location = new System.Drawing.Point(16, 65);
            this.Empolyee_Pass.Name = "Empolyee_Pass";
            this.Empolyee_Pass.PasswordChar = '*';
            this.Empolyee_Pass.Size = new System.Drawing.Size(194, 26);
            this.Empolyee_Pass.TabIndex = 1;
            this.Empolyee_Pass.Text = "sgwesdgsd";
            this.Empolyee_Pass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Employee_UserName
            // 
            this.Employee_UserName.Location = new System.Drawing.Point(16, 22);
            this.Employee_UserName.Name = "Employee_UserName";
            this.Employee_UserName.Size = new System.Drawing.Size(194, 26);
            this.Employee_UserName.TabIndex = 0;
            this.Employee_UserName.Text = "Enter Your Employee ID";
            this.Employee_UserName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(103, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "LOGIN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Show Password";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(176, 110);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(22, 21);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Exit.Location = new System.Drawing.Point(51, 204);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(134, 55);
            this.Exit.TabIndex = 5;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Startpage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel_Login);
            this.Name = "Startpage";
            this.Text = "Startpage";
            this.Load += new System.EventHandler(this.Startpage_Load);
            this.panel_Login.ResumeLayout(false);
            this.panel_Login.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Login;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.TextBox Empolyee_Pass;
        private System.Windows.Forms.TextBox Employee_UserName;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Exit;
    }
}