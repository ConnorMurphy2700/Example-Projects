﻿
namespace SGlen_Prototype_1
{
    partial class Update_asset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Update_Asset_View = new System.Windows.Forms.DataGridView();
            this.assetIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diviceNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manufacturerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchaseDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hDDSerialNUMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.networkinterfaceNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.networkinterfaceTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.networkIPVersionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maintenanceNotesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.notesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.locationIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iPAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assetsBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet9 = new SGlen_Prototype_1.mssql1903299DataSet9();
            this.assetsBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet8 = new SGlen_Prototype_1.mssql1903299DataSet8();
            this.assetsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet3 = new SGlen_Prototype_1.mssql1903299DataSet3();
            this.assetsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet2 = new SGlen_Prototype_1.mssql1903299DataSet2();
            this.assetsTableAdapter = new SGlen_Prototype_1.mssql1903299DataSet2TableAdapters.AssetsTableAdapter();
            this.Update_Reset = new System.Windows.Forms.Button();
            this.Update_Delete = new System.Windows.Forms.Button();
            this.Update_Save = new System.Windows.Forms.Button();
            this.Update_Back = new System.Windows.Forms.Button();
            this.Update_Notes = new System.Windows.Forms.TextBox();
            this.Update_PD = new System.Windows.Forms.TextBox();
            this.Update_MNote = new System.Windows.Forms.TextBox();
            this.assetsTableAdapter1 = new SGlen_Prototype_1.mssql1903299DataSet3TableAdapters.AssetsTableAdapter();
            this.assetsTableAdapter2 = new SGlen_Prototype_1.mssql1903299DataSet8TableAdapters.AssetsTableAdapter();
            this.assetsTableAdapter3 = new SGlen_Prototype_1.mssql1903299DataSet9TableAdapters.AssetsTableAdapter();
            this.mssql1903299DataSet11 = new SGlen_Prototype_1.mssql1903299DataSet11();
            this.assetsBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.assetsTableAdapter4 = new SGlen_Prototype_1.mssql1903299DataSet11TableAdapters.AssetsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.Update_Asset_View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource4)).BeginInit();
            this.SuspendLayout();
            // 
            // Update_Asset_View
            // 
            this.Update_Asset_View.AutoGenerateColumns = false;
            this.Update_Asset_View.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Update_Asset_View.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.assetIDDataGridViewTextBoxColumn,
            this.diviceNameDataGridViewTextBoxColumn,
            this.modelDataGridViewTextBoxColumn,
            this.manufacturerDataGridViewTextBoxColumn,
            this.mTypeDataGridViewTextBoxColumn,
            this.purchaseDateDataGridViewTextBoxColumn,
            this.hDDSerialNUMDataGridViewTextBoxColumn,
            this.networkinterfaceNameDataGridViewTextBoxColumn,
            this.networkinterfaceTypeDataGridViewTextBoxColumn,
            this.networkIPVersionDataGridViewTextBoxColumn,
            this.maintenanceNotesDataGridViewTextBoxColumn,
            this.notesDataGridViewTextBoxColumn,
            this.locationIDDataGridViewTextBoxColumn,
            this.iPAddressDataGridViewTextBoxColumn,
            this.oSDataGridViewTextBoxColumn});
            this.Update_Asset_View.DataSource = this.assetsBindingSource4;
            this.Update_Asset_View.Location = new System.Drawing.Point(12, 12);
            this.Update_Asset_View.Name = "Update_Asset_View";
            this.Update_Asset_View.RowHeadersWidth = 62;
            this.Update_Asset_View.RowTemplate.Height = 28;
            this.Update_Asset_View.Size = new System.Drawing.Size(1045, 328);
            this.Update_Asset_View.TabIndex = 0;
            this.Update_Asset_View.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Update_Asset_View_CellContentClick);
            // 
            // assetIDDataGridViewTextBoxColumn
            // 
            this.assetIDDataGridViewTextBoxColumn.DataPropertyName = "Asset_ID";
            this.assetIDDataGridViewTextBoxColumn.HeaderText = "Asset_ID";
            this.assetIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.assetIDDataGridViewTextBoxColumn.Name = "assetIDDataGridViewTextBoxColumn";
            this.assetIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.assetIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // diviceNameDataGridViewTextBoxColumn
            // 
            this.diviceNameDataGridViewTextBoxColumn.DataPropertyName = "Divice_Name";
            this.diviceNameDataGridViewTextBoxColumn.HeaderText = "Divice_Name";
            this.diviceNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.diviceNameDataGridViewTextBoxColumn.Name = "diviceNameDataGridViewTextBoxColumn";
            this.diviceNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // modelDataGridViewTextBoxColumn
            // 
            this.modelDataGridViewTextBoxColumn.DataPropertyName = "Model";
            this.modelDataGridViewTextBoxColumn.HeaderText = "Model";
            this.modelDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.modelDataGridViewTextBoxColumn.Name = "modelDataGridViewTextBoxColumn";
            this.modelDataGridViewTextBoxColumn.Width = 150;
            // 
            // manufacturerDataGridViewTextBoxColumn
            // 
            this.manufacturerDataGridViewTextBoxColumn.DataPropertyName = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn.HeaderText = "Manufacturer";
            this.manufacturerDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.manufacturerDataGridViewTextBoxColumn.Name = "manufacturerDataGridViewTextBoxColumn";
            this.manufacturerDataGridViewTextBoxColumn.Width = 150;
            // 
            // mTypeDataGridViewTextBoxColumn
            // 
            this.mTypeDataGridViewTextBoxColumn.DataPropertyName = "MType";
            this.mTypeDataGridViewTextBoxColumn.HeaderText = "MType";
            this.mTypeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.mTypeDataGridViewTextBoxColumn.Name = "mTypeDataGridViewTextBoxColumn";
            this.mTypeDataGridViewTextBoxColumn.Width = 150;
            // 
            // purchaseDateDataGridViewTextBoxColumn
            // 
            this.purchaseDateDataGridViewTextBoxColumn.DataPropertyName = "Purchase_Date";
            this.purchaseDateDataGridViewTextBoxColumn.HeaderText = "Purchase_Date";
            this.purchaseDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.purchaseDateDataGridViewTextBoxColumn.Name = "purchaseDateDataGridViewTextBoxColumn";
            this.purchaseDateDataGridViewTextBoxColumn.Width = 150;
            // 
            // hDDSerialNUMDataGridViewTextBoxColumn
            // 
            this.hDDSerialNUMDataGridViewTextBoxColumn.DataPropertyName = "HDD_Serial_NUM";
            this.hDDSerialNUMDataGridViewTextBoxColumn.HeaderText = "HDD_Serial_NUM";
            this.hDDSerialNUMDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.hDDSerialNUMDataGridViewTextBoxColumn.Name = "hDDSerialNUMDataGridViewTextBoxColumn";
            this.hDDSerialNUMDataGridViewTextBoxColumn.Width = 150;
            // 
            // networkinterfaceNameDataGridViewTextBoxColumn
            // 
            this.networkinterfaceNameDataGridViewTextBoxColumn.DataPropertyName = "Network_interface_Name";
            this.networkinterfaceNameDataGridViewTextBoxColumn.HeaderText = "Network_interface_Name";
            this.networkinterfaceNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.networkinterfaceNameDataGridViewTextBoxColumn.Name = "networkinterfaceNameDataGridViewTextBoxColumn";
            this.networkinterfaceNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // networkinterfaceTypeDataGridViewTextBoxColumn
            // 
            this.networkinterfaceTypeDataGridViewTextBoxColumn.DataPropertyName = "Network_interfaceType";
            this.networkinterfaceTypeDataGridViewTextBoxColumn.HeaderText = "Network_interfaceType";
            this.networkinterfaceTypeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.networkinterfaceTypeDataGridViewTextBoxColumn.Name = "networkinterfaceTypeDataGridViewTextBoxColumn";
            this.networkinterfaceTypeDataGridViewTextBoxColumn.Width = 150;
            // 
            // networkIPVersionDataGridViewTextBoxColumn
            // 
            this.networkIPVersionDataGridViewTextBoxColumn.DataPropertyName = "Network_IP_Version";
            this.networkIPVersionDataGridViewTextBoxColumn.HeaderText = "Network_IP_Version";
            this.networkIPVersionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.networkIPVersionDataGridViewTextBoxColumn.Name = "networkIPVersionDataGridViewTextBoxColumn";
            this.networkIPVersionDataGridViewTextBoxColumn.Width = 150;
            // 
            // maintenanceNotesDataGridViewTextBoxColumn
            // 
            this.maintenanceNotesDataGridViewTextBoxColumn.DataPropertyName = "Maintenance_Notes";
            this.maintenanceNotesDataGridViewTextBoxColumn.HeaderText = "Maintenance_Notes";
            this.maintenanceNotesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.maintenanceNotesDataGridViewTextBoxColumn.Name = "maintenanceNotesDataGridViewTextBoxColumn";
            this.maintenanceNotesDataGridViewTextBoxColumn.Width = 150;
            // 
            // notesDataGridViewTextBoxColumn
            // 
            this.notesDataGridViewTextBoxColumn.DataPropertyName = "Notes";
            this.notesDataGridViewTextBoxColumn.HeaderText = "Notes";
            this.notesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.notesDataGridViewTextBoxColumn.Name = "notesDataGridViewTextBoxColumn";
            this.notesDataGridViewTextBoxColumn.Width = 150;
            // 
            // locationIDDataGridViewTextBoxColumn
            // 
            this.locationIDDataGridViewTextBoxColumn.DataPropertyName = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn.HeaderText = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.locationIDDataGridViewTextBoxColumn.Name = "locationIDDataGridViewTextBoxColumn";
            this.locationIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // iPAddressDataGridViewTextBoxColumn
            // 
            this.iPAddressDataGridViewTextBoxColumn.DataPropertyName = "IP_Address";
            this.iPAddressDataGridViewTextBoxColumn.HeaderText = "IP_Address";
            this.iPAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.iPAddressDataGridViewTextBoxColumn.Name = "iPAddressDataGridViewTextBoxColumn";
            this.iPAddressDataGridViewTextBoxColumn.Width = 150;
            // 
            // oSDataGridViewTextBoxColumn
            // 
            this.oSDataGridViewTextBoxColumn.DataPropertyName = "OS";
            this.oSDataGridViewTextBoxColumn.HeaderText = "OS";
            this.oSDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.oSDataGridViewTextBoxColumn.Name = "oSDataGridViewTextBoxColumn";
            this.oSDataGridViewTextBoxColumn.Width = 150;
            // 
            // assetsBindingSource3
            // 
            this.assetsBindingSource3.DataMember = "Assets";
            this.assetsBindingSource3.DataSource = this.mssql1903299DataSet9;
            // 
            // mssql1903299DataSet9
            // 
            this.mssql1903299DataSet9.DataSetName = "mssql1903299DataSet9";
            this.mssql1903299DataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetsBindingSource2
            // 
            this.assetsBindingSource2.DataMember = "Assets";
            this.assetsBindingSource2.DataSource = this.mssql1903299DataSet8;
            // 
            // mssql1903299DataSet8
            // 
            this.mssql1903299DataSet8.DataSetName = "mssql1903299DataSet8";
            this.mssql1903299DataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetsBindingSource1
            // 
            this.assetsBindingSource1.DataMember = "Assets";
            this.assetsBindingSource1.DataSource = this.mssql1903299DataSet3;
            // 
            // mssql1903299DataSet3
            // 
            this.mssql1903299DataSet3.DataSetName = "mssql1903299DataSet3";
            this.mssql1903299DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetsBindingSource
            // 
            this.assetsBindingSource.DataMember = "Assets";
            this.assetsBindingSource.DataSource = this.mssql1903299DataSet2;
            // 
            // mssql1903299DataSet2
            // 
            this.mssql1903299DataSet2.DataSetName = "mssql1903299DataSet2";
            this.mssql1903299DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetsTableAdapter
            // 
            this.assetsTableAdapter.ClearBeforeFill = true;
            // 
            // Update_Reset
            // 
            this.Update_Reset.Location = new System.Drawing.Point(699, 386);
            this.Update_Reset.Name = "Update_Reset";
            this.Update_Reset.Size = new System.Drawing.Size(147, 67);
            this.Update_Reset.TabIndex = 1;
            this.Update_Reset.Text = "Reset Table";
            this.Update_Reset.UseVisualStyleBackColor = true;
            this.Update_Reset.Click += new System.EventHandler(this.Update_Reset_Click);
            // 
            // Update_Delete
            // 
            this.Update_Delete.Location = new System.Drawing.Point(862, 386);
            this.Update_Delete.Name = "Update_Delete";
            this.Update_Delete.Size = new System.Drawing.Size(147, 67);
            this.Update_Delete.TabIndex = 2;
            this.Update_Delete.Text = "Delete";
            this.Update_Delete.UseVisualStyleBackColor = true;
            this.Update_Delete.Click += new System.EventHandler(this.Update_Delete_Click);
            // 
            // Update_Save
            // 
            this.Update_Save.Location = new System.Drawing.Point(699, 459);
            this.Update_Save.Name = "Update_Save";
            this.Update_Save.Size = new System.Drawing.Size(147, 67);
            this.Update_Save.TabIndex = 3;
            this.Update_Save.Text = "Save";
            this.Update_Save.UseVisualStyleBackColor = true;
            this.Update_Save.Click += new System.EventHandler(this.Update_Save_Click);
            // 
            // Update_Back
            // 
            this.Update_Back.Location = new System.Drawing.Point(862, 459);
            this.Update_Back.Name = "Update_Back";
            this.Update_Back.Size = new System.Drawing.Size(147, 67);
            this.Update_Back.TabIndex = 4;
            this.Update_Back.Text = "Back";
            this.Update_Back.UseVisualStyleBackColor = true;
            this.Update_Back.Click += new System.EventHandler(this.Update_Back_Click);
            // 
            // Update_Notes
            // 
            this.Update_Notes.Location = new System.Drawing.Point(120, 427);
            this.Update_Notes.Name = "Update_Notes";
            this.Update_Notes.Size = new System.Drawing.Size(366, 26);
            this.Update_Notes.TabIndex = 5;
            this.Update_Notes.Text = "Enter the Updated general notes";
            this.Update_Notes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Update_PD
            // 
            this.Update_PD.Location = new System.Drawing.Point(120, 470);
            this.Update_PD.Name = "Update_PD";
            this.Update_PD.Size = new System.Drawing.Size(366, 26);
            this.Update_PD.TabIndex = 6;
            this.Update_PD.Text = "Enter the Updated Purchace Date";
            this.Update_PD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Update_MNote
            // 
            this.Update_MNote.Location = new System.Drawing.Point(120, 386);
            this.Update_MNote.Name = "Update_MNote";
            this.Update_MNote.Size = new System.Drawing.Size(366, 26);
            this.Update_MNote.TabIndex = 7;
            this.Update_MNote.Text = "Enter the Updated Manitanace notes";
            this.Update_MNote.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // assetsTableAdapter1
            // 
            this.assetsTableAdapter1.ClearBeforeFill = true;
            // 
            // assetsTableAdapter2
            // 
            this.assetsTableAdapter2.ClearBeforeFill = true;
            // 
            // assetsTableAdapter3
            // 
            this.assetsTableAdapter3.ClearBeforeFill = true;
            // 
            // mssql1903299DataSet11
            // 
            this.mssql1903299DataSet11.DataSetName = "mssql1903299DataSet11";
            this.mssql1903299DataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetsBindingSource4
            // 
            this.assetsBindingSource4.DataMember = "Assets";
            this.assetsBindingSource4.DataSource = this.mssql1903299DataSet11;
            // 
            // assetsTableAdapter4
            // 
            this.assetsTableAdapter4.ClearBeforeFill = true;
            // 
            // Update_asset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1069, 558);
            this.Controls.Add(this.Update_MNote);
            this.Controls.Add(this.Update_PD);
            this.Controls.Add(this.Update_Notes);
            this.Controls.Add(this.Update_Back);
            this.Controls.Add(this.Update_Save);
            this.Controls.Add(this.Update_Delete);
            this.Controls.Add(this.Update_Reset);
            this.Controls.Add(this.Update_Asset_View);
            this.Name = "Update_asset";
            this.Text = "Update";
            this.Load += new System.EventHandler(this.Update_asset_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Update_Asset_View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetsBindingSource4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Update_Asset_View;
        private mssql1903299DataSet2 mssql1903299DataSet2;
        private System.Windows.Forms.BindingSource assetsBindingSource;
        private mssql1903299DataSet2TableAdapters.AssetsTableAdapter assetsTableAdapter;
        private System.Windows.Forms.Button Update_Reset;
        private System.Windows.Forms.Button Update_Delete;
        private System.Windows.Forms.Button Update_Save;
        private System.Windows.Forms.Button Update_Back;
        private System.Windows.Forms.TextBox Update_Notes;
        private System.Windows.Forms.TextBox Update_PD;
        private System.Windows.Forms.TextBox Update_MNote;
        private mssql1903299DataSet3 mssql1903299DataSet3;
        private System.Windows.Forms.BindingSource assetsBindingSource1;
        private mssql1903299DataSet3TableAdapters.AssetsTableAdapter assetsTableAdapter1;
        private mssql1903299DataSet8 mssql1903299DataSet8;
        private System.Windows.Forms.BindingSource assetsBindingSource2;
        private mssql1903299DataSet8TableAdapters.AssetsTableAdapter assetsTableAdapter2;
        private mssql1903299DataSet9 mssql1903299DataSet9;
        private System.Windows.Forms.BindingSource assetsBindingSource3;
        private mssql1903299DataSet9TableAdapters.AssetsTableAdapter assetsTableAdapter3;
        private System.Windows.Forms.DataGridViewTextBoxColumn assetIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diviceNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manufacturerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchaseDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hDDSerialNUMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn networkinterfaceNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn networkinterfaceTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn networkIPVersionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maintenanceNotesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn notesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iPAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oSDataGridViewTextBoxColumn;
        private mssql1903299DataSet11 mssql1903299DataSet11;
        private System.Windows.Forms.BindingSource assetsBindingSource4;
        private mssql1903299DataSet11TableAdapters.AssetsTableAdapter assetsTableAdapter4;
    }
}