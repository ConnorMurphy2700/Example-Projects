﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SGlen_Prototype_1
{
    public partial class Location : Form
    {
        public Location()
        {
            InitializeComponent();
        }

        readonly mssql1903299Entities6 db = new mssql1903299Entities6();
        Asset asset = new Asset();
        DLocation building = new DLocation();
        int Empid = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            ClearData();
            SetDataInGridView();
        }

        public void ClearData()
        {
            Location_Name.Text = Location_Adds.Text = Location_Post_Code.Text = Location_PNum.Text = string.Empty;
            Loc_Delete.Enabled = false;
            Submit_Location.Text = "Save";
            Empid = 0;
        }

        public void SetDataInGridView()
        {
            BranchGridView.AutoGenerateColumns = false;
            BranchGridView.DataSource = db.DLocations.ToList<DLocation>();
        }

        private void Submit_Location_Click(object sender, EventArgs e)
        {
            try
            {

                if (string.IsNullOrEmpty(Location_Name.Text) == true) //checks text boxes for new information
                {
                    MessageBox.Show("Please enter the name of the new branch");
                    Location_Name.Text = "Enter the name of the new branch";
                    return;
                }
                if (Location_Name.Text == "Enter the name of the new branch")
                {
                    MessageBox.Show("Please enter the name of the new branch");
                    Location_Name.Text = "Enter the name of the new branch";
                    return;
                }
                if (string.IsNullOrEmpty(Location_Adds.Text) == true)
                {
                    MessageBox.Show("Please enter the Address of the new branch");
                    Location_Adds.Text = "Enter the Address of the new branch";
                    return;
                }
                if (Location_Adds.Text == "Enter the Address of the new branch")
                {
                    MessageBox.Show("Please enter the Address of the new branch");
                    Location_Adds.Text = "Enter the Address of the new branch";
                    return;
                }
                if (string.IsNullOrEmpty(Location_Post_Code.Text) == true)
                {
                    MessageBox.Show("Please enter the Post Code of the new branch");
                    Location_Post_Code.Text = "Enter the Post Code of  the New Branch";
                    return;
                }
                if (Location_Post_Code.Text == "Enter the Post Code of  the New Branch")
                {
                    MessageBox.Show("Please enter the Post Code of the new branch");
                    Location_Post_Code.Text = "Enter the Post Code of  the New Branch";
                    return;
                }
                if (string.IsNullOrEmpty(Location_PNum.Text) == true)
                {
                    MessageBox.Show("Please enter the Phone Number of the new branch");
                    Location_PNum.Text = "Enter the Phone Number of the new branch";
                    return;
                }
                if (Location_PNum.Text == "Enter the Phone Number of the new branch")
                {
                    MessageBox.Show("Please enter the Phone Number of the new branch");
                    Location_PNum.Text = "Enter the Phone Number of the new branch";
                    return;
                }

                building.Place_Name = Location_Name.Text.Trim(); // sets row values
                building.DAddress = Location_Adds.Text.Trim();
                building.Post_Code = Location_Post_Code.Text.Trim();
                building.Phone_Num = Convert.ToInt32(Location_PNum.Text.Trim());

                if (Empid > 0)
                    db.Entry(building).State = EntityState.Modified;
                else
                {
                    db.DLocations.Add(building);//adding new row to the database
                }

                db.SaveChanges();
                SetDataInGridView();
                MessageBox.Show("Record Save Successfully");

                Location_Name.Text = "Enter the name of the new branch"; // resets text boxes
                Location_Adds.Text = "Enter the Address of the new branch";
                Location_Post_Code.Text = "Enter the Post Code of  the New Branch";
                Location_PNum.Text = "Enter the Phone Number of the new branch";
            }
            catch (Exception x)
            {
                MessageBox.Show("You have entered invalid data make sure to check for correct formatting.");

            }
            

        }


        private void Loc_Cancel_Click(object sender, EventArgs e)
        {
            var m = new MainPage();//navagates back to main page
            m.Show();
            this.Hide();
        }

        private void Location_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mssql1903299DataSet.DLocation' table. You can move, or remove it, as needed.
            this.dLocationTableAdapter1.Fill(this.mssql1903299DataSet.DLocation);

        }

        private void BranchGridView_DoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (BranchGridView.CurrentCell.RowIndex != -1)
            {
                Empid = (int)BranchGridView.CurrentRow.Cells[0].Value;
                building = db.DLocations.Where(x => x.Location_ID == Empid).FirstOrDefault();
                Location_Name.Text = building.Place_Name;
                Location_Adds.Text = building.DAddress;
                Location_Post_Code.Text = building.Post_Code.ToString();
                Location_PNum.Text = building.Phone_Num.ToString();

            }
            Submit_Location.Text = "Update";
            Loc_Delete.Enabled = true;
        }

        private void Loc_Delete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this record ?", "Delete ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                db.DLocations.Remove(building);
                db.SaveChanges();
                ClearData();
                SetDataInGridView();
                MessageBox.Show("Record Deleted Successfully");
            }
        }

        private void Loc_Reload_Click(object sender, EventArgs e)
        {
            SetDataInGridView();
        }
    }
}
