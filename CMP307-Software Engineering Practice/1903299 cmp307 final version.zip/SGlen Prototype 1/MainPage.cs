﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SGlen_Prototype_1
{
    public partial class MainPage : Form
    {
        public MainPage()
        {
            InitializeComponent();
        }

        readonly mssql1903299Entities6 db = new mssql1903299Entities6();
        Asset asset = new Asset();
        Software sware = new Software();
        Search GB = new Search();
        int EmpId;
        public static int LocID;
        public static string IPADD;
        string hold;
        public bool TestTextbox() //test to see if the textbox has been filled 
        {
            if (string.IsNullOrEmpty(Find_Asset.Text) == true) //checks text boxes for new information
            {
                MessageBox.Show("Please enter the data you are trying to search by");
                Find_Asset.Text = "Enter the data you are trying to search by";
                return false;
            }
            if (Find_Asset.Text == "Enter the data you are trying to search by")
            {
                MessageBox.Show("Please enter the data you are trying to search by");
                Find_Asset.Text = "Enter the data you are trying to search by";
                return false;
            }
            return true;
        }

        private void Reset_Table_Click(object sender, EventArgs e)//resets asset table
        {
            Main_Assets.AutoGenerateColumns = false;
            Main_Assets.DataSource = db.Assets.ToList<Asset>();

        }

        public void ClearData()// clear software data 
        {
            Software_OS.Text = Software_manu.Text = string.Empty;
            Software_Save.Text = "Save";
            EmpId = 0;
        }

        public void SetDataInGridView()//sets the software table
        {
            SoftwareGridView.AutoGenerateColumns = false;
            SoftwareGridView.DataSource = db.Softwares.ToList<Software>();
        }

        private void AddAsset_Click(object sender, EventArgs e) //navagates to add asset page
        {
            var m = new Add_Asset();
            m.Show();
            this.Hide();
        }

        private void SearchId_Click(object sender, EventArgs e) //searches asset by there ID
        {
            if(TestTextbox() == false){return;}//test to see if the textbox has been filled 
            int search =Convert.ToInt32(Find_Asset.Text.Trim());
            bool exists = GB.Asset_Test(search);// test to see if asset exists
            if (exists == false) { return; }
            Main_Assets.AutoGenerateColumns = false;
            Main_Assets.DataSource = (from p in db.Assets
                                      where p.Asset_ID == search
                                      select p).ToList();
        }

        private void SearchLocation_Click(object sender, EventArgs e) //searches asset by there location 
        {
            if (TestTextbox() == false) { return; }//test to see if the textbox has been filled 
            int search = Convert.ToInt32(Find_Asset.Text.Trim());
            bool exists = GB.Asset_Test(search);// test to see if asset exists
            if (exists == false) { return; }
            Main_Assets.AutoGenerateColumns = false;
            Main_Assets.DataSource = (from p in db.Assets
                                      where p.Location_ID == search
                                      select p).ToList();
        }

        private void FindAsset_Click(object sender, EventArgs e) //navagates to find asset page
        {

            if (TestTextbox() == false) { return; }//test to see if the textbox has been filled 
            int search = Convert.ToInt32(Find_Asset.Text.Trim());
            bool exists2 = GB.Asset_Test(search);// test to see if asset exists
            if (exists2 == false) { return; }


             IPADD = GB.Find_IP(search);
             LocID = GB.Find_building(search);

            var m = new Search_Asset();
            m.Show();
            this.Hide();
        }
        private void Update_Asset_Click(object sender, EventArgs e) //navagates to update asset page
        {
            var m = new Update_asset();
            m.Show();
            this.Hide();
        }
        private void MainPage_Load(object sender, EventArgs e) // loads data tables 
        {
            // TODO: This line of code loads data into the 'mssql1903299DataSet10.Assets' table. You can move, or remove it, as needed.
            this.assetsTableAdapter4.Fill(this.mssql1903299DataSet10.Assets);
            // TODO: This line of code loads data into the 'mssql1903299DataSet7.Assets' table. You can move, or remove it, as needed.
            //this.assetsTableAdapter3.Fill(this.mssql1903299DataSet7.Assets);
            // TODO: This line of code loads data into the 'mssql1903299DataSet6.Software' table. You can move, or remove it, as needed.
            this.softwareTableAdapter.Fill(this.mssql1903299DataSet6.Software);
            // TODO: This line of code loads data into the 'mssql1903299DataSet3.Assets' table. You can move, or remove it, as needed.
            //this.assetsTableAdapter1.Fill(this.mssql1903299DataSet3.Assets);
        }

        private void AddLocation_Click(object sender, EventArgs e) //navagates to add location page
        {
            var m = new Location();
            m.Show();
            this.Hide();
        }

        private void Delete_Location_Click(object sender, EventArgs e) //navagates to add location page
        {
            var m = new Location();
            m.Show();
            this.Hide();
        }

        private void Update_Location_Click(object sender, EventArgs e) //navagates to add location page
        {
            var m = new Location();
            m.Show();
            this.Hide();
        }

        private void AddLocation_Click_1(object sender, EventArgs e) //navagates to add location page
        {
            var m = new Location();
            m.Show();
            this.Hide();
        }

        private void Software_Relode_Click(object sender, EventArgs e) //reloads software table
        {
            SoftwareGridView.AutoGenerateColumns = false;
            SoftwareGridView.DataSource = db.Softwares.ToList<Software>();
        }

        private void Software_Save_Click(object sender, EventArgs e) //save or update software row
        {
            
            try { 
            if (string.IsNullOrEmpty(Software_OS.Text) == true) //checks text boxes for new information
            {
                MessageBox.Show("Please enter the name of the new operating system as well as the version");
                Software_OS.Text = "Enter the name of the new operating system as well as the version";
                return;
            }
            if (Software_OS.Text == "Enter the name of the new operating system as well as the version")
            {
                MessageBox.Show("Please enter the name of the new operating system as well as the version");
                Software_OS.Text = "Enter the name of the new operating system as well as the version";
                return;
            }

            if (string.IsNullOrEmpty(Software_manu.Text) == true) //checks text boxes for new information
            {
                MessageBox.Show("Please enter the name of the new manufacture of the Operating System");
                Software_manu.Text = "Enter the name of  the manufacture of the Operating System";
                return;
            }
            if (Software_manu.Text == "Enter the name of  the manufacture of the Operating System")
            {
                MessageBox.Show("Please enter the name of the new manufacture of the Operating System");
                Software_manu.Text = "Enter the name of  the manufacture of the Operating System";
                return;
            }

            sware.OS = Software_OS.Text.Trim();
            sware.Manufacturer = Software_manu.Text.Trim();

            if (EmpId > 0) { 
                db.Entry(sware).State = EntityState.Modified;
                    GB.update_asset(hold, Software_OS.Text.Trim());
            }
                else
            {
                db.Softwares.Add(sware);
            }
            db.SaveChanges();
            ClearData();
            SetDataInGridView();
            MessageBox.Show("Record Save Successfully");

            Software_OS.Text = "Enter the name of the new operating system as well as the version"; // resets text boxes
            Software_manu.Text = "Enter the name of  the manufacture of the Operating System";

            }
            catch (Exception x)
            {
                MessageBox.Show("You have entered invalid data make sure to check for correct formatting.");

            }
        }




        private void SoftwareGridView_CellContentClick_1(object sender, DataGridViewCellEventArgs e)//function to update software row
        {
            if (SoftwareGridView.CurrentCell.RowIndex != -1)
            {
                EmpId = (int)SoftwareGridView.CurrentRow.Cells[0].Value;
                sware = db.Softwares.Where(x => x.SW_ID == EmpId).FirstOrDefault();
                Software_OS.Text = sware.OS;
                hold = sware.OS;
                Software_manu.Text = sware.Manufacturer;

            }
            Software_Save.Text = "Update";
        }


    }
}
