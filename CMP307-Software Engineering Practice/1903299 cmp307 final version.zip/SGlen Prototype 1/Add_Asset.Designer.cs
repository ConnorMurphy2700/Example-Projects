﻿
namespace SGlen_Prototype_1
{
    partial class Add_Asset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Main_Assets = new System.Windows.Forms.DataGridView();
            this.locationIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.placeNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dLocationBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet4 = new SGlen_Prototype_1.mssql1903299DataSet4();
            this.dLocationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet = new SGlen_Prototype_1.mssql1903299DataSet();
            this.dLocationTableAdapter = new SGlen_Prototype_1.mssql1903299DataSetTableAdapters.DLocationTableAdapter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Asset_MNote = new System.Windows.Forms.TextBox();
            this.Asset_Location = new System.Windows.Forms.TextBox();
            this.Asset_NIT = new System.Windows.Forms.TextBox();
            this.Asset_NIN = new System.Windows.Forms.TextBox();
            this.Asset_HDD = new System.Windows.Forms.TextBox();
            this.Asset_Date = new System.Windows.Forms.TextBox();
            this.Asset_manu = new System.Windows.Forms.TextBox();
            this.Asset_Model = new System.Windows.Forms.TextBox();
            this.Asset_name = new System.Windows.Forms.TextBox();
            this.Asset_Notes = new System.Windows.Forms.TextBox();
            this.Location_Room_Num = new System.Windows.Forms.TextBox();
            this.Location_Dep = new System.Windows.Forms.TextBox();
            this.Location_Desk_Number = new System.Windows.Forms.TextBox();
            this.Asset_IP = new System.Windows.Forms.TextBox();
            this.Location_Ser = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Get_Info = new System.Windows.Forms.Button();
            this.Asset_Cancel = new System.Windows.Forms.Button();
            this.Asset_Submit = new System.Windows.Forms.Button();
            this.Asset_Type = new System.Windows.Forms.TextBox();
            this.Asset_IP_Version = new System.Windows.Forms.TextBox();
            this.dLocationBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dLocationTableAdapter1 = new SGlen_Prototype_1.mssql1903299DataSet4TableAdapters.DLocationTableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Asset_OS = new System.Windows.Forms.TextBox();
            this.Software_Manu = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Main_Assets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // Main_Assets
            // 
            this.Main_Assets.AllowUserToAddRows = false;
            this.Main_Assets.AllowUserToDeleteRows = false;
            this.Main_Assets.AllowUserToOrderColumns = true;
            this.Main_Assets.AutoGenerateColumns = false;
            this.Main_Assets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Main_Assets.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.locationIDDataGridViewTextBoxColumn,
            this.placeNameDataGridViewTextBoxColumn});
            this.Main_Assets.DataSource = this.dLocationBindingSource2;
            this.Main_Assets.Location = new System.Drawing.Point(617, 238);
            this.Main_Assets.Name = "Main_Assets";
            this.Main_Assets.ReadOnly = true;
            this.Main_Assets.RowHeadersWidth = 62;
            this.Main_Assets.RowTemplate.Height = 28;
            this.Main_Assets.Size = new System.Drawing.Size(442, 190);
            this.Main_Assets.TabIndex = 1;
            // 
            // locationIDDataGridViewTextBoxColumn
            // 
            this.locationIDDataGridViewTextBoxColumn.DataPropertyName = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn.HeaderText = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.locationIDDataGridViewTextBoxColumn.Name = "locationIDDataGridViewTextBoxColumn";
            this.locationIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.locationIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // placeNameDataGridViewTextBoxColumn
            // 
            this.placeNameDataGridViewTextBoxColumn.DataPropertyName = "Place_Name";
            this.placeNameDataGridViewTextBoxColumn.HeaderText = "Place_Name";
            this.placeNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.placeNameDataGridViewTextBoxColumn.Name = "placeNameDataGridViewTextBoxColumn";
            this.placeNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.placeNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // dLocationBindingSource2
            // 
            this.dLocationBindingSource2.DataMember = "DLocation";
            this.dLocationBindingSource2.DataSource = this.mssql1903299DataSet4;
            // 
            // mssql1903299DataSet4
            // 
            this.mssql1903299DataSet4.DataSetName = "mssql1903299DataSet4";
            this.mssql1903299DataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dLocationBindingSource
            // 
            this.dLocationBindingSource.DataMember = "DLocation";
            this.dLocationBindingSource.DataSource = this.mssql1903299DataSet;
            // 
            // mssql1903299DataSet
            // 
            this.mssql1903299DataSet.DataSetName = "mssql1903299DataSet";
            this.mssql1903299DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dLocationTableAdapter
            // 
            this.dLocationTableAdapter.ClearBeforeFill = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Location = new System.Drawing.Point(12, 199);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1056, 10);
            this.panel1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.Location = new System.Drawing.Point(12, 450);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1054, 10);
            this.panel2.TabIndex = 3;
            // 
            // Asset_MNote
            // 
            this.Asset_MNote.Location = new System.Drawing.Point(17, 270);
            this.Asset_MNote.Multiline = true;
            this.Asset_MNote.Name = "Asset_MNote";
            this.Asset_MNote.Size = new System.Drawing.Size(456, 76);
            this.Asset_MNote.TabIndex = 4;
            this.Asset_MNote.Text = "Enter the any Maintenance notes for the Asset less than 150 characters";
            this.Asset_MNote.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Asset_Location
            // 
            this.Asset_Location.Location = new System.Drawing.Point(17, 238);
            this.Asset_Location.Name = "Asset_Location";
            this.Asset_Location.Size = new System.Drawing.Size(456, 26);
            this.Asset_Location.TabIndex = 5;
            this.Asset_Location.Text = "Enter the Id of the building the new Asset will be placed in";
            this.Asset_Location.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Asset_NIT
            // 
            this.Asset_NIT.Location = new System.Drawing.Point(594, 89);
            this.Asset_NIT.Name = "Asset_NIT";
            this.Asset_NIT.Size = new System.Drawing.Size(467, 26);
            this.Asset_NIT.TabIndex = 6;
            this.Asset_NIT.Text = "Enter the type of network interface the new Asset will use";
            this.Asset_NIT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Asset_NIN
            // 
            this.Asset_NIN.Location = new System.Drawing.Point(594, 57);
            this.Asset_NIN.Name = "Asset_NIN";
            this.Asset_NIN.Size = new System.Drawing.Size(467, 26);
            this.Asset_NIN.TabIndex = 7;
            this.Asset_NIN.Text = "Enter the name of the Network Interface of new Asset";
            this.Asset_NIN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Asset_HDD
            // 
            this.Asset_HDD.Location = new System.Drawing.Point(17, 153);
            this.Asset_HDD.Name = "Asset_HDD";
            this.Asset_HDD.Size = new System.Drawing.Size(325, 26);
            this.Asset_HDD.TabIndex = 8;
            this.Asset_HDD.Text = "Enter the HDD number of the new Asset";
            this.Asset_HDD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Asset_Date
            // 
            this.Asset_Date.Location = new System.Drawing.Point(594, 25);
            this.Asset_Date.Name = "Asset_Date";
            this.Asset_Date.Size = new System.Drawing.Size(467, 26);
            this.Asset_Date.TabIndex = 9;
            this.Asset_Date.Text = "Enter the date of purchace of the new Asset (yyyy/mm/dd)";
            this.Asset_Date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Asset_manu
            // 
            this.Asset_manu.Location = new System.Drawing.Point(17, 89);
            this.Asset_manu.Name = "Asset_manu";
            this.Asset_manu.Size = new System.Drawing.Size(325, 26);
            this.Asset_manu.TabIndex = 10;
            this.Asset_manu.Text = "Enter the Manufacturer of the new Asset";
            this.Asset_manu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Asset_Model
            // 
            this.Asset_Model.Location = new System.Drawing.Point(17, 57);
            this.Asset_Model.Name = "Asset_Model";
            this.Asset_Model.Size = new System.Drawing.Size(325, 26);
            this.Asset_Model.TabIndex = 11;
            this.Asset_Model.Text = "Enter the Model of the new Asset";
            this.Asset_Model.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Asset_name
            // 
            this.Asset_name.Location = new System.Drawing.Point(17, 25);
            this.Asset_name.Name = "Asset_name";
            this.Asset_name.Size = new System.Drawing.Size(325, 26);
            this.Asset_name.TabIndex = 12;
            this.Asset_name.Text = "Enter the name of the new Asset";
            this.Asset_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Asset_Notes
            // 
            this.Asset_Notes.Location = new System.Drawing.Point(17, 352);
            this.Asset_Notes.Multiline = true;
            this.Asset_Notes.Name = "Asset_Notes";
            this.Asset_Notes.Size = new System.Drawing.Size(456, 76);
            this.Asset_Notes.TabIndex = 13;
            this.Asset_Notes.Text = "Enter the any general notes for the Asset less than 150 characters";
            this.Asset_Notes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Location_Room_Num
            // 
            this.Location_Room_Num.Location = new System.Drawing.Point(120, 700);
            this.Location_Room_Num.Name = "Location_Room_Num";
            this.Location_Room_Num.Size = new System.Drawing.Size(456, 26);
            this.Location_Room_Num.TabIndex = 14;
            this.Location_Room_Num.Text = "Enter the Room Number the new Asset will be placed in";
            this.Location_Room_Num.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Location_Dep
            // 
            this.Location_Dep.Location = new System.Drawing.Point(120, 639);
            this.Location_Dep.Name = "Location_Dep";
            this.Location_Dep.Size = new System.Drawing.Size(456, 26);
            this.Location_Dep.TabIndex = 15;
            this.Location_Dep.Text = "Enter the Department that will use the new Asset";
            this.Location_Dep.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Location_Desk_Number
            // 
            this.Location_Desk_Number.Location = new System.Drawing.Point(595, 586);
            this.Location_Desk_Number.Name = "Location_Desk_Number";
            this.Location_Desk_Number.Size = new System.Drawing.Size(456, 26);
            this.Location_Desk_Number.TabIndex = 16;
            this.Location_Desk_Number.Text = "Enter the Desk Number the new Asset will be used at";
            this.Location_Desk_Number.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Asset_IP
            // 
            this.Asset_IP.Location = new System.Drawing.Point(120, 586);
            this.Asset_IP.Name = "Asset_IP";
            this.Asset_IP.Size = new System.Drawing.Size(456, 26);
            this.Asset_IP.TabIndex = 17;
            this.Asset_IP.Text = "Enter the IP Address of the new Asset";
            this.Asset_IP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Location_Ser
            // 
            this.Location_Ser.Location = new System.Drawing.Point(595, 700);
            this.Location_Ser.Name = "Location_Ser";
            this.Location_Ser.Size = new System.Drawing.Size(456, 26);
            this.Location_Ser.TabIndex = 18;
            this.Location_Ser.Text = "Enter the Server Section Number the new Asset will be used at";
            this.Location_Ser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(792, 642);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 20);
            this.label1.TabIndex = 19;
            this.label1.Text = "OR ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(719, 750);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(211, 20);
            this.label2.TabIndex = 20;
            this.label2.Text = "One section must be filled in ";
            // 
            // Get_Info
            // 
            this.Get_Info.Location = new System.Drawing.Point(132, 746);
            this.Get_Info.Name = "Get_Info";
            this.Get_Info.Size = new System.Drawing.Size(147, 58);
            this.Get_Info.TabIndex = 21;
            this.Get_Info.Text = "Get current asset information";
            this.Get_Info.UseVisualStyleBackColor = true;
            this.Get_Info.Click += new System.EventHandler(this.Get_Info_Click);
            // 
            // Asset_Cancel
            // 
            this.Asset_Cancel.Location = new System.Drawing.Point(442, 749);
            this.Asset_Cancel.Name = "Asset_Cancel";
            this.Asset_Cancel.Size = new System.Drawing.Size(134, 52);
            this.Asset_Cancel.TabIndex = 22;
            this.Asset_Cancel.Text = "Cancel";
            this.Asset_Cancel.UseVisualStyleBackColor = true;
            this.Asset_Cancel.Click += new System.EventHandler(this.Asset_Cancel_Click);
            // 
            // Asset_Submit
            // 
            this.Asset_Submit.Location = new System.Drawing.Point(296, 749);
            this.Asset_Submit.Name = "Asset_Submit";
            this.Asset_Submit.Size = new System.Drawing.Size(134, 55);
            this.Asset_Submit.TabIndex = 23;
            this.Asset_Submit.Text = "Submit";
            this.Asset_Submit.UseVisualStyleBackColor = true;
            this.Asset_Submit.Click += new System.EventHandler(this.Asset_Submit_Click);
            // 
            // Asset_Type
            // 
            this.Asset_Type.Location = new System.Drawing.Point(17, 121);
            this.Asset_Type.Name = "Asset_Type";
            this.Asset_Type.Size = new System.Drawing.Size(325, 26);
            this.Asset_Type.TabIndex = 24;
            this.Asset_Type.Text = "Enter the Type of the new Asset";
            this.Asset_Type.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Asset_IP_Version
            // 
            this.Asset_IP_Version.Location = new System.Drawing.Point(594, 121);
            this.Asset_IP_Version.Name = "Asset_IP_Version";
            this.Asset_IP_Version.Size = new System.Drawing.Size(467, 26);
            this.Asset_IP_Version.TabIndex = 25;
            this.Asset_IP_Version.Text = "Enter the IP Version of network interface the new Asset will use";
            this.Asset_IP_Version.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dLocationBindingSource1
            // 
            this.dLocationBindingSource1.DataMember = "DLocation";
            this.dLocationBindingSource1.DataSource = this.mssql1903299DataSet;
            // 
            // dLocationTableAdapter1
            // 
            this.dLocationTableAdapter1.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(411, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 20);
            this.label3.TabIndex = 26;
            this.label3.Text = "Hardware data";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel4.Location = new System.Drawing.Point(12, 561);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1059, 10);
            this.panel4.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 682);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 20);
            this.label4.TabIndex = 27;
            this.label4.Text = "Room data";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(490, 312);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 20);
            this.label7.TabIndex = 30;
            this.label7.Text = "Building data";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(199, 501);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 20);
            this.label8.TabIndex = 31;
            this.label8.Text = "Software data";
            // 
            // Asset_OS
            // 
            this.Asset_OS.Location = new System.Drawing.Point(571, 466);
            this.Asset_OS.Name = "Asset_OS";
            this.Asset_OS.Size = new System.Drawing.Size(456, 26);
            this.Asset_OS.TabIndex = 32;
            this.Asset_OS.Text = "Enter the Operating System the new Asset will run on";
            this.Asset_OS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Software_Manu
            // 
            this.Software_Manu.Location = new System.Drawing.Point(571, 501);
            this.Software_Manu.Name = "Software_Manu";
            this.Software_Manu.Size = new System.Drawing.Size(456, 26);
            this.Software_Manu.TabIndex = 34;
            this.Software_Manu.Text = "Enter the manufacture of  the Operating System";
            this.Software_Manu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Add_Asset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1090, 846);
            this.Controls.Add(this.Software_Manu);
            this.Controls.Add(this.Asset_OS);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Asset_IP_Version);
            this.Controls.Add(this.Asset_Type);
            this.Controls.Add(this.Asset_Submit);
            this.Controls.Add(this.Asset_Cancel);
            this.Controls.Add(this.Get_Info);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Location_Ser);
            this.Controls.Add(this.Asset_IP);
            this.Controls.Add(this.Location_Desk_Number);
            this.Controls.Add(this.Location_Dep);
            this.Controls.Add(this.Location_Room_Num);
            this.Controls.Add(this.Asset_Notes);
            this.Controls.Add(this.Asset_name);
            this.Controls.Add(this.Asset_Model);
            this.Controls.Add(this.Asset_manu);
            this.Controls.Add(this.Asset_Date);
            this.Controls.Add(this.Asset_HDD);
            this.Controls.Add(this.Asset_NIN);
            this.Controls.Add(this.Asset_NIT);
            this.Controls.Add(this.Asset_Location);
            this.Controls.Add(this.Asset_MNote);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Main_Assets);
            this.Name = "Add_Asset";
            this.Text = "Add a New Asset";
            this.Load += new System.EventHandler(this.Add_Asset_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Main_Assets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Main_Assets;
        private mssql1903299DataSet mssql1903299DataSet;
        private System.Windows.Forms.BindingSource dLocationBindingSource;
        private mssql1903299DataSetTableAdapters.DLocationTableAdapter dLocationTableAdapter;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox Asset_MNote;
        private System.Windows.Forms.TextBox Asset_Location;
        private System.Windows.Forms.TextBox Asset_NIT;
        private System.Windows.Forms.TextBox Asset_NIN;
        private System.Windows.Forms.TextBox Asset_HDD;
        private System.Windows.Forms.TextBox Asset_Date;
        private System.Windows.Forms.TextBox Asset_manu;
        private System.Windows.Forms.TextBox Asset_Model;
        private System.Windows.Forms.TextBox Asset_name;
        private System.Windows.Forms.TextBox Asset_Notes;
        private System.Windows.Forms.TextBox Location_Room_Num;
        private System.Windows.Forms.TextBox Location_Dep;
        private System.Windows.Forms.TextBox Location_Desk_Number;
        private System.Windows.Forms.TextBox Asset_IP;
        private System.Windows.Forms.TextBox Location_Ser;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Get_Info;
        private System.Windows.Forms.Button Asset_Cancel;
        private System.Windows.Forms.Button Asset_Submit;
        private System.Windows.Forms.TextBox Asset_Type;
        private System.Windows.Forms.TextBox Asset_IP_Version;
        private System.Windows.Forms.BindingSource dLocationBindingSource1;
        private mssql1903299DataSet4 mssql1903299DataSet4;
        private System.Windows.Forms.BindingSource dLocationBindingSource2;
        private mssql1903299DataSet4TableAdapters.DLocationTableAdapter dLocationTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn placeNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Asset_OS;
        private System.Windows.Forms.TextBox Software_Manu;
    }
}