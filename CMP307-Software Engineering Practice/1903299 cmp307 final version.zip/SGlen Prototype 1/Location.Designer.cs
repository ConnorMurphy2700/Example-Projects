﻿
namespace SGlen_Prototype_1
{
    partial class Location
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Submit_Location = new System.Windows.Forms.Button();
            this.Location_Name = new System.Windows.Forms.TextBox();
            this.Location_PNum = new System.Windows.Forms.TextBox();
            this.Location_Post_Code = new System.Windows.Forms.TextBox();
            this.Location_Adds = new System.Windows.Forms.TextBox();
            this.dLocationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mssql1903299DataSet1 = new SGlen_Prototype_1.mssql1903299DataSet1();
            this.mssql1903299DataSet = new SGlen_Prototype_1.mssql1903299DataSet();
            this.mssql1903299DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dLocationTableAdapter = new SGlen_Prototype_1.mssql1903299DataSet1TableAdapters.DLocationTableAdapter();
            this.Loc_Cancel = new System.Windows.Forms.Button();
            this.BranchGridView = new System.Windows.Forms.DataGridView();
            this.locationIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.placeNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.postCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dLocationBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dLocationTableAdapter1 = new SGlen_Prototype_1.mssql1903299DataSetTableAdapters.DLocationTableAdapter();
            this.Loc_Delete = new System.Windows.Forms.Button();
            this.Loc_Reload = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BranchGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // Submit_Location
            // 
            this.Submit_Location.Location = new System.Drawing.Point(703, 333);
            this.Submit_Location.Name = "Submit_Location";
            this.Submit_Location.Size = new System.Drawing.Size(136, 63);
            this.Submit_Location.TabIndex = 2;
            this.Submit_Location.Text = "Save";
            this.Submit_Location.UseVisualStyleBackColor = true;
            this.Submit_Location.Click += new System.EventHandler(this.Submit_Location_Click);
            // 
            // Location_Name
            // 
            this.Location_Name.Location = new System.Drawing.Point(23, 305);
            this.Location_Name.Name = "Location_Name";
            this.Location_Name.Size = new System.Drawing.Size(325, 26);
            this.Location_Name.TabIndex = 3;
            this.Location_Name.Text = "Enter the name of the new branch";
            this.Location_Name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Location_PNum
            // 
            this.Location_PNum.Location = new System.Drawing.Point(23, 454);
            this.Location_PNum.Name = "Location_PNum";
            this.Location_PNum.Size = new System.Drawing.Size(325, 26);
            this.Location_PNum.TabIndex = 4;
            this.Location_PNum.Text = "Enter the Phone Number of the new branch";
            this.Location_PNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Location_Post_Code
            // 
            this.Location_Post_Code.Location = new System.Drawing.Point(23, 404);
            this.Location_Post_Code.Name = "Location_Post_Code";
            this.Location_Post_Code.Size = new System.Drawing.Size(325, 26);
            this.Location_Post_Code.TabIndex = 5;
            this.Location_Post_Code.Text = "Enter the Post Code of  the New Branch";
            this.Location_Post_Code.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Location_Adds
            // 
            this.Location_Adds.Location = new System.Drawing.Point(23, 351);
            this.Location_Adds.Name = "Location_Adds";
            this.Location_Adds.Size = new System.Drawing.Size(325, 26);
            this.Location_Adds.TabIndex = 6;
            this.Location_Adds.Text = "Enter the Address of the new branch";
            this.Location_Adds.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dLocationBindingSource
            // 
            this.dLocationBindingSource.DataMember = "DLocation";
            this.dLocationBindingSource.DataSource = this.mssql1903299DataSet1;
            // 
            // mssql1903299DataSet1
            // 
            this.mssql1903299DataSet1.DataSetName = "mssql1903299DataSet1";
            this.mssql1903299DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mssql1903299DataSet
            // 
            this.mssql1903299DataSet.DataSetName = "mssql1903299DataSet";
            this.mssql1903299DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mssql1903299DataSetBindingSource
            // 
            this.mssql1903299DataSetBindingSource.DataSource = this.mssql1903299DataSet;
            this.mssql1903299DataSetBindingSource.Position = 0;
            // 
            // dLocationTableAdapter
            // 
            this.dLocationTableAdapter.ClearBeforeFill = true;
            // 
            // Loc_Cancel
            // 
            this.Loc_Cancel.Location = new System.Drawing.Point(868, 417);
            this.Loc_Cancel.Name = "Loc_Cancel";
            this.Loc_Cancel.Size = new System.Drawing.Size(136, 63);
            this.Loc_Cancel.TabIndex = 8;
            this.Loc_Cancel.Text = "Back to main page";
            this.Loc_Cancel.UseVisualStyleBackColor = true;
            this.Loc_Cancel.Click += new System.EventHandler(this.Loc_Cancel_Click);
            // 
            // BranchGridView
            // 
            this.BranchGridView.AutoGenerateColumns = false;
            this.BranchGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.BranchGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.locationIDDataGridViewTextBoxColumn,
            this.placeNameDataGridViewTextBoxColumn,
            this.dAddressDataGridViewTextBoxColumn,
            this.postCodeDataGridViewTextBoxColumn,
            this.phoneNumDataGridViewTextBoxColumn});
            this.BranchGridView.DataSource = this.dLocationBindingSource1;
            this.BranchGridView.Location = new System.Drawing.Point(12, 12);
            this.BranchGridView.Name = "BranchGridView";
            this.BranchGridView.RowHeadersWidth = 62;
            this.BranchGridView.RowTemplate.Height = 28;
            this.BranchGridView.Size = new System.Drawing.Size(1024, 272);
            this.BranchGridView.TabIndex = 9;
            this.BranchGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.BranchGridView_DoubleClick);
            // 
            // locationIDDataGridViewTextBoxColumn
            // 
            this.locationIDDataGridViewTextBoxColumn.DataPropertyName = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn.HeaderText = "Location_ID";
            this.locationIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.locationIDDataGridViewTextBoxColumn.Name = "locationIDDataGridViewTextBoxColumn";
            this.locationIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.locationIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // placeNameDataGridViewTextBoxColumn
            // 
            this.placeNameDataGridViewTextBoxColumn.DataPropertyName = "Place_Name";
            this.placeNameDataGridViewTextBoxColumn.HeaderText = "Place_Name";
            this.placeNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.placeNameDataGridViewTextBoxColumn.Name = "placeNameDataGridViewTextBoxColumn";
            this.placeNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // dAddressDataGridViewTextBoxColumn
            // 
            this.dAddressDataGridViewTextBoxColumn.DataPropertyName = "DAddress";
            this.dAddressDataGridViewTextBoxColumn.HeaderText = "DAddress";
            this.dAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dAddressDataGridViewTextBoxColumn.Name = "dAddressDataGridViewTextBoxColumn";
            this.dAddressDataGridViewTextBoxColumn.Width = 150;
            // 
            // postCodeDataGridViewTextBoxColumn
            // 
            this.postCodeDataGridViewTextBoxColumn.DataPropertyName = "Post_Code";
            this.postCodeDataGridViewTextBoxColumn.HeaderText = "Post_Code";
            this.postCodeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.postCodeDataGridViewTextBoxColumn.Name = "postCodeDataGridViewTextBoxColumn";
            this.postCodeDataGridViewTextBoxColumn.Width = 150;
            // 
            // phoneNumDataGridViewTextBoxColumn
            // 
            this.phoneNumDataGridViewTextBoxColumn.DataPropertyName = "Phone_Num";
            this.phoneNumDataGridViewTextBoxColumn.HeaderText = "Phone_Num";
            this.phoneNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.phoneNumDataGridViewTextBoxColumn.Name = "phoneNumDataGridViewTextBoxColumn";
            this.phoneNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // dLocationBindingSource1
            // 
            this.dLocationBindingSource1.DataMember = "DLocation";
            this.dLocationBindingSource1.DataSource = this.mssql1903299DataSetBindingSource;
            // 
            // dLocationTableAdapter1
            // 
            this.dLocationTableAdapter1.ClearBeforeFill = true;
            // 
            // Loc_Delete
            // 
            this.Loc_Delete.Location = new System.Drawing.Point(703, 417);
            this.Loc_Delete.Name = "Loc_Delete";
            this.Loc_Delete.Size = new System.Drawing.Size(136, 63);
            this.Loc_Delete.TabIndex = 10;
            this.Loc_Delete.Text = "Delete";
            this.Loc_Delete.UseVisualStyleBackColor = true;
            this.Loc_Delete.Click += new System.EventHandler(this.Loc_Delete_Click);
            // 
            // Loc_Reload
            // 
            this.Loc_Reload.Location = new System.Drawing.Point(868, 333);
            this.Loc_Reload.Name = "Loc_Reload";
            this.Loc_Reload.Size = new System.Drawing.Size(136, 63);
            this.Loc_Reload.TabIndex = 11;
            this.Loc_Reload.Text = "Refresh table";
            this.Loc_Reload.UseVisualStyleBackColor = true;
            this.Loc_Reload.Click += new System.EventHandler(this.Loc_Reload_Click);
            // 
            // Location
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1048, 499);
            this.Controls.Add(this.Loc_Reload);
            this.Controls.Add(this.Loc_Delete);
            this.Controls.Add(this.BranchGridView);
            this.Controls.Add(this.Loc_Cancel);
            this.Controls.Add(this.Location_Adds);
            this.Controls.Add(this.Location_Post_Code);
            this.Controls.Add(this.Location_PNum);
            this.Controls.Add(this.Location_Name);
            this.Controls.Add(this.Submit_Location);
            this.Name = "Location";
            this.Text = "Location";
            this.Load += new System.EventHandler(this.Location_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mssql1903299DataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BranchGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dLocationBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Submit_Location;
        private System.Windows.Forms.TextBox Location_Name;
        private System.Windows.Forms.TextBox Location_PNum;
        private System.Windows.Forms.TextBox Location_Post_Code;
        private System.Windows.Forms.TextBox Location_Adds;
        private System.Windows.Forms.BindingSource mssql1903299DataSetBindingSource;
        private mssql1903299DataSet mssql1903299DataSet;
        private mssql1903299DataSet1 mssql1903299DataSet1;
        private System.Windows.Forms.BindingSource dLocationBindingSource;
        private mssql1903299DataSet1TableAdapters.DLocationTableAdapter dLocationTableAdapter;
        private System.Windows.Forms.Button Loc_Cancel;
        private System.Windows.Forms.DataGridView BranchGridView;
        private System.Windows.Forms.BindingSource dLocationBindingSource1;
        private mssql1903299DataSetTableAdapters.DLocationTableAdapter dLocationTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn placeNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn postCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Loc_Delete;
        private System.Windows.Forms.Button Loc_Reload;
    }
}