﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.Net;
using System.Management;
using System.IO;
using System.Collections;

namespace SGlen_Prototype_1
{
    public partial class Add_Asset : Form
    {
        public Add_Asset()
        {
            InitializeComponent();
        }

        readonly mssql1903299Entities6 db = new mssql1903299Entities6();
        Asset asset = new Asset();
        Location_Spes loc = new Location_Spes();
        Software sware = new Software();
        Search GB = new Search();
        
        
        //back button
        private void Asset_Cancel_Click(object sender, EventArgs e)
        {
            var m = new MainPage(); //navagates back to main page
            m.Show();
            this.Hide();
        }


        //adds a new asset to the database
        private void Asset_Submit_Click(object sender, EventArgs e)
        {
            bool desk_check = true; // used to check if both desk and server sections are left untouched 
            bool serv_check = true;
            try
            {
                //asset section
            if (string.IsNullOrEmpty(Asset_name.Text) == true) //checks text boxes for new information
            {
                MessageBox.Show("Please enter the name of the new Asset");
                Asset_name.Text = "Enter the name of the new Asset";
                return;
            }
            if (Asset_name.Text == "Enter the name of the new Asset")
            {
                MessageBox.Show("Please enter the name of the new Asset");
                Asset_name.Text = "Enter the name of the new Asset";
                return;
            }
            if (string.IsNullOrEmpty(Asset_Model.Text) == true)
            {
                MessageBox.Show("Please enter the Model of the new Asset");
                Asset_Model.Text = "Enter the Model of the new Asset";
                return;
            }
            if (Asset_Model.Text == "Enter the Model of the new Asset")
            {
                MessageBox.Show("Please enter the Model of the new Asset");
                Asset_Model.Text = "Enter the Model of the new Asset";
                return;
            }
            if (string.IsNullOrEmpty(Asset_manu.Text) == true)
            {
                MessageBox.Show("Please enter the Manufacturer of the new Asset");
                Asset_manu.Text = "Enter the Manufacturer of the new Asset";
                return;
            }
            if (Asset_manu.Text == "Enter the Type of the new Asset")
            {
                MessageBox.Show("Please enter the Manufacturer of the new Asset");
                Asset_manu.Text = "Enter the Manufacturer of the new Asset";
                return;
            }
            if (string.IsNullOrEmpty(Asset_Type.Text) == true)
            {
                MessageBox.Show("Please enter the Type of the new Asset");
                Asset_Type.Text = "Enter the Type of the new Asset";
                return;
            }
            if (Asset_Type.Text == "Enter the Type of the new Asset")
            {
                MessageBox.Show("Please enter the Type of the new Asset");
                Asset_Type.Text = "Enter the Type of the new Asset";
                return;
            }
            if (string.IsNullOrEmpty(Asset_Date.Text) == true)
            {
                Asset_Date.Text = "  ";
            }
            if (Asset_Date.Text == "Enter the date of purchace of the new Asset (yyyy/mm/dd)")
            {
                Asset_Date.Text = "  ";
            }
            if (string.IsNullOrEmpty(Asset_Notes.Text) == true)
            {
                Asset_Notes.Text = "  ";
            }
            if (Asset_Notes.Text == "Enter the any general notes for the Asset less than 150 characters")
            {
                Asset_Notes.Text = "  ";
            }
            if (string.IsNullOrEmpty(Asset_MNote.Text) == true)
            {
                Asset_MNote.Text = "  ";
            }
            if (Asset_MNote.Text == "Enter the any Maintenance notes for the Asset less than 150 characters")
            {
                Asset_MNote.Text = "  ";
            }
            if (string.IsNullOrEmpty(Asset_HDD.Text) == true)
            {
                MessageBox.Show("Please enter the HDD number of the new Asset");
                Asset_HDD.Text = "Enter the HDD number of the new Asset";
                return;
            }
            if (Asset_HDD.Text == "Enter the HDD number of the new Asset")
            {
                MessageBox.Show("Please enter the HDD number of the new Asset");
                Asset_HDD.Text = "Enter the HDD number of the new Asset";
                return;
            }
            if (string.IsNullOrEmpty(Asset_NIN.Text) == true)
            {
                MessageBox.Show("Please enter the name of the Network Interface of new Asset");
                Asset_NIN.Text = "Enter the name of the Network Interface of new Asset";
                return;
            }
            if (Asset_NIN.Text == "Enter the name of the Network Interface of new Asset")
            {
                MessageBox.Show("Please enter the name of the Network Interface of new Asset");
                Asset_NIN.Text = "Enter Product Stock";
                return;
            }
            if (string.IsNullOrEmpty(Asset_NIT.Text) == true)
            {
                MessageBox.Show("Please enter the type of network interface the new Asset will use");
                Asset_NIT.Text = "Enter the type of network interface the new Asset will use";
                return;
            }
            if (Asset_NIT.Text == "Enter the type of network interface the new Asset will use")
            {
                MessageBox.Show("Please enter the type of network interface the new Asset will use");
                Asset_NIT.Text = "Enter the type of network interface the new Asset will use";
                return;
            }
            if (string.IsNullOrEmpty(Asset_Location.Text) == true)
            {
                MessageBox.Show("Please enter the Id of the building the new Asset will be placed in");
                Asset_Location.Text = "Enter the Id of the building the new Asset will be placed in";
                return;
            }
            if (Asset_Location.Text == "Enter the Id of the building the new Asset will be placed in")
            {
                MessageBox.Show("Please enter the Id of the building the new Asset will be placed in");
                Asset_Location.Text = "Enter the Id of the building the new Asset will be placed in";
                return;
            }
            if (string.IsNullOrEmpty(Asset_IP.Text) == true)
            {
                MessageBox.Show("Please enter the IP Address of the new asset");
                Asset_IP.Text = "Enter the IP Address of the new Asset";
                return;
            }
            if (Asset_IP.Text == "Enter the IP Address of the new Asset")
            {
                MessageBox.Show("Please enter the IP Address of the new asset");
                Asset_IP.Text = "Enter the IP Address of the new Asset";
                return;
            }

            if (string.IsNullOrEmpty(Asset_IP_Version.Text) == true)
            {
                MessageBox.Show("Please enter the IP Version of network interface the new Asset");
                Asset_IP_Version.Text = "Enter the IP Version of network interface the new Asset will use";
                return;
            }
            if (Asset_IP_Version.Text == "Enter the IP Version of network interface the new Asset will use")
            {
                MessageBox.Show("Please enter the IP Version of network interface the new Asset");
                Asset_IP_Version.Text = "Enter the IP Version of network interface the new Asset will use";
                return;
            }

                //location sections
                if (string.IsNullOrEmpty(Location_Desk_Number.Text) == true) //checks text boxes for new information
                {
                    Location_Desk_Number.Text = "";
                    desk_check = false;
                }
                if (Location_Desk_Number.Text == "Enter the new desk number")
                {
                    Location_Desk_Number.Text = "";
                    desk_check = false;
                }

                if (string.IsNullOrEmpty(Location_Ser.Text) == true) //checks text boxes for new information
                {
                    Location_Ser.Text = "";
                    serv_check = false;
                }
                if (Location_Ser.Text == "Enter the new server section")
                {
                    Location_Ser.Text = "";
                    serv_check = false;
                }

            if (string.IsNullOrEmpty(Location_Room_Num.Text) == true)
            {
                MessageBox.Show("Please enter the Room Number the new Asset will be placed in");
                Location_Room_Num.Text = "Enter the Room Number the new Asset will be placed in";
                return;
            }
            if (Location_Room_Num.Text == "Enter the Room Number the new Asset will be placed in")
            {
                MessageBox.Show("Please enter the Room Number the new Asset will be placed in");
                Location_Room_Num.Text = "Enter the Room Number the new Asset will be placed in";
                return;
            }
            if (string.IsNullOrEmpty(Location_Dep.Text) == true)
            {
                MessageBox.Show("Please enter the Department that will use the new Asset");
                Location_Dep.Text = "Enter the Department that will use the new Asset";
                return;
            }
            if (Location_Dep.Text == "Enter the Department that will use the new Asset")
            {
                MessageBox.Show("Please enter the Department that will use the new Asset");
                Location_Dep.Text = "Enter the Department that will use the new Asset";
                return;
            }
            //software section 
            if (string.IsNullOrEmpty(Asset_OS.Text) == true)
            {
                MessageBox.Show("Please enter the Operating System the new Asset will run on");
                Asset_OS.Text = "Enter the Operating System the new Asset will run on";
                return;
            }
            if (Asset_OS.Text == "Enter the Operating System the new Asset will run on")
            {
                MessageBox.Show("Please enter the Operating System the new Asset will run on");
                Asset_OS.Text = "Enter the Operating System the new Asset will run on";
                return;
            }
            if (string.IsNullOrEmpty(Software_Manu.Text) == true)
            {
                MessageBox.Show("Please enter the Operating System version the new Asset will run on");
                Software_Manu.Text = "Enter the manufacture of  the Operating System";
                return;
            }
            if (Software_Manu.Text == "Enter the manufacture of  the Operating System")
            {
                MessageBox.Show("Please enter the manufacture of  the Operating System");
                Software_Manu.Text = "Enter the manufacture of  the Operating System";
                return;
            }


                if ((desk_check = false) && (serv_check = false))//checks to see if the boxes have been filled in 
                {
                    MessageBox.Show("Please enter a Desk Number or a Server section");
                    return;
                }

                // checks to see if both boxes are filled in 
                if ((string.IsNullOrEmpty(Location_Ser.Text) == false) && (string.IsNullOrEmpty(Location_Desk_Number.Text) == false))
                {
                    MessageBox.Show("Please only enter a Desk Number or a Server section");
                    return;
                }
                bool building_check = GB.Location_Test(Convert.ToInt32( Asset_Location.Text));
                if (building_check == false)
                {
                    MessageBox.Show("pleas enter a valid building id");
                    return;
                }

            asset.Divice_Name = Asset_name.Text.Trim();
            asset.Model = Asset_Model.Text.Trim();
            asset.Manufacturer = Asset_manu.Text.Trim();
            asset.MType = Asset_Type.Text.Trim();
            asset.Purchase_Date = Asset_Date.Text.Trim();
            asset.HDD_Serial_NUM = Asset_HDD.Text.Trim();
            asset.Network_interface_Name = Asset_NIN.Text.Trim();
            asset.Network_IP_Version = Asset_IP_Version.Text.Trim();
            asset.Network_interfaceType = Asset_NIT.Text.Trim();
            asset.Maintenance_Notes = Asset_MNote.Text.Trim();
            asset.Notes = Asset_Notes.Text.Trim();
            asset.Location_ID = Convert.ToInt32(Asset_Location.Text.Trim());
            asset.IP_Address = Asset_IP.Text.Trim();
            asset.OS = Asset_OS.Text.Trim();
            

            loc.IP_Address = Asset_IP.Text.Trim(); // sets row values
            loc.Location_ID = Convert.ToInt32(Asset_Location.Text.Trim());
            loc.Department = Location_Dep.Text.Trim();
            loc.Room_Num = Convert.ToInt32(Location_Room_Num.Text.Trim());
            loc.Desk_Num = Convert.ToInt32(Location_Desk_Number.Text.Trim());
            loc.Server_Section = Location_Ser.Text.Trim();

            sware.OS = Asset_OS.Text.Trim();
            sware.Manufacturer = Software_Manu.Text.Trim();
            bool s_check = GB.Software_Test(Asset_OS.Text.Trim());
            //if(s_check == false) {db.Softwares.Add(sware); }


            db.Assets.Add(asset); 
            db.Location_Spes.Add(loc);
            
            db.SaveChanges(); //adding new rows to the database
            MessageBox.Show("Record Save Successfully");

            Asset_name.Text = "Enter the name of the new Asset"; // resets text boxes
            Asset_Model.Text = "Enter the Model of the new Asset";
            Asset_manu.Text = "Enter the Manufacturer of the new Asset";
            Asset_Type.Text = "Enter the Type of the new Asset";
            Asset_HDD.Text = "Enter the HDD number of the new Asset";
            Asset_Date.Text = "Enter the date of purchace of the new Asset (yyyy/mm/dd)";
            Asset_NIN.Text = "Enter the name of the Network Interface of new Asset";
            Asset_IP_Version.Text = "Enter the IP Version of network interface the new Asset will use";
            Asset_NIT.Text = "Enter the type of network interface the new Asset will use";
            Asset_Location.Text = "Enter the Id of the building the new Asset will be placed in";
            Asset_MNote.Text = "Enter the any Maintenance notes for the Asset less than 150 characters";
            Asset_Notes.Text = "Enter the any general notes for the Asset less than 150 characters";
            Asset_IP.Text = "Enter the IP Address of the new Asset";
            Location_Dep.Text = "Enter the Department that will use the new Asset";
            Location_Room_Num.Text = "Enter the Room Number the new Asset will be placed in";
            Location_Desk_Number.Text = "Enter the Desk Number the new Asset will be used at";
            Location_Ser.Text = "Enter the Server Section Number the new Asset will be used at";
            Asset_OS.Text = "Enter the Operating System the new Asset will run on";
            Software_Manu.Text = "Enter the manufacture of  the Operating System";

            }

            catch (Exception x)
            {
                MessageBox.Show("You have entered invalid data make sure to check for correct formatting.");
                return;

            }

            var m = new MainPage(); //navagates back to main page
            m.Show();
            this.Hide();
        }

        private void Add_Asset_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mssql1903299DataSet4.DLocation' table. You can move, or remove it, as needed.
            this.dLocationTableAdapter1.Fill(this.mssql1903299DataSet4.DLocation);

        }

        private void Get_Info_Click(object sender, EventArgs e)
        {
            IPGlobalProperties computerProperties = IPGlobalProperties.GetIPGlobalProperties();
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface adapter in nics) // getting network interface information
            {
            Asset_NIN.Text = adapter.Description;
            Asset_NIT.Text = adapter.NetworkInterfaceType.ToString();
            string versions = "";

                // Create a display string for the supported IP versions.
                if (adapter.Supports(NetworkInterfaceComponent.IPv4))
                {
                    versions = "IPv4";
                }
                if (adapter.Supports(NetworkInterfaceComponent.IPv6))
                {
                    if (versions.Length > 0)
                    {
                        versions += " ";
                    }
                    versions += "IPv6";
                }

            Asset_IP_Version.Text = versions;


                break;
            }

            string hostName = Dns.GetHostName(); // Retrive the Name of HOST
            // Get the IP
            string myIP = Dns.GetHostByName(hostName).AddressList[0].ToString();
            Asset_IP.Text = myIP;
            Asset_name.Text = Environment.MachineName.ToString();

            ManagementClass mc = new ManagementClass("Win32_ComputerSystem");
            //collection to store all management objects
            ManagementObjectCollection moc = mc.GetInstances();

            if (moc.Count != 0)
            {
                foreach (ManagementObject mo in mc.GetInstances())
                {
                  Asset_manu.Text = mo["Manufacturer"].ToString();
                }
            }


            ManagementObjectSearcher moSearcher = new
            ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");

            foreach (ManagementObject wmi_HD in moSearcher.Get())
            {
                Asset_Model.Text = wmi_HD["Model"].ToString();  //Model Number
                Asset_HDD.Text = wmi_HD["SerialNumber"].ToString(); //Serial Number
                break;              
            }

            Asset_OS.Text = Environment.OSVersion.ToString();

            if(Asset_OS.Text.Contains("Windows")== true)
            {
                Software_Manu.Text = "Microsoft";
            }
            if (Asset_OS.Text.Contains("Ubuntu") == true)
            {
                Software_Manu.Text = " Canonical Ltd";
            }
            if (Asset_OS.Text.Contains("Fedora") == true)
            {
                Software_Manu.Text = "Fedora Project";
            }

        }


    }
}
    

