#include <unordered_map>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <queue>

using std::string;
using std::cout;
using std::endl;
using std::vector;
using std::ifstream;
using std::ostringstream;
using namespace std;

using std::chrono::duration_cast; //setting up the clock for testing 
using std::chrono::milliseconds;
using the_clock = std::chrono::steady_clock;

std::unordered_map<string, string> hashes; //using global variables in order to make easy access for all the functions
vector<string> PossiblePassword;
std::mutex PaswordMutex;
std::mutex TaskMutex;
std::condition_variable cv;
bool result_ready = false;
bool file_read = false;

string encrypt(string text) // this function encripts passwords using a simple switch cypher
{
	string result;
	int cypher[5] = { 7,8,-3,14,-6 }; //the cypher used to chance the letters of each password
	int j = 0;
	// traverse the password
	for (int i = 0; i < text.length(); i++)
	{
		if (j > 5) { j = 0; }
		// apply transformation to each character
		result += wchar_t(int(text[i] + cypher[j] - 65) % 26 + 65); //using wchar_t it beable to use Unicode charateds for added protection
		j++;
	}
	// Return the resulting string
	return result;
}


// gets the hash to compare against 
string GetPassToCrack()
{
	cout << "getting pasword to crack" << endl;
	ifstream input_file("PassToCrack.txt");

	auto ss = std::ostringstream{};
	ss << input_file.rdbuf();
	return ss.str();
}


/// <summary>
///  reads a list of possible passwords form a .txt file and uses them to populate a vector thet is the returned
/// </summary>
void  GetPossiblePass()
{
	cout << "reading in passwords" << endl;
	string input;
	ifstream myfile("Posablepaswords.txt");
	if (myfile.is_open())
	{
		while (getline(myfile, input)) {
			PaswordMutex.lock();
			PossiblePassword.push_back(input);
			PaswordMutex.unlock();
			result_ready = false;
			cv.notify_all();

		}
		myfile.close();
	}
	file_read = true;
}

// does the main work of the program taking passwords encripting them and them placing them in to a map
void HashPassword(string compareHash, int thredID)
{
	string test;
	string output;
	std::unique_lock<std::mutex> lk(TaskMutex);
	cv.wait(lk);

	while (!result_ready)
	{


		if (!PossiblePassword.empty())// checkes if posiable passwords is empty if not then hash the remaing paswords
		{

			std::unique_lock <std::mutex> lock(PaswordMutex);
			test = PossiblePassword.back();
			PossiblePassword.pop_back();
			result_ready = false;
			output = encrypt(test); //encripts the password			
			hashes.insert({output, test }); //Adds the plain password and the encripted password to the unorderd map
		}

		if (PossiblePassword.empty() && file_read == true)// to brake the loop when all the paswords have been read in and hashed 
		{
			//cout << thredID << endl;
			return;
		}
	}
}


int main()
{

	vector<std::thread> threads;
	ofstream my_file("timing.csv");

	int NumThreads = 8; // this variable controls the number od threads made to run the program 

	int choice = 0;
	bool choicemade = false;
	string input;

	while (!choicemade)// desides wether to run with a predetermind password or a user made one
	{
		cout << "Enter 1 if you want to use you own password or 2 to use the premade encripted password" << endl;
		cin >> choice;

		if (choice == 1) //running with the users inputted password 
		{
			string temp;
			cout << "Please enter the password you want to try" << endl;
			cin >> temp;
			input = encrypt(temp);
			cout << "Your encrypted password is " << input << endl;
			choicemade = true;
		};
		if (choice == 2)//running with the predesigned inputted password
		{
			input = GetPassToCrack();
			choicemade = true;
		};
	}

	for (int i = 0; i < 10; i++) // testing loop
	{
		the_clock::time_point startTime = the_clock::now();
		// get paswords to check
		threads.push_back(std::thread(GetPossiblePass));


		for (int i = 0; i < NumThreads; i++) // create threads to divide up the task 
		{
			threads.push_back(std::thread(HashPassword, input, i));//encript paswords on the cpu make and put in to a map for storage 
		}

		for (std::thread& t : threads) { //join all the threads back together
			if (t.joinable()) {
				t.join();
			}
		}
		the_clock::time_point endTime = the_clock::now();

		auto time_taken = duration_cast<milliseconds>(endTime - startTime).count();

		my_file << time_taken << "," << NumThreads << "\n";

		// use map to output possible haswords
		if (!(hashes.find(input) == hashes.end()))
		{
			cout << "The possible passwords of the inputed hash " << input << endl;
			cout << hashes.find(input)->second << endl;
		}
		else
		{
			cout << "No matches where found" << endl;
		}

		hashes.clear(); // used to empty the map in between uses 
		threads.clear(); // clean up the threds in between loops
	}
	my_file.close();
}
